package com.example.netspeed

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Menyalakan kembali overlay setelah HP restart, jika "Mulai otomatis" diaktifkan. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = Prefs(context)
        if (!prefs.autoStart || !prefs.enabled) return
        if (!Settings.canDrawOverlays(context)) return
        try {
            context.startForegroundService(Intent(context, OverlayService::class.java))
        } catch (_: Exception) {
        }
    }
}
