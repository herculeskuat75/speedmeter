package com.example.netspeed

import java.net.InetSocketAddress
import java.net.Socket

/** Ping ke Google (8.8.8.8). Dipanggil dari thread latar. */
object Pinger {
    private val timeRe = Regex("""time[=<]\s*([0-9.]+)""")

    /** Milidetik, atau null jika tidak ada respon. */
    fun pingGoogle(): Int? = icmp("8.8.8.8") ?: tcp("8.8.8.8", 443)

    private fun icmp(host: String): Int? {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("ping", "-c", "1", "-W", "2", host))
            try {
                val out = p.inputStream.bufferedReader().readText()
                p.waitFor()
                val ms = timeRe.find(out)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                if (ms == null) null else Math.round(ms).toInt().coerceAtLeast(1)
            } finally {
                p.destroy()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun tcp(host: String, port: Int): Int? {
        return try {
            val s = Socket()
            val t0 = System.nanoTime()
            try {
                s.connect(InetSocketAddress(host, port), 2000)
            } finally {
                try { s.close() } catch (_: Exception) {}
            }
            ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
        } catch (_: Exception) {
            null
        }
    }
}
