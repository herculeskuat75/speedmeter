package com.example.netspeed

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import android.util.DisplayMetrics

/** Pembungkus supaya aplikasi tetap jalan di Android lama (minimal Android 5.0). */
object Compat {

    /** Izin "tampil di atas aplikasi lain". Di Android 5 izin ini sudah otomatis diberikan saat pasang. */
    fun canDrawOverlays(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 23) Settings.canDrawOverlays(c) else true

    /** Android 8+ wajib startForegroundService, Android lama pakai startService. */
    fun startOverlayService(c: Context) {
        val i = Intent(c, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
    }

    @Suppress("DEPRECATION")
    fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    /** Ada jaringan aktif yang punya internet? */
    @Suppress("DEPRECATION")
    fun isConnected(cm: ConnectivityManager): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 23) {
                val n = cm.activeNetwork
                val caps = if (n != null) cm.getNetworkCapabilities(n) else null
                caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            } else {
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Exception) {
            false
        }
    }

    /** Ukuran layar penuh (termasuk area tombol navigasi). */
    @Suppress("DEPRECATION")
    fun realScreenSize(wm: WindowManager): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    /**
     * Tinggi tombol navigasi di bawah layar (Home / Back / Recent atau garis gestur).
     * Meter dan panel dijaga agar tidak menutupi area ini, supaya tombol Home tetap bisa ditekan.
     */
    fun navBarHeight(c: Context): Int {
        return try {
            val r = c.resources
            val id = r.getIdentifier("navigation_bar_height", "dimen", "android")
            if (id > 0) r.getDimensionPixelSize(id) else 0
        } catch (_: Exception) {
            0
        }
    }

    /** Tinggi yang aman dipakai (di atas tombol navigasi). */
    fun usableHeight(c: Context, wm: WindowManager, safe: Boolean): Int {
        val (_, h) = realScreenSize(wm)
        return if (safe) (h - navBarHeight(c)).coerceAtLeast(h / 2) else h
    }
}
