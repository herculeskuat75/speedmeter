package com.example.netspeed

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Layanan aksesibilitas kosong. Satu-satunya gunanya: jendela bertipe TYPE_ACCESSIBILITY_OVERLAY
 * digambar di ATAS panel notifikasi dan layar Pengaturan, dan tidak ikut disembunyikan Android
 * seperti jendela overlay biasa. Tidak membaca isi layar (canRetrieveWindowContent = false).
 */
class OverlayAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        OverlayService.current?.recreateOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        OverlayService.current?.recreateOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: OverlayAccessibilityService? = null
    }
}
