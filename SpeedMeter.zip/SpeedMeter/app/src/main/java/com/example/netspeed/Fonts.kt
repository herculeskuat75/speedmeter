package com.example.netspeed

import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.graphics.Color

/** Daftar font yang tersedia di semua HP Android (tanpa file font tambahan). */
object Fonts {
    val names = listOf(
        "Ikuti font HP (sistem)",
        "Bawaan aplikasi (monospace)",
        "Sans-serif (Roboto)",
        "Sans-serif tipis",
        "Sans-serif sedang",
        "Sans-serif ringkas",
        "Serif",
        "Casual",
        "Tulisan tangan (cursive)"
    )

    /** Nama keluarga font; null = font bawaan HP. */
    fun family(idx: Int): String? = when (idx) {
        1 -> "monospace"
        2 -> "sans-serif"
        3 -> "sans-serif-light"
        4 -> "sans-serif-medium"
        5 -> "sans-serif-condensed"
        6 -> "serif"
        7 -> "casual"
        8 -> "cursive"
        else -> null
    }

    /** weight: 0 = normal, 1 = tebal, 2 = tebal banget */
    fun typeface(idx: Int, weight: Int): Typeface {
        val fam = family(idx)
        return when {
            weight <= 0 -> if (fam == null) Typeface.DEFAULT else Typeface.create(fam, Typeface.NORMAL)
            weight >= 2 && (fam == null || fam == "sans-serif") ->
                try { Typeface.create("sans-serif-black", Typeface.NORMAL) } catch (_: Throwable) { Typeface.DEFAULT_BOLD }
            fam == null -> Typeface.DEFAULT_BOLD
            else -> Typeface.create(fam, Typeface.BOLD)
        }
    }

    /**
     * Teks berformat untuk notifikasi (RemoteViews tidak bisa setTypeface, jadi pakai span).
     * color: null = warna bawaan layout. rainbowHue: null = tanpa pelangi.
     */
    fun styled(text: String, fontIdx: Int, weight: Int, color: Int?, rainbowHue: Float?): CharSequence {
        val ss = SpannableString(text)
        if (text.isEmpty()) return ss
        val end = text.length
        var fam = family(fontIdx)
        var bold = weight >= 1
        if (weight >= 2 && (fam == null || fam == "sans-serif")) {
            fam = "sans-serif-black"
            bold = false
        }
        if (fam != null) ss.setSpan(TypefaceSpan(fam), 0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (bold) ss.setSpan(StyleSpan(Typeface.BOLD), 0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (rainbowHue != null) {
            for (i in 0 until end) {
                if (text[i].isWhitespace()) continue
                ss.setSpan(
                    ForegroundColorSpan(Rainbow.color(rainbowHue + i * 18f)),
                    i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        } else if (color != null) {
            ss.setSpan(ForegroundColorSpan(color), 0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return ss
    }
}
