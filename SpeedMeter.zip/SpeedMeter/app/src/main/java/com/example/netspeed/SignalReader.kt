package com.example.netspeed

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Membaca dBm & band lewat root, port dari script Termux:
 *   su -c "dumpsys telephony.registry; dumpsys phone"
 *
 * Bedanya dengan script: sel yang bertanda `mRegistered=YES` (sel yang benar-benar dipakai HP)
 * dibaca lebih dulu, supaya tidak salah mengambil sel tetangga. Kalau gagal, baru memakai
 * pola yang sama persis dengan script (mDbm / rsrp / mBand / earfcn).
 */
object SignalReader {

    class Info(val dbm: String, val band: String)

    private val NO_VALUE = Int.MAX_VALUE

    /** Harus dipanggil dari thread latar. Mengembalikan null jika root tidak tersedia / tidak ada data. */
    fun read(): Info? {
        val txt = RootShell.runAny("dumpsys telephony.registry 2>/dev/null; dumpsys phone 2>/dev/null")
            ?: return null
        return parse(txt)
    }

    fun parse(t: String): Info {
        val regs = registeredSegments(t)

        // ---------------- dBm
        var dbm: Int? = null
        for (seg in regs) {
            dbm = valid(first(seg, Regex("""\brsrp=(-?\d+)""")))
                ?: valid(first(seg, Regex("""ssRsrp=(-?\d+)""")))
            if (dbm != null) break
        }
        if (dbm == null) {
            // Urutan sama seperti script.
            val mDbm = Regex("""mDbm=(-?\d+)""")
            dbm = valid(first(t, mDbm))
                ?: valid(first(t, Regex("""\brsrp=(-?\d+)""")))
                ?: valid(all(t, mDbm).lastOrNull())
                ?: valid(first(t, Regex("""ssRsrp=(-?\d+)""")))
        }
        val dbmText = if (dbm == null) "N/A" else "$dbm dBm"

        // ---------------- band
        var band: String? = null
        for (seg in regs) {
            val nr = seg.contains("CellIdentityNr") || seg.contains("CellInfoNr")
            val fromList = first(seg, Regex("""mBands\s*=\s*\[\s*(\d+)"""))?.toIntOrNull()
            val fromSingle = first(seg, Regex("""mBand=(\d+)"""))?.toIntOrNull()
            val b = fromList ?: fromSingle
            if (b != null && b in 1..127) {
                band = label(b, nr)
                break
            }
            if (!nr) {
                val ch = first(seg, Regex("""[mM]?[eE]arfcn=(\d+)"""))?.toIntOrNull()
                val eb = if (ch != null) bandFromEarfcn(ch) else null
                if (eb != null) {
                    band = label(eb, false)
                    break
                }
            }
        }
        if (band == null) {
            val raw = first(t, Regex("""mBand=(\d+)"""))?.toIntOrNull()
            if (raw != null && raw in 1..99) {
                band = label(raw, false)
            } else {
                val ch = first(t, Regex("""earfcn=(\d+)"""))?.toIntOrNull()
                    ?: first(t, Regex("""mEarfcn=(\d+)"""))?.toIntOrNull()
                val eb = if (ch != null && ch > 0) bandFromEarfcn(ch) else null
                band = if (eb != null) label(eb, false) else "LTE"
            }
        }
        return Info(dbmText, band ?: "LTE")
    }

    private fun valid(v: String?): Int? {
        val i = v?.toIntOrNull() ?: return null
        return if (i == NO_VALUE || i > 0 || i < -200) null else i
    }

    private fun first(t: String, re: Regex): String? = re.find(t)?.groupValues?.getOrNull(1)

    private fun all(t: String, re: Regex): List<String> =
        re.findAll(t).mapNotNull { it.groupValues.getOrNull(1) }.toList()

    /** Potongan teks untuk tiap sel yang `mRegistered=YES`. */
    private fun registeredSegments(t: String): List<String> {
        val out = ArrayList<String>()
        var from = 0
        while (true) {
            val i = t.indexOf("mRegistered=", from)
            if (i < 0) break
            val next = t.indexOf("mRegistered=", i + 12)
            val end = if (next < 0) minOf(t.length, i + 3000) else minOf(next, i + 3000)
            if (t.startsWith("mRegistered=YES", i)) out.add(t.substring(i, end))
            from = i + 12
        }
        // LTE didahulukan dari NR / lainnya supaya cocok dengan tampilan "Info Telepon" untuk LTE.
        return out.sortedBy { if (it.contains("CellIdentityLte")) 0 else 1 }
    }

    private fun label(b: Int, nr: Boolean): String {
        val f = when (b) {
            1 -> "2100"
            2 -> "1900"
            3 -> "1800"
            5 -> "850"
            7 -> "2600"
            8 -> "900"
            20 -> "800"
            28 -> "700"
            38 -> "2600"
            40 -> "2300"
            41 -> "2500"
            78 -> "3500"
            else -> null
        }
        val name = if (nr) "n$b" else "Band $b"
        return if (f != null) "$name ($f)" else name
    }

    /** Peta nomor kanal EARFCN (downlink) ke band LTE. Sama dengan script, ditambah beberapa band umum. */
    fun bandFromEarfcn(ch: Int): Int? = when (ch) {
        in 0..599 -> 1
        in 600..1199 -> 2
        in 1200..1949 -> 3
        in 1950..2399 -> 4
        in 2400..2649 -> 5
        in 2750..3449 -> 7
        in 3450..3799 -> 8
        in 6150..6449 -> 20
        in 9210..9659 -> 28
        in 37750..38249 -> 38
        in 38650..39649 -> 40
        in 39650..41589 -> 41
        else -> null
    }

    /** IP lokal (IPv4). Jaringan fisik didahulukan (bukan VPN), Wi-Fi sebelum seluler. */
    fun localIp(ctx: Context): String {
        return try {
            val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var cellular: String? = null
            var other: String? = null
            for (n in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(n) ?: continue
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                val lp = cm.getLinkProperties(n) ?: continue
                val a = lp.linkAddresses.map { it.address }
                    .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
                    ?.hostAddress ?: continue
                when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> return a
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> if (cellular == null) cellular = a
                    else -> if (other == null) other = a
                }
            }
            cellular ?: other ?: "No IP"
        } catch (_: Exception) {
            "No IP"
        }
    }
}

/** Mengubah alamat IP jadi nama host lewat reverse DNS, di thread latar, hasilnya disimpan (cache). */
object HostResolver {
    private val cache = ConcurrentHashMap<String, String>() // ip -> nama host ("" = tidak ada)
    private val pending = ConcurrentHashMap.newKeySet<String>()
    private val pool = Executors.newFixedThreadPool(3)

    /** null = belum pernah dicari, "" = dicari tapi tidak ada nama. */
    fun cached(ip: String): String? = cache[ip]

    fun request(ip: String, onDone: () -> Unit) {
        if (cache.containsKey(ip) || !pending.add(ip)) return
        try {
            pool.execute {
                val host = try {
                    val h = InetAddress.getByName(ip).canonicalHostName
                    if (h == null || h == ip) "" else h
                } catch (_: Exception) {
                    ""
                }
                if (cache.size > 500) cache.clear()
                cache[ip] = host
                pending.remove(ip)
                onDone()
            }
        } catch (_: Exception) {
            pending.remove(ip)
        }
    }
}
