package com.example.netspeed

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var statusText: TextView
    private lateinit var toggleBtn: Button

    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContentView(buildUi())

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ------------------------------------------------------------------ aksi

    private fun refreshStatus() {
        val hasPerm = Settings.canDrawOverlays(this)
        val on = OverlayService.running
        statusText.text = when {
            !hasPerm -> "Izin \"Tampil di atas aplikasi lain\" belum diberikan."
            on -> "Meter sedang aktif dan mengambang di layar."
            else -> "Meter mati."
        }
        toggleBtn.text = if (on) "MATIKAN METER" else "NYALAKAN METER"
    }

    private fun toggle() {
        if (OverlayService.running) {
            prefs.enabled = false
            stopService(Intent(this, OverlayService::class.java))
            toggleBtn.postDelayed({ refreshStatus() }, 300)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin lalu kembali ke aplikasi ini", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        prefs.enabled = true
        startForegroundService(Intent(this, OverlayService::class.java))
        toggleBtn.postDelayed({ refreshStatus() }, 300)
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(32))
        }

        col.addView(TextView(this).apply {
            text = "Speed Meter"
            textSize = 26f
            setTextColor(Color.BLACK)
        })

        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(6), 0, dp(12))
        }
        col.addView(statusText)

        toggleBtn = Button(this).apply { setOnClickListener { toggle() } }
        col.addView(toggleBtn)

        col.addView(sectionTitle("Warna"))
        col.addView(colorSection("Download (↓)", { prefs.downColor }, { prefs.downColor = it }))
        col.addView(colorSection("Upload (↑)", { prefs.upColor }, { prefs.upColor = it }))
        col.addView(colorSection("Latar belakang", { prefs.bgColor }, { prefs.bgColor = it }))

        col.addView(sectionTitle("Tampilan"))
        col.addView(labeledSeek("Transparansi latar", 255, prefs.bgAlpha, { "${it * 100 / 255}%" }) {
            prefs.bgAlpha = it
        })
        col.addView(labeledSeek("Ukuran teks", 30, prefs.textSize - 8, { "${it + 8} sp" }) {
            prefs.textSize = it + 8
        })
        col.addView(
            labeledSeek("Interval pengukuran", 7, (prefs.intervalMs / 250 - 1).toInt(),
                { "${(it + 1) * 250} ms" }) {
                prefs.intervalMs = (it + 1) * 250L
            }
        )

        col.addView(sectionTitle("Opsi"))
        col.addView(toggleRow("Tampilkan dalam bit (Mbps)", prefs.useBits) { prefs.useBits = it })
        col.addView(toggleRow("Abaikan trafik VPN (cegah hitungan ganda)", prefs.ignoreVpn) { prefs.ignoreVpn = it })
        col.addView(toggleRow("Tampilkan upload", prefs.showUpload) { prefs.showUpload = it })
        col.addView(toggleRow("Kunci posisi (tidak bisa digeser)", prefs.locked) { prefs.locked = it })
        col.addView(toggleRow("Mulai otomatis setelah HP restart", prefs.autoStart) { prefs.autoStart = it })

        col.addView(TextView(this).apply {
            text = "Tip: seret meter di layar untuk memindahkan posisinya."
            textSize = 12f
            setPadding(0, dp(16), 0, 0)
        })

        return ScrollView(this).apply { addView(col) }
    }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 18f
        setTextColor(Color.BLACK)
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun seek(max: Int, progress: Int, onChange: (Int) -> Unit): SeekBar =
        SeekBar(this).apply {
            this.max = max
            this.progress = progress
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) onChange(p)
                }

                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }

    private fun labeledSeek(
        title: String,
        max: Int,
        progress: Int,
        label: (Int) -> String,
        onChange: (Int) -> Unit
    ): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tv = TextView(this).apply { text = "$title: ${label(progress)}" }
        box.addView(tv)
        box.addView(seek(max, progress) {
            tv.text = "$title: ${label(it)}"
            onChange(it)
        })
        return box
    }

    private fun toggleRow(title: String, initial: Boolean, onChange: (Boolean) -> Unit): View =
        Switch(this).apply {
            text = title
            isChecked = initial
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }

    /** Pemilih warna: kotak pratinjau + slider R/G/B + warna cepat. */
    private fun colorSection(title: String, get: () -> Int, set: (Int) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val preview = View(this).apply { setBackgroundColor(get()) }
        header.addView(TextView(this).apply { text = title }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(preview, LinearLayout.LayoutParams(dp(56), dp(28)))
        box.addView(header)

        val c0 = get()
        val sbs = arrayOfNulls<SeekBar>(3)
        fun apply() {
            val c = Color.rgb(sbs[0]!!.progress, sbs[1]!!.progress, sbs[2]!!.progress)
            preview.setBackgroundColor(c)
            set(c)
        }
        sbs[0] = seek(255, Color.red(c0)) { apply() }
        sbs[1] = seek(255, Color.green(c0)) { apply() }
        sbs[2] = seek(255, Color.blue(c0)) { apply() }
        sbs.forEach { box.addView(it) }

        val presets = intArrayOf(
            Color.WHITE, Color.parseColor("#4CAF50"), Color.CYAN, Color.YELLOW,
            Color.parseColor("#FF9800"), Color.RED, Color.MAGENTA, Color.BLACK
        )
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (p in presets) {
            val sw = View(this).apply {
                setBackgroundColor(p)
                setOnClickListener {
                    sbs[0]!!.progress = Color.red(p)
                    sbs[1]!!.progress = Color.green(p)
                    sbs[2]!!.progress = Color.blue(p)
                    preview.setBackgroundColor(p)
                    set(p)
                }
            }
            val lp = LinearLayout.LayoutParams(0, dp(30), 1f)
            lp.setMargins(dp(2), dp(6), dp(2), 0)
            row.addView(sw, lp)
        }
        box.addView(row)
        return box
    }
}
