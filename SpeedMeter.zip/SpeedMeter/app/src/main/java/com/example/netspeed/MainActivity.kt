package com.example.netspeed

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var usage: UsageStore
    private lateinit var statusText: TextView
    private lateinit var toggleBtn: Button
    private lateinit var tvToday: TextView
    private lateinit var tvWeek: TextView
    private lateinit var tvMonth: TextView
    private lateinit var bgImage: ImageView
    private lateinit var tvUsageAccess: TextView
    private lateinit var contentRoot: View

    private val ui = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable {
        override fun run() {
            refreshStatus()
            refreshUsage()
            ui.postDelayed(this, 2000L)
        }
    }

    private val bgFile get() = File(filesDir, "app_bg.jpg")

    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        usage = UsageStore(this)
        contentRoot = buildUi()
        setContentView(contentRoot)
        applyBackground()
        applyTextColor()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        ui.removeCallbacks(refresher)
        ui.post(refresher)
    }

    override fun onPause() {
        ui.removeCallbacks(refresher)
        super.onPause()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_BG && resultCode == RESULT_OK) {
            data?.data?.let { saveBackground(it) }
        }
    }

    // ------------------------------------------------------------------ warna teks aplikasi

    /** Terapkan warna teks pilihan ke semua tulisan di layar pengaturan (tombol dibiarkan). */
    private fun applyTextColor() {
        tint(contentRoot, prefs.appTextColor)
    }

    private fun tint(v: View, c: Int) {
        if (v is Button) return
        if (v is TextView) v.setTextColor(c)
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) tint(v.getChildAt(i), c)
        }
    }

    // ------------------------------------------------------------------ aksi

    private fun refreshStatus() {
        val hasPerm = Settings.canDrawOverlays(this)
        val on = OverlayService.running
        statusText.text = when {
            !hasPerm -> "Izin \"Tampil di atas aplikasi lain\" belum diberikan."
            on -> "Meter sedang aktif dan mengambang di layar."
            else -> "Meter mati."
        }
        toggleBtn.text = if (on) "MATIKAN METER" else "NYALAKAN METER"
        tvUsageAccess.text = if (hasUsageAccess(this)) {
            "Akses penggunaan: sudah diizinkan."
        } else {
            "Akses penggunaan: belum diizinkan."
        }
    }

    private fun toggle() {
        if (OverlayService.running) {
            prefs.enabled = false
            stopService(Intent(this, OverlayService::class.java))
            toggleBtn.postDelayed({ refreshStatus() }, 300)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin lalu kembali ke aplikasi ini", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        prefs.enabled = true
        startForegroundService(Intent(this, OverlayService::class.java))
        toggleBtn.postDelayed({ refreshStatus() }, 300)
    }

    private fun usageText(title: String, u: UsageStore.Usage): String =
        "$title\nWi-Fi: ${SpeedSampler.formatSize(u.wifi)}  \u2022  " +
            "Data: ${SpeedSampler.formatSize(u.mobile)}  \u2022  " +
            "Total: ${SpeedSampler.formatSize(u.total)}"

    private fun refreshUsage() {
        tvToday.text = usageText("Hari ini", usage.today())
        tvWeek.text = usageText("Minggu ini (mulai Senin)", usage.week())
        tvMonth.text = usageText("Bulan ini", usage.month())
    }

    // ------------------------------------------------------------------ latar belakang

    private fun pickBackground() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        try {
            startActivityForResult(i, REQ_BG)
        } catch (_: Exception) {
            try {
                val alt = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                startActivityForResult(Intent.createChooser(alt, "Pilih gambar"), REQ_BG)
            } catch (_: Exception) {
                Toast.makeText(this, "Tidak ada aplikasi galeri/pemilih file", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Ambil gambar, kecilkan (maks 1600 px), putar sesuai EXIF, simpan di penyimpanan aplikasi. */
    private fun saveBackground(uri: Uri) {
        Toast.makeText(this, "Memproses gambar\u2026", Toast.LENGTH_SHORT).show()
        Thread {
            var error: String? = null
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException("gambar tidak terbaca")
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2

                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, opts)
                } ?: throw IllegalStateException("gambar tidak terbaca")

                val orientation = try {
                    contentResolver.openInputStream(uri)?.use {
                        ExifInterface(it).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                        )
                    } ?: ExifInterface.ORIENTATION_NORMAL
                } catch (_: Exception) {
                    ExifInterface.ORIENTATION_NORMAL
                }
                val degrees = when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
                if (degrees != 0f) {
                    val m = Matrix().apply { postRotate(degrees) }
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                }

                bgFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            } catch (e: Throwable) {
                error = e.message ?: e.javaClass.simpleName
            }
            runOnUiThread {
                if (error != null) {
                    Toast.makeText(this, "Gagal memakai gambar: $error", Toast.LENGTH_LONG).show()
                } else {
                    applyBackground()
                }
            }
        }.start()
    }

    private fun removeBackground() {
        bgFile.delete()
        applyBackground()
    }

    private fun applyBackground() {
        if (bgFile.exists()) {
            val bmp = BitmapFactory.decodeFile(bgFile.absolutePath)
            if (bmp != null) {
                bgImage.setImageBitmap(bmp)
                bgImage.visibility = View.VISIBLE // gambar tampil apa adanya, tanpa lapisan putih
                return
            }
        }
        bgImage.setImageDrawable(null)
        bgImage.visibility = View.GONE // tanpa gambar: latar putih (warna dasar frame)
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(32))
        }

        col.addView(TextView(this).apply {
            text = "Speed Meter"
            textSize = 26f
            setTextColor(Color.BLACK)
        })

        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(6), 0, dp(12))
        }
        col.addView(statusText)

        toggleBtn = Button(this).apply { setOnClickListener { toggle() } }
        col.addView(toggleBtn)

        col.addView(sectionTitle("Total pemakaian data"))
        tvToday = TextView(this).apply { setPadding(0, dp(4), 0, dp(8)) }
        tvWeek = TextView(this).apply { setPadding(0, dp(4), 0, dp(8)) }
        tvMonth = TextView(this).apply { setPadding(0, dp(4), 0, dp(8)) }
        col.addView(tvToday)
        col.addView(tvWeek)
        col.addView(tvMonth)
        col.addView(TextView(this).apply {
            text = "Dihitung hanya saat meter aktif (perkiraan, bukan kuota resmi operator)."
            textSize = 12f
        })

        col.addView(sectionTitle("Latar belakang aplikasi"))
        val bgRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bgRow.addView(Button(this).apply {
            text = "Pilih gambar"
            setOnClickListener { pickBackground() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bgRow.addView(Button(this).apply {
            text = "Hapus gambar"
            setOnClickListener { removeBackground() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(bgRow)

        col.addView(sectionTitle("Jaringan yang diukur"))
        col.addView(radioRow("Tampilkan kecepatan dari", listOf("Semua (Wi-Fi + data)", "Hanya Wi-Fi", "Hanya data seluler"), prefs.netFilter) {
            prefs.netFilter = it
        })

        col.addView(sectionTitle("Warna"))
        col.addView(colorSection("Teks di aplikasi ini", { prefs.appTextColor }, {
            prefs.appTextColor = it
            applyTextColor()
        }))
        col.addView(toggleRow("Warna pelangi otomatis (berubah-ubah saat internet tersambung)", prefs.rainbow) {
            prefs.rainbow = it
        })
        col.addView(colorSection("Download (↓)", { prefs.downColor }, { prefs.downColor = it }))
        col.addView(colorSection("Upload (↑)", { prefs.upColor }, { prefs.upColor = it }))
        col.addView(colorSection("Latar belakang", { prefs.bgColor }, { prefs.bgColor = it }))

        col.addView(sectionTitle("Tampilan"))
        col.addView(radioRow("Ketebalan huruf", listOf("Normal", "Tebal", "Tebal banget"), prefs.textWeight) {
            prefs.textWeight = it
        })
        col.addView(radioRow("Panah saat ada trafik", listOf("Mati", "Menyala", "Berkedip"), prefs.arrowMode) {
            prefs.arrowMode = it
        })
        col.addView(labeledSeek("Transparansi latar", 255, prefs.bgAlpha, { "${it * 100 / 255}%" }) {
            prefs.bgAlpha = it
        })
        col.addView(labeledSeek("Ukuran teks", 30, prefs.textSize - 8, { "${it + 8} sp" }) {
            prefs.textSize = it + 8
        })
        col.addView(
            labeledSeek("Interval pengukuran", 7, (prefs.intervalMs / 250 - 1).toInt(),
                { "${(it + 1) * 250} ms" }) {
                prefs.intervalMs = (it + 1) * 250L
            }
        )

        col.addView(sectionTitle("Panel trafik (ketuk meter)"))
        col.addView(TextView(this).apply {
            text = "Ketuk meter yang mengambang untuk melihat grafik naik-turun, aplikasi yang " +
                "sedang memakai internet, dan alamat yang diakses. Trafik per aplikasi butuh izin " +
                "\"Akses penggunaan\"."
            textSize = 13f
            setPadding(0, dp(4), 0, dp(6))
        })
        tvUsageAccess = TextView(this).apply { setPadding(0, 0, 0, dp(4)) }
        col.addView(tvUsageAccess)
        col.addView(Button(this).apply {
            text = "Buka pengaturan Akses penggunaan"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Pengaturan tidak ditemukan", Toast.LENGTH_LONG).show()
                }
            }
        })

        col.addView(toggleRow("Alamat via root (minta akses su, untuk melihat alamat yang diakses)", prefs.rootAddr) { on ->
            prefs.rootAddr = on
            if (on) {
                // Memancing dialog izin root (Magisk/KernelSU) sekarang juga.
                Thread {
                    val ok = RootShell.run("id") != null
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            if (ok) "Akses root diberikan" else "Akses root ditolak / tidak ada root",
                            Toast.LENGTH_LONG
                        ).show()
                        if (!ok) prefs.rootAddr = false
                    }
                }.start()
            }
        })

        col.addView(toggleRow("Tampilkan nama host (subdomain) bukan IP, lewat reverse DNS", prefs.resolveHost) { prefs.resolveHost = it })

        col.addView(sectionTitle("Notifikasi: IP, sinyal, band"))
        col.addView(TextView(this).apply {
            text = "Notifikasi menampilkan IP lokal. dBm dan band dibaca lewat root (dumpsys), sama seperti script Termux."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        })
        col.addView(toggleRow("Tampilkan dBm & band di notifikasi (butuh root)", prefs.rootSignal) { on ->
            prefs.rootSignal = on
            if (on) {
                Thread {
                    val ok = RootShell.run("id") != null
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            if (ok) "Akses root diberikan" else "Akses root ditolak / tidak ada root",
                            Toast.LENGTH_LONG
                        ).show()
                        if (!ok) prefs.rootSignal = false
                    }
                }.start()
            }
        })

        col.addView(sectionTitle("Opsi"))
        col.addView(toggleRow("Tampilkan dalam bit (Mbps)", prefs.useBits) { prefs.useBits = it })
        col.addView(toggleRow("Saat VPN aktif, ukur level aplikasi (sama seperti 1DM+)", prefs.vpnAppLevel) { prefs.vpnAppLevel = it })
        col.addView(toggleRow("Tampilkan upload", prefs.showUpload) { prefs.showUpload = it })
        col.addView(toggleRow("Kunci posisi (tidak bisa digeser)", prefs.locked) { prefs.locked = it })
        col.addView(toggleRow("Kunci ukuran (cubit dua jari tidak mengubah ukuran)", prefs.lockResize) { prefs.lockResize = it })
        col.addView(TextView(this).apply {
            text = "Ukuran meter: cubit dua jari pada meter untuk mengecilkan, rentangkan untuk membesarkan."
            textSize = 12f
        })
        col.addView(Button(this).apply {
            text = "Reset ukuran meter"
            setOnClickListener { prefs.overlayScale = 1f }
        })
        col.addView(toggleRow("Mulai otomatis setelah HP restart", prefs.autoStart) { prefs.autoStart = it })

        col.addView(TextView(this).apply {
            text = "Tip: seret meter di layar untuk memindahkan posisinya."
            textSize = 12f
            setPadding(0, dp(16), 0, 0)
        })

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        bgImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
        }
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        frame.addView(bgImage, FrameLayout.LayoutParams(match, match))
        frame.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(match, match))
        return frame
    }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 18f
        setTextColor(Color.BLACK)
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun seek(max: Int, progress: Int, onChange: (Int) -> Unit): SeekBar =
        SeekBar(this).apply {
            this.max = max
            this.progress = progress
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) onChange(p)
                }

                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }

    private fun labeledSeek(
        title: String,
        max: Int,
        progress: Int,
        label: (Int) -> String,
        onChange: (Int) -> Unit
    ): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tv = TextView(this).apply { text = "$title: ${label(progress)}" }
        box.addView(tv)
        box.addView(seek(max, progress) {
            tv.text = "$title: ${label(it)}"
            onChange(it)
        })
        return box
    }

    private fun radioRow(
        title: String,
        options: List<String>,
        selected: Int,
        onSelect: (Int) -> Unit
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        box.addView(TextView(this).apply { text = title })
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        val ids = ArrayList<Int>()
        options.forEach { label ->
            val rb = RadioButton(this)
            rb.text = label
            rb.id = View.generateViewId()
            ids.add(rb.id)
            group.addView(rb)
        }
        group.check(ids[selected.coerceIn(0, ids.size - 1)])
        group.setOnCheckedChangeListener { _, checkedId ->
            val idx = ids.indexOf(checkedId)
            if (idx >= 0) onSelect(idx)
        }
        box.addView(group)
        return box
    }

    private fun toggleRow(title: String, initial: Boolean, onChange: (Boolean) -> Unit): View =
        Switch(this).apply {
            text = title
            isChecked = initial
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }

    /** Pemilih warna: kotak pratinjau + slider R/G/B + warna cepat. */
    private fun colorSection(title: String, get: () -> Int, set: (Int) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val preview = View(this).apply { setBackgroundColor(get()) }
        header.addView(TextView(this).apply { text = title }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(preview, LinearLayout.LayoutParams(dp(56), dp(28)))
        box.addView(header)

        val c0 = get()
        val sbs = arrayOfNulls<SeekBar>(3)
        fun apply() {
            val c = Color.rgb(sbs[0]!!.progress, sbs[1]!!.progress, sbs[2]!!.progress)
            preview.setBackgroundColor(c)
            set(c)
        }
        sbs[0] = seek(255, Color.red(c0)) { apply() }
        sbs[1] = seek(255, Color.green(c0)) { apply() }
        sbs[2] = seek(255, Color.blue(c0)) { apply() }
        sbs.forEach { box.addView(it) }

        val presets = intArrayOf(
            Color.WHITE, Color.parseColor("#4CAF50"), Color.CYAN, Color.YELLOW,
            Color.parseColor("#FF9800"), Color.RED, Color.MAGENTA, Color.BLACK
        )
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (p in presets) {
            val sw = View(this).apply {
                setBackgroundColor(p)
                setOnClickListener {
                    sbs[0]!!.progress = Color.red(p)
                    sbs[1]!!.progress = Color.green(p)
                    sbs[2]!!.progress = Color.blue(p)
                    preview.setBackgroundColor(p)
                    set(p)
                }
            }
            val lp = LinearLayout.LayoutParams(0, dp(30), 1f)
            lp.setMargins(dp(2), dp(6), dp(2), 0)
            row.addView(sw, lp)
        }
        box.addView(row)
        return box
    }

    companion object {
        private const val REQ_BG = 42
    }
}
