package com.example.netspeed

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.net.InetAddress
import java.util.Calendar

/** Apakah izin "Akses penggunaan" (Usage Access) sudah diberikan? Dibutuhkan untuk trafik per aplikasi. */
@Suppress("DEPRECATION")
fun hasUsageAccess(ctx: Context): Boolean {
    return try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(
                "android:get_usage_stats", Process.myUid(), ctx.packageName
            )
        } else {
            ops.checkOpNoThrow(
                "android:get_usage_stats", Process.myUid(), ctx.packageName
            )
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
        false
    }
}

/**
 * Membaca daftar koneksi TCP yang sedang terhubung dari /proc/net.
 * Android 10+ memblokir file ini untuk aplikasi biasa, jadi hasilnya null di HP modern.
 */
object ConnectionReader {
    class Conn(val ip: String, val port: Int, val uid: Int = -1)

    /** Parse isi gabungan /proc/net/tcp dan /proc/net/tcp6 (mis. hasil `su -c cat`). */
    fun parseAll(text: String): List<Conn> {
        val seen = LinkedHashSet<String>()
        val list = ArrayList<Conn>()
        for (line in text.lineSequence()) {
            val c = parse(line) ?: continue
            if (seen.add(c.uid.toString() + "|" + c.ip + ":" + c.port)) list.add(c)
        }
        return list
    }

    fun read(): List<Conn>? {
        val seen = LinkedHashSet<String>()
        val list = ArrayList<Conn>()
        var readable = false
        for (path in arrayOf("/proc/net/tcp6", "/proc/net/tcp")) {
            try {
                File(path).bufferedReader().use { br ->
                    val head = br.readLine()
                    if (head != null) readable = true
                    var line = br.readLine()
                    while (line != null) {
                        val c = parse(line)
                        if (c != null && seen.add(c.ip + ":" + c.port)) list.add(c)
                        line = br.readLine()
                    }
                }
            } catch (_: Exception) {
            }
        }
        return if (readable) list.take(6) else null
    }

    private fun parse(line: String): Conn? {
        val f = line.trim().split(Regex("\\s+"))
        if (f.size < 4 || f[3] != "01") return null // 01 = ESTABLISHED
        val rem = f[2].split(":")
        if (rem.size != 2) return null
        val port = rem[1].toIntOrNull(16) ?: return null
        val words = rem[0].chunked(8)
        if (words.size != 1 && words.size != 4) return null
        val bytes = ByteArray(words.size * 4)
        for ((i, w) in words.withIndex()) {
            val v = w.toLongOrNull(16) ?: return null
            bytes[i * 4] = (v and 0xFF).toByte()
            bytes[i * 4 + 1] = ((v shr 8) and 0xFF).toByte()
            bytes[i * 4 + 2] = ((v shr 16) and 0xFF).toByte()
            bytes[i * 4 + 3] = ((v shr 24) and 0xFF).toByte()
        }
        val addr = try {
            InetAddress.getByAddress(bytes)
        } catch (_: Exception) {
            return null
        }
        if (addr.isLoopbackAddress || addr.isAnyLocalAddress) return null
        val ip = addr.hostAddress ?: return null
        return Conn(ip, port, f.getOrNull(7)?.toIntOrNull() ?: -1)
    }

    fun portHint(port: Int): String = when (port) {
        443 -> "HTTPS"
        80 -> "HTTP"
        53 -> "DNS"
        5228, 5229, 5230 -> "Google / FCM"
        993, 143 -> "IMAP"
        465, 587 -> "SMTP"
        8080 -> "HTTP"
        else -> ""
    }
}

/** Menjalankan perintah lewat root (su). Harus dipanggil dari thread latar. */
object RootShell {
    fun run(cmd: String): String? {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            if (code == 0 && out.isNotEmpty()) out else null
        } catch (_: Exception) {
            null
        }
    }

    fun readConnections(): String? = run("cat /proc/net/tcp /proc/net/tcp6")

    /** Seperti run(), tapi hasilnya dipakai walau kode keluar bukan 0 (dumpsys kadang begitu). */
    fun runAny(cmd: String): String? {
        val proc = try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        } catch (_: Exception) {
            return null
        }
        return try {
            val out = proc.inputStream.bufferedReader().readText()
            proc.waitFor()
            if (out.isNotBlank()) out else null
        } catch (_: Exception) {
            null
        } finally {
            try {
                proc.destroy()
            } catch (_: Exception) {
            }
        }
    }
}

/**
 * Pembungkus yang mengecilkan / membesarkan SELURUH isi panel (grafik, daftar aplikasi, alamat)
 * dengan cubit dua jari. Ukuran jendela ikut berubah, sentuhan dipetakan otomatis oleh View.scaleX/Y.
 */
class ScaleFrame(context: Context) : FrameLayout(context) {

    var contentScale = 1f
        set(v) {
            field = v
            applyScale()
            requestLayout()
        }
    var pinchEnabled = true
    var minScale = 0.1f
    var maxScale = 2.5f
    var onUserScale: ((Float) -> Unit)? = null
    var onTouched: (() -> Unit)? = null

    /** Geser seluruh panel dengan satu jari di bagian mana pun (termasuk grafik & daftar hostname). */
    var onDragStart: (() -> Unit)? = null
    var onDragMove: ((dx: Float, dy: Float) -> Unit)? = null
    /** Bila tidak null: sentuhan yang dimulai di dalam view ini TIDAK menggeser panel (dipakai grafik saat mode zoom grafik). */
    var dragExemptView: View? = null

    /** Ukuran isi sebelum diskalakan (px). */
    val contentWidth: Int get() = getChildAt(0)?.measuredWidth ?: 0
    val contentHeight: Int get() = getChildAt(0)?.measuredHeight ?: 0

    private var multi = false
    private var dragging = false
    private var exempt = false
    private var downRawX = 0f
    private var downRawY = 0f
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private fun insideExempt(rx: Float, ry: Float): Boolean {
        val v = dragExemptView ?: return false
        if (v.visibility != VISIBLE) return false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return rx >= loc[0] && rx <= loc[0] + v.width * contentScale &&
            ry >= loc[1] && ry <= loc[1] + v.height * contentScale
    }

    private val det = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val ns = (contentScale * d.scaleFactor).coerceIn(minScale, maxScale)
                if (ns != contentScale) {
                    contentScale = ns
                    onUserScale?.invoke(ns)
                }
                return true
            }
        })

    init {
        clipChildren = false
        clipToPadding = false
        det.isQuickScaleEnabled = false
    }

    private fun applyScale() {
        val c = getChildAt(0) ?: return
        c.pivotX = 0f
        c.pivotY = 0f
        c.scaleX = contentScale
        c.scaleY = contentScale
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val c = getChildAt(0)
        if (c == null || c.visibility == GONE) {
            setMeasuredDimension(0, 0)
            return
        }
        val lpw = c.layoutParams.width
        val cw = if (lpw > 0) MeasureSpec.makeMeasureSpec(lpw, MeasureSpec.EXACTLY)
        else MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        c.measure(cw, MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        setMeasuredDimension(
            (c.measuredWidth * contentScale + 0.5f).toInt(),
            (c.measuredHeight * contentScale + 0.5f).toInt()
        )
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val c = getChildAt(0) ?: return
        c.layout(0, 0, c.measuredWidth, c.measuredHeight)
        applyScale()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        onTouched?.invoke()
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false
                dragging = false
                downRawX = ev.rawX
                downRawY = ev.rawY
                exempt = insideExempt(ev.rawX, ev.rawY)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // Jari kedua: hentikan geser, serahkan ke cubit.
                if (dragging) dragging = false
            }
        }

        // ---- geser panel dengan 1 jari (di mana saja) ----
        if (dragging) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE ->
                    if (ev.pointerCount == 1) onDragMove?.invoke(ev.rawX - downRawX, ev.rawY - downRawY)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
            }
            return true
        }
        if (!multi && !exempt && ev.pointerCount == 1 &&
            ev.actionMasked == MotionEvent.ACTION_MOVE &&
            (Math.abs(ev.rawX - downRawX) > slop || Math.abs(ev.rawY - downRawY) > slop)
        ) {
            dragging = true
            val cancel = MotionEvent.obtain(ev)
            cancel.action = MotionEvent.ACTION_CANCEL
            super.dispatchTouchEvent(cancel)
            cancel.recycle()
            onDragStart?.invoke()
            onDragMove?.invoke(ev.rawX - downRawX, ev.rawY - downRawY)
            return true
        }

        // ---- cubit 2 jari = ubah ukuran seluruh panel ----
        if (!pinchEnabled) return super.dispatchTouchEvent(ev)
        det.onTouchEvent(ev)
        if (!multi && ev.pointerCount > 1) {
            multi = true
            val cancel = MotionEvent.obtain(ev)
            cancel.action = MotionEvent.ACTION_CANCEL
            super.dispatchTouchEvent(cancel)
            cancel.recycle()
        }
        if (multi) return true
        return super.dispatchTouchEvent(ev)
    }
}

/**
 * Panel yang muncul saat meter mengambang diketuk: grafik naik-turun, aplikasi yang sedang memakai
 * internet (lewat NetworkStatsManager, butuh izin Akses penggunaan), dan alamat yang sedang diakses.
 *
 * Panel TIDAK hilang saat layar di luarnya disentuh. Tutup dengan tombol X atau ketuk meter lagi.
 */
/** UID semu untuk trafik yang hanya diketahui lewat VPN. */
private const val VPN_FALLBACK_UID = -1000

/** UID semu untuk trafik yang tidak terbaca per aplikasi (tanpa VPN). */
private const val NET_FALLBACK_UID = -1001

class TrafficPanel(
    private val ctx: Context,
    private val wm: WindowManager,
    private val prefs: Prefs,
    private val history: SpeedHistory,
    private val windowType: Int = Compat.overlayWindowType()
) {
    private val ui = Handler(Looper.getMainLooper())
    private val pm = ctx.packageManager
    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val green = Color.parseColor("#00C853")
    private val red = Color.parseColor("#FF5252")
    private val amber = Color.parseColor("#FFB300")
    private val grey = Color.argb(200, 255, 255, 255)

    private var frame: ScaleFrame? = null
    private var card: LinearLayout? = null
    private var winLp: WindowManager.LayoutParams? = null
    private var graph: SpeedGraphView? = null
    private var tvDown: TextView? = null
    private var tvUp: TextView? = null
    private var tvSpan: TextView? = null
    private var tvPing: TextView? = null
    private var tvMode: TextView? = null
    private var pingBusy = false
    private var appsBox: LinearLayout? = null
    private var addrBox: LinearLayout? = null

    private var baseWidth = 0
    private var screenW = 0
    private var usableH = 0
    private var anchorTop = true
    private var anchorY = 0
    private var anchorH = 0
    private var lastTouchMs = 0L
    private var lastAddrSig = ""
    private var graphPinch = false
    private var dragged = false
    private var dragSx = 0
    private var dragSy = 0
    private var dragTx = 0f
    private var dragTy = 0f

    var lastHideMs = 0L
        private set
    val isShowing: Boolean get() = frame != null

    private val typeface: Typeface get() = Fonts.typeface(prefs.fontOf(Area.GRAPH), 0)
    private val typefaceBold: Typeface get() = Fonts.typeface(prefs.fontOf(Area.GRAPH), 1)

    private val sweeper = RainbowSweeper(
        enabled = { prefs.rainbowGraph },
        views = {
            val out = ArrayList<TextView>()
            frame?.let { Rainbow.collect(it, out) }
            out
        },
        restore = { tv -> (tv.tag as? Int)?.let { tv.setTextColor(it) } },
        speed = { prefs.rainbowSpeedPanel }
    )

    // pengukuran per aplikasi
    private var prev: Map<Int, LongArray>? = null
    private var prevT = 0L
    private var prevDay = 0L
    private val rates = HashMap<Int, DoubleArray>() // uid -> [unduh B/s, unggah B/s]
    private val session = HashMap<Int, LongArray>() // uid -> [unduh, unggah] sejak panel dibuka
    private var rootOk: Boolean? = null // null = belum ada jawaban
    private var rootConns: List<ConnectionReader.Conn> = emptyList()
    private var rootBusy = false
    private val labelCache = HashMap<Int, Pair<String, Drawable?>>()

    /** Ping ke Google tiap 3 detik selama panel terbuka. */
    private val pinger = object : Runnable {
        override fun run() {
            if (frame == null) return
            if (!pingBusy) {
                pingBusy = true
                Thread {
                    val ms = Pinger.pingGoogle()
                    ui.post {
                        pingBusy = false
                        showPing(ms)
                    }
                }.start()
            }
            ui.postDelayed(this, 3000L)
        }
    }

    private fun showPing(ms: Int?) {
        val t = tvPing ?: return
        val c = if (ms == null) red else when {
            ms < 80 -> green
            ms < 200 -> amber
            else -> red
        }
        t.text = if (ms == null) "Ping Google: tidak ada respon" else "Ping Google: $ms ms"
        t.tag = c
        t.setTextColor(c)
    }

    private fun copyText(s: String) {
        try {
            val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cb.setPrimaryClip(ClipData.newPlainText("alamat", s))
            Toast.makeText(ctx, "Disalin: $s", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Gagal menyalin", Toast.LENGTH_SHORT).show()
        }
    }

    private val poller = object : Runnable {
        override fun run() {
            pollApps()
            refreshLists()
            refit()
            ui.postDelayed(this, 2000L)
        }
    }

    // ------------------------------------------------------------------ ukuran panel

    private fun scaleBy(delta: Float) {
        val f = frame ?: return
        val ns = (f.contentScale + delta).coerceIn(f.minScale, f.maxScale)
        f.contentScale = ns
        prefs.panelScale = ns
        reposition()
    }

    /** Hitung batas skala supaya panel muat di layar (tidak menutupi tombol navigasi), lalu terapkan. */
    private fun refit() {
        val f = frame ?: return
        val ch = f.contentHeight
        if (ch <= 0 || baseWidth <= 0) return
        val availH = if (dragged) {
            usableH - (winLp?.y ?: 0) - dp(4)
        } else if (anchorTop) {
            usableH - (anchorY + anchorH + dp(6)) - dp(4)
        } else {
            anchorY - dp(6) - dp(4)
        }
        val fitH = availH.toFloat() / ch
        val fitW = screenW.toFloat() / baseWidth
        val mx = minOf(2.5f, fitW * 0.98f, fitH).coerceAtLeast(f.minScale)
        f.maxScale = mx
        val want = prefs.panelScale.coerceIn(f.minScale, mx)
        if (Math.abs(f.contentScale - want) > 0.001f) f.contentScale = want
        reposition()
    }

    private fun reposition() {
        val f = frame ?: return
        val lp = winLp ?: return
        val w = (baseWidth * f.contentScale).toInt()
        if (!dragged) lp.x = ((screenW - w) / 2).coerceAtLeast(0)
        else lp.x = lp.x.coerceIn(0, (screenW - w).coerceAtLeast(0))
        try {
            wm.updateViewLayout(f, lp)
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ tampil / sembunyi

    fun show(anchorYPx: Int, anchorHPx: Int) {
        if (frame != null) return
        rootOk = null
        rootConns = emptyList()
        prev = null
        rates.clear()
        session.clear()
        prevUid = null
        polls = 0
        estRates.clear()
        estSession.clear()
        fgPkg = null
        fgQueryAt = 0L
        fallbackActive = false
        hideTether = false
        lastAddrSig = ""
        graphPinch = false
        dragged = false

        val (sw, sh) = Compat.realScreenSize(wm)
        screenW = sw
        usableH = Compat.usableHeight(ctx, wm, prefs.safeNav)
        baseWidth = minOf(sw - dp(16), dp(380))
        anchorY = anchorYPx
        anchorH = anchorHPx
        anchorTop = anchorYPx + anchorHPx / 2 < sh / 2

        val c = build()
        card = c
        val f = ScaleFrame(ctx)
        f.addView(c, FrameLayout.LayoutParams(baseWidth, FrameLayout.LayoutParams.WRAP_CONTENT))
        f.contentScale = prefs.panelScale.coerceIn(0.1f, 2.5f)
        f.onUserScale = { s ->
            prefs.panelScale = s
            reposition()
        }
        f.onTouched = { lastTouchMs = SystemClock.elapsedRealtime() }
        f.onDragStart = {
            val lp0 = winLp
            if (lp0 != null) {
                if (!dragged) {
                    val loc = IntArray(2)
                    f.getLocationOnScreen(loc)
                    lp0.gravity = Gravity.TOP or Gravity.START
                    lp0.x = loc[0]
                    lp0.y = loc[1]
                    dragged = true
                }
                dragSx = lp0.x
                dragSy = lp0.y
            }
        }
        f.onDragMove = { dx, dy ->
            val lp0 = winLp
            if (lp0 != null) {
                val w = f.width
                val h = f.height
                lp0.x = (dragSx + dx).toInt().coerceIn(0, (screenW - w).coerceAtLeast(0))
                lp0.y = (dragSy + dy).toInt().coerceIn(0, (usableH - h).coerceAtLeast(0))
                try { wm.updateViewLayout(f, lp0) } catch (e: Exception) { android.util.Log.w("TrafficPanel", "drag gagal", e) }
            }
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            // Tanpa FLAG_WATCH_OUTSIDE_TOUCH: menyentuh layar di luar panel tidak menutup panel.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            x = (sw - baseWidth) / 2
            if (anchorTop) {
                gravity = Gravity.TOP or Gravity.START
                y = anchorYPx + anchorHPx + dp(6)
            } else {
                gravity = Gravity.BOTTOM or Gravity.START
                y = (sh - anchorYPx + dp(6)).coerceAtLeast(0)
            }
        }
        winLp = lp

        try {
            wm.addView(f, lp)
        } catch (_: Exception) {
            winLp = null
            card = null
            return
        }
        frame = f
        onSample()
        ui.removeCallbacks(poller)
        ui.post(poller)
        ui.removeCallbacks(pinger)
        ui.post(pinger)
        sweeper.start()
        f.post { refit() }
    }

    fun hide() {
        ui.removeCallbacks(poller)
        ui.removeCallbacks(pinger)
        sweeper.stop()
        val v = frame ?: return
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
        frame = null
        card = null
        winLp = null
        graph = null
        tvDown = null
        tvUp = null
        tvSpan = null
        tvPing = null
        tvMode = null
        appsBox = null
        addrBox = null
        lastHideMs = SystemClock.elapsedRealtime()
    }

    /** Dipanggil service tiap ada sampel kecepatan baru. */
    fun onSample() {
        val g = graph ?: return
        val n = history.size
        if (n == 0) return
        val bits = prefs.useBits
        g.useBits = bits
        g.showUp = prefs.showUpload
        g.intervalMs = prefs.intervalMs
        g.rainbowText = prefs.rainbowGraph
        g.rainbowSpeed = prefs.rainbowSpeedPanel
        g.dotBlink = prefs.dotBlink
        g.dotCustom = prefs.dotCustom
        g.dotColorValue = prefs.dotColor
        g.onSampleAdded()

        tvDown?.apply {
            text = "\u2193 " + SpeedSampler.format(history.down[n - 1], bits)
            val c = if (history.trendUp()) green else red
            tag = c
            setTextColor(c)
        }
        tvUp?.apply {
            visibility = if (prefs.showUpload) View.VISIBLE else View.GONE
            text = "\u2191 " + SpeedSampler.format(history.up[n - 1], bits)
        }
        val secs = (g.visibleCount * prefs.intervalMs / 1000f).toInt()
        tvSpan?.text = "Rentang \u00B1${secs} detik  \u2022  hijau = naik, merah = turun, biru = lurus"
    }

    // ------------------------------------------------------------------ UI

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(color)
            tag = color
            includeFontPadding = false
            typeface = if (bold) typefaceBold else typeface
        }

    private fun smallButton(label: String, onClick: () -> Unit): TextView =
        text(label, 12f, Color.WHITE, true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = 8f * d
                setColor(Color.argb(70, 255, 255, 255))
            }
            setOnClickListener { onClick() }
        }

    private fun build(): LinearLayout {
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = 18f * d
                setColor(Color.argb(240, 14, 18, 24))
            }
        }

        // judul + tombol tutup
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            text("\u2630 Trafik jaringan \u2022 geser di mana saja", 14f, Color.WHITE, true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(text("\u2715", 20f, Color.WHITE, true).apply {
            setPadding(dp(16), dp(4), dp(4), dp(4))
            setOnClickListener { hide() }
        })
        card.addView(header)

        // angka saat ini
        val stats = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(6))
        }
        val down = text("\u2193 -", 20f, green, true)
        val up = text("\u2191 -", 14f, amber, true)
        stats.addView(down, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        stats.addView(up)
        card.addView(stats)
        tvDown = down
        tvUp = up

        // grafik
        val g = SpeedGraphView(ctx, history)
        g.textTypeface = typeface
        g.pinchEnabled = false
        card.addView(g, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(prefs.graphHeightDp)))
        graph = g

        val span = text("", 10f, grey)
        card.addView(span, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(4) })
        tvSpan = span

        // tombol ukuran panel
        val ctl = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
        }
        fun add(v: View) {
            ctl.addView(v, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(6) })
        }
        add(smallButton("\u2796 Kecil") { scaleBy(-0.1f) })
        add(smallButton("\u2795 Besar") { scaleBy(0.1f) })
        add(smallButton("\u27F2 Grafik") { graph?.resetView() })
        card.addView(ctl)

        val mode = smallButton("") { toggleGraphPinch() }
        mode.text = "Cubit 2 jari: seluruh panel"
        tvMode = mode
        card.addView(mode, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })

        card.addView(text(
            "Cubit = kecilkan / besarkan seluruh panel  \u2022  geser 1 jari di mana saja = pindahkan panel  \u2022  ketuk 2x grafik = reset  \u2022  tutup dengan \u2715 atau ketuk meter lagi",
            10f, grey
        ).apply { setPadding(0, dp(6), 0, 0) })
        val ping = text("Ping Google: \u2026", 10f, grey, true).apply {
            setPadding(0, dp(3), 0, 0)
        }
        card.addView(ping)
        tvPing = ping

        // aplikasi
        card.addView(text("Aplikasi yang memakai internet", 12f, grey, true).apply {
            setPadding(0, dp(14), 0, dp(4))
        })
        val apps = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        card.addView(apps)
        appsBox = apps

        // alamat
        card.addView(text("Alamat yang sedang diakses", 12f, grey, true).apply {
            setPadding(0, dp(14), 0, 0)
        })
        card.addView(text("Tombol Salin di sebelah kanan  \u2022  ketuk baris = salin nama  \u2022  tahan = salin IP:port", 10f, grey).apply {
            setPadding(0, dp(1), 0, dp(4))
        })
        val addr = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        card.addView(addr)
        addrBox = addr

        return card
    }

    /** Pilih apa yang dikendalikan cubit dua jari: seluruh panel, atau hanya zoom grafik. */
    private fun toggleGraphPinch() {
        graphPinch = !graphPinch
        frame?.pinchEnabled = !graphPinch
        graph?.pinchEnabled = graphPinch
        frame?.dragExemptView = if (graphPinch) graph else null
        tvMode?.text = if (graphPinch) "Cubit 2 jari: zoom grafik (geser grafik = isi grafik)" else "Cubit 2 jari: seluruh panel"
    }

    private fun note(t: String): TextView = text(t, 11f, grey).apply {
        setPadding(0, dp(2), 0, dp(2))
    }

    private fun refreshLists() {
        refreshApps()
        refreshAddresses()
    }

    private fun refreshApps() {
        val box = appsBox ?: return
        // Jangan bangun ulang daftar saat jari sedang menyentuh panel (membatalkan ketukan).
        if (SystemClock.elapsedRealtime() - lastTouchMs < 2500L) return
        box.removeAllViews()

        if (Build.VERSION.SDK_INT < 23) {
            box.addView(note("Trafik per aplikasi membutuhkan Android 6.0 ke atas."))
            return
        }
        if (!hasUsageAccess(ctx)) {
            box.addView(note("Untuk melihat trafik per aplikasi, izinkan \"Akses penggunaan\" untuk Speed Meter."))
            box.addView(text("Beri izin", 13f, Color.WHITE, true).apply {
                setPadding(dp(16), dp(8), dp(16), dp(8))
                background = GradientDrawable().apply {
                    cornerRadius = 10f * d
                    setColor(Color.parseColor("#1E88E5"))
                }
                setOnClickListener {
                    hide()
                    try {
                        ctx.startActivity(
                            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                    }
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) })
            return
        }

        val vpnUids = HashSet<Int>(NetCounters.vpnAppUids(ctx))
        if (vpnUid >= 0) vpnUids.add(vpnUid)
        val vpnOn = vpnUid != NetCounters.NO_VPN

        // Gabungkan data asli (NetworkStats) dengan perkiraan (saat VPN membuat data per aplikasi hilang).
        class Item(val uid: Int, val rate: DoubleArray, val sess: LongArray, val estimated: Boolean)
        val all = ArrayList<Item>()
        val keys = HashSet<Int>(session.keys)
        keys.addAll(estSession.keys)
        for (uid in keys) {
            // Terowongan VPN (trafik terenkripsi) disembunyikan selama perkiraan per aplikasi jalan,
            // karena angkanya sama dengan total dan hanya menutupi aplikasi yang sebenarnya.
            if (fallbackActive && vpnOn && uid in vpnUids && uid !in estSession) continue
            // Hotspot / tethering yang sebenarnya mati tapi muncul di daftar saat VPN aktif = artefak statistik.
            if (vpnOn && hideTether && uid == NetworkStats.Bucket.UID_TETHERING) continue
            val rr = rates[uid] ?: DoubleArray(2)
            val ss = session[uid] ?: LongArray(2)
            val er = estRates[uid]
            val es = estSession[uid]
            val useReal = !(fallbackActive && vpnOn && uid in vpnUids)
            val rate = DoubleArray(2)
            val sess = LongArray(2)
            if (useReal) {
                rate[0] += rr[0]; rate[1] += rr[1]
                sess[0] += ss[0]; sess[1] += ss[1]
            }
            if (er != null) { rate[0] += er[0]; rate[1] += er[1] }
            if (es != null) { sess[0] += es[0]; sess[1] += es[1] }
            if (sess[0] + sess[1] > 0L) all.add(Item(uid, rate, sess, es != null && es[0] + es[1] > 0L))
        }
        val items = all
            .sortedWith(
                compareByDescending<Item> { it.rate[0] + it.rate[1] }
                    .thenByDescending { it.sess[0] + it.sess[1] }
            )
            .take(5)

        if (items.isEmpty()) {
            box.addView(note(
                if (polls < 4) "Belum ada aplikasi yang memakai internet. Menunggu data\u2026"
                else "Belum ada data per aplikasi. Android memperbarui statistik ini lambat; coba pakai internet " +
                    "(buka halaman web) beberapa detik. Jika VPN aktif, sebagian HP mencatat trafik aplikasi di " +
                    "jaringan VPN sehingga tidak terbaca per aplikasi. Jika tetap kosong, HP ini tidak memberi " +
                    "data per aplikasi ke aplikasi biasa."
            ))
            return
        }
        for (e in items) {
            box.addView(appRow(e.uid, e.rate, e.sess, e.estimated))
        }
        if (items.any { it.estimated }) {
            box.addView(note("(perkiraan) = Android belum memberi data per aplikasi (sering terjadi saat VPN aktif atau statistik telat); " +
                "trafik dicatat atas nama aplikasi yang sedang dibuka."))
        }
    }

    private fun appRow(uid: Int, r: DoubleArray, sess: LongArray, estimated: Boolean = false): View {
        val (label0, icon) = labelFor(uid)
        val label = when {
            estimated && uid != VPN_FALLBACK_UID && uid != NET_FALLBACK_UID -> "$label0 (perkiraan)"
            uid == vpnUid && uid >= 0 -> "$label0 (VPN)"
            else -> label0
        }
        val bits = prefs.useBits
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        val iv = ImageView(ctx)
        if (icon != null) iv.setImageDrawable(icon)
        row.addView(iv, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(10) })

        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(text(label, 13f, Color.WHITE, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        mid.addView(text("Sesi: " + SpeedSampler.formatSize(sess[0] + sess[1]), 10f, grey))
        row.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val right = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        right.addView(text("\u2193 " + SpeedSampler.format(r[0], bits), 12f, green, true))
        if (prefs.showUpload) {
            right.addView(text("\u2191 " + SpeedSampler.format(r[1], bits), 12f, amber, true))
        }
        row.addView(right)
        return row
    }

    private fun requestRoot() {
        if (rootBusy) return
        rootBusy = true
        Thread {
            val txt = RootShell.readConnections()
            ui.post {
                rootBusy = false
                if (frame == null) return@post
                rootOk = txt != null
                rootConns = if (txt != null) ConnectionReader.parseAll(txt) else emptyList()
                refreshAddresses()
            }
        }.start()
    }

    /**
     * Satu alamat: nama host (subdomain) jadi teks utama, IP:port di bawahnya kecil.
     * Di kanan ada tombol Salin sendiri (nama host dan IP:port). Ketuk baris = salin nama, tahan = salin IP:port.
     */
    private fun addrRow(box: LinearLayout, c: ConnectionReader.Conn, host: String, searching: Boolean) {
        val hint = ConnectionReader.portHint(c.port)
        val ipPort = c.ip + ":" + c.port
        val ipPortHint = ipPort + (if (hint.isEmpty()) "" else "  ($hint)")
        val app = if (c.uid >= 0) labelFor(c.uid).first else ""

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, dp(3))
            isClickable = true
            setOnClickListener { copyText(if (host.isNotEmpty()) host else c.ip) }
            setOnLongClickListener {
                copyText(ipPort)
                true
            }
        }

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        if (app.isNotEmpty()) {
            col.addView(text(app, 11f, amber, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        }
        if (host.isNotEmpty()) {
            col.addView(text(host, 12f, Color.WHITE, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setPadding(0, dp(1), 0, 0)
            })
            col.addView(text(ipPortHint, 10f, grey).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        } else {
            col.addView(text(ipPortHint, 11f, Color.WHITE).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(1), 0, 0)
            })
            if (prefs.resolveHost) {
                col.addView(text(if (searching) "mencari nama host\u2026" else "(server tidak punya nama host publik)", 10f, grey))
            }
        }
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val btns = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        fun copyBtn(label: String, value: String) {
            btns.addView(smallButton(label) { copyText(value) }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(2) })
        }
        if (host.isNotEmpty()) copyBtn("Salin nama", host)
        copyBtn("Salin IP", ipPort)
        row.addView(btns, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(8) })

        box.addView(row)
    }

    private fun hostInfo(ip: String): Pair<String, Boolean> {
        if (!prefs.resolveHost) return Pair("", false)
        val cached = HostResolver.cached(ip)
        if (cached == null) {
            HostResolver.request(ip) { ui.post { if (frame != null) refreshAddresses() } }
            return Pair("", true)
        }
        return Pair(cached, false)
    }

    private fun refreshAddresses() {
        val box = addrBox ?: return

        // Daftar kosong / catatan
        fun setNote(t: String) {
            val sig = "note:$t"
            if (sig == lastAddrSig) return
            lastAddrSig = sig
            box.removeAllViews()
            box.addView(note(t))
        }

        fun setConns(list: List<ConnectionReader.Conn>) {
            val items = list.map { c ->
                val (h, s) = hostInfo(c.ip)
                Triple(c, h, s)
            }
            val sig = "conns:" + items.joinToString(";") { "${it.first.uid}|${it.first.ip}:${it.first.port}|${it.second}|${it.third}" }
            // Tidak ada perubahan -> jangan bangun ulang, supaya tombol Salin tidak terhapus saat ditekan.
            if (sig == lastAddrSig) return
            if (SystemClock.elapsedRealtime() - lastTouchMs < 2500L && lastAddrSig.startsWith("conns:")) return
            lastAddrSig = sig
            box.removeAllViews()
            for ((c, h, s) in items) addrRow(box, c, h, s)
        }

        if (prefs.rootAddr) {
            if (!rootBusy) requestRoot()
            when (rootOk) {
                null -> setNote("Meminta akses root\u2026 (izinkan di Magisk/KernelSU jika muncul)")
                false -> setNote("Akses root ditolak atau HP belum di-root.")
                true -> if (rootConns.isEmpty()) setNote("Tidak ada koneksi aktif.") else setConns(rootConns.take(8))
            }
            return
        }

        val res = ConnectionReader.read()
        when {
            res == null -> setNote(
                "Android 10 ke atas melarang aplikasi biasa membaca daftar koneksi. " +
                    "Fitur ini hanya bisa jalan di HP root: nyalakan \"Alamat via root\" di pengaturan."
            )
            res.isEmpty() -> setNote("Tidak ada koneksi aktif.")
            else -> setConns(res)
        }
    }

    // ------------------------------------------------------------------ data per aplikasi

    private fun startOfToday(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** Total byte per UID (unduh, unggah) sejak tengah malam, gabungan Wi-Fi + seluler. */
    @Suppress("DEPRECATION")
    private fun queryTotals(start: Long): Map<Int, LongArray> {
        val out = HashMap<Int, LongArray>()
        if (Build.VERSION.SDK_INT < 23) return out
        val nsm = ctx.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val end = System.currentTimeMillis() + 60_000L
        for (type in intArrayOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
            try {
                // Android 6-9: data seluler butuh subscriberId; Android 10+ cukup null (semua SIM).
                val sub = if (type == ConnectivityManager.TYPE_MOBILE && Build.VERSION.SDK_INT < 29) {
                    NetCounters.subscriberId(ctx)
                } else null
                val st = nsm.querySummary(type, sub, start, end)
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    val a = out.getOrPut(b.uid) { LongArray(2) }
                    a[0] += b.rxBytes
                    a[1] += b.txBytes
                }
                st.close()
            } catch (_: Exception) {
            }
        }
        return out
    }

    private var prevUid: Map<Int, LongArray>? = null
    private var polls = 0
    private var gotAny = false

    private fun pollApps() {
        if (Build.VERSION.SDK_INT < 23 || !hasUsageAccess(ctx)) return
        val now = SystemClock.elapsedRealtime()
        val day = startOfToday()
        val cur = queryTotals(day)
        val curU = NetCounters.uidTraffic(ctx)
        val p = prev
        val pu = prevUid
        if ((p != null && day == prevDay) || pu != null) {
            val dt = (now - prevT) / 1000.0
            if (dt > 0.0) {
                val uids = HashSet<Int>()
                uids.addAll(cur.keys)
                if (curU != null) uids.addAll(curU.keys)
                for (uid in uids) {
                    // Dua sumber, ambil yang lebih besar (masing-masing bisa kosong di HP tertentu).
                    var dr = 0L
                    var dtx = 0L
                    val a = cur[uid]
                    val pa = p?.get(uid)
                    if (a != null && p != null && day == prevDay) {
                        dr = (a[0] - (pa?.get(0) ?: 0L)).coerceAtLeast(0L)
                        dtx = (a[1] - (pa?.get(1) ?: 0L)).coerceAtLeast(0L)
                    }
                    val u = curU?.get(uid)
                    val pu1 = pu?.get(uid)
                    if (u != null && pu1 != null) {
                        dr = maxOf(dr, (u[0] - pu1[0]).coerceAtLeast(0L))
                        dtx = maxOf(dtx, (u[1] - pu1[1]).coerceAtLeast(0L))
                    }
                    val r = rates.getOrPut(uid) { DoubleArray(2) }
                    r[0] = r[0] * 0.4 + (dr / dt) * 0.6
                    r[1] = r[1] * 0.4 + (dtx / dt) * 0.6
                    if (dr > 0L || dtx > 0L) {
                        val s = session.getOrPut(uid) { LongArray(2) }
                        s[0] += dr
                        s[1] += dtx
                        gotAny = true
                    }
                }
            }
        }
        vpnFallback()
        polls++
        prev = cur
        prevUid = curU
        prevT = now
        prevDay = day
    }

    private var vpnUid = NetCounters.NO_VPN

    // Perkiraan per aplikasi saat VPN aktif (terpisah dari data asli supaya tidak tercampur).
    private val estRates = HashMap<Int, DoubleArray>()
    private val estSession = HashMap<Int, LongArray>()
    private var fallbackActive = false
    private var hideTether = false
    private var fgPkg: String? = null
    private var fgQueryAt = 0L
    private var homePkg: String? = null

    /** Paket aplikasi yang sedang di layar (dari riwayat UsageStats), atau null kalau tidak diketahui. */
    @Suppress("DEPRECATION")
    private fun foregroundUid(): Int? {
        try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (fgQueryAt == 0L) now - 6L * 3600_000L else fgQueryAt - 1000L
            val ev = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                when (e.eventType) {
                    UsageEvents.Event.MOVE_TO_FOREGROUND -> fgPkg = e.packageName
                    UsageEvents.Event.MOVE_TO_BACKGROUND -> if (e.packageName == fgPkg) fgPkg = null
                }
            }
            fgQueryAt = now
        } catch (_: Throwable) {
            return null
        }
        val pkg = fgPkg ?: return null
        if (pkg == ctx.packageName || pkg == "com.android.systemui") return null
        if (homePkg == null) {
            homePkg = try {
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                pm.resolveActivity(i, 0)?.activityInfo?.packageName ?: ""
            } catch (_: Throwable) {
                ""
            }
        }
        if (pkg == homePkg) return null // di layar utama: trafiknya bukan milik peluncur
        return try {
            pm.getApplicationInfo(pkg, 0).uid
        } catch (_: Throwable) {
            null
        }
    }

    private fun decayEstimates() {
        for (r in estRates.values) {
            r[0] *= 0.4
            r[1] *= 0.4
        }
    }

    /**
     * Saat VPN aktif, banyak HP mencatat trafik aplikasi di jaringan VPN (bukan Wi-Fi / seluler), jadi
     * yang terbaca di NetworkStats hanya aplikasi VPN-nya (terowongan terenkripsi) dan hotspot/tethering.
     *
     * Dulu aplikasi VPN dianggap "aplikasi biasa yang terbaca normal", sehingga cadangan tidak pernah
     * jalan dan daftar hanya berisi VPN + hotspot. Sekarang aplikasi VPN dan tethering TIDAK dihitung
     * sebagai data per aplikasi. Kalau tidak ada aplikasi lain yang terbaca padahal ada trafik di
     * perangkat, kecepatan total dicatat atas nama aplikasi yang sedang dibuka (ditandai "perkiraan"),
     * atau atas nama VPN kalau tidak ada aplikasi di layar.
     */
    private fun vpnFallback() {
        val v = NetCounters.vpnOwnerUid(ctx)
        vpnUid = v
        val vpnOn = v != NetCounters.NO_VPN
        hideTether = vpnOn && NetCounters.tetheringActive() == false
        val vpnUids = HashSet<Int>()
        if (vpnOn) {
            vpnUids.addAll(NetCounters.vpnAppUids(ctx))
            if (v >= 0) vpnUids.add(v)
        }

        // Berapa banyak trafik yang SUDAH terbaca per aplikasi (data asli)?
        var realRx = 0.0
        var realTx = 0.0
        for ((uid, r) in rates) {
            if (uid == NetworkStats.Bucket.UID_TETHERING || uid in vpnUids) continue
            realRx += r[0]
            realTx += r[1]
        }
        val realSum = realRx + realTx
        val dn = if (history.size > 0) history.down.last() else 0.0
        val upv = if (history.size > 0) history.up.last() else 0.0
        // Data asli dianggap cukup kalau sudah menjelaskan separuh lebih trafik total.
        // Tanpa VPN pun Android sering telat / tidak memberi data per aplikasi, jadi cadangan ini
        // dipakai di semua keadaan, bukan hanya saat VPN aktif.
        val realApp = if (dn + upv >= 2048.0) realSum >= (dn + upv) * 0.5 else realSum > 512.0
        fallbackActive = !realApp
        if (realApp || history.size == 0) {
            decayEstimates()
            return
        }
        val dt = (SystemClock.elapsedRealtime() - prevT) / 1000.0
        if (dt <= 0.0 || dt > 30.0) return
        if (dn + upv < 2048.0) {
            decayEstimates()
            return
        }
        val estDn = (dn - realRx).coerceAtLeast(0.0)
        val estUp = (upv - realTx).coerceAtLeast(0.0)
        val fg = foregroundUid()
        val key = fg ?: when {
            v >= 0 -> v
            vpnOn -> VPN_FALLBACK_UID
            else -> NET_FALLBACK_UID
        }
        for ((k, r) in estRates) {
            if (k != key) {
                r[0] *= 0.4
                r[1] *= 0.4
            }
        }
        val r = estRates.getOrPut(key) { DoubleArray(2) }
        r[0] = r[0] * 0.4 + estDn * 0.6
        r[1] = r[1] * 0.4 + estUp * 0.6
        val sess = estSession.getOrPut(key) { LongArray(2) }
        sess[0] += (estDn * dt).toLong()
        sess[1] += (estUp * dt).toLong()
        gotAny = true
    }

    private fun labelFor(uid: Int): Pair<String, Drawable?> = labelCache.getOrPut(uid) {
        when (uid) {
            VPN_FALLBACK_UID -> Pair("Lalu lintas lewat VPN", null)
            NET_FALLBACK_UID -> Pair("Lalu lintas jaringan", null)
            NetworkStats.Bucket.UID_REMOVED -> Pair("Aplikasi yang sudah dihapus", null)
            NetworkStats.Bucket.UID_TETHERING -> Pair("Hotspot / tethering", null)
            0 -> Pair("Sistem (root)", null)
            1000 -> Pair("Android System", null)
            else -> try {
                val pkgs = pm.getPackagesForUid(uid)
                if (pkgs.isNullOrEmpty()) {
                    Pair("UID $uid", null)
                } else {
                    @Suppress("DEPRECATION")
                    val ai = pm.getApplicationInfo(pkgs[0], 0)
                    Pair(pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai))
                }
            } catch (_: Exception) {
                Pair("UID $uid", null)
            }
        }
    }
}
