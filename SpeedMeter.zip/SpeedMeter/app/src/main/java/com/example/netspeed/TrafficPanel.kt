package com.example.netspeed

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.net.InetAddress
import java.util.Calendar

/** Apakah izin "Akses penggunaan" (Usage Access) sudah diberikan? Dibutuhkan untuk trafik per aplikasi. */
@Suppress("DEPRECATION")
fun hasUsageAccess(ctx: Context): Boolean {
    return try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
            )
        } else {
            ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
            )
        }
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
        false
    }
}

/**
 * Membaca daftar koneksi TCP yang sedang terhubung dari /proc/net.
 * Android 10+ memblokir file ini untuk aplikasi biasa, jadi hasilnya null di HP modern.
 */
object ConnectionReader {
    class Conn(val ip: String, val port: Int, val uid: Int = -1)

    /** Parse isi gabungan /proc/net/tcp dan /proc/net/tcp6 (mis. hasil `su -c cat`). */
    fun parseAll(text: String): List<Conn> {
        val seen = LinkedHashSet<String>()
        val list = ArrayList<Conn>()
        for (line in text.lineSequence()) {
            val c = parse(line) ?: continue
            if (seen.add(c.uid.toString() + "|" + c.ip + ":" + c.port)) list.add(c)
        }
        return list
    }

    fun read(): List<Conn>? {
        val seen = LinkedHashSet<String>()
        val list = ArrayList<Conn>()
        var readable = false
        for (path in arrayOf("/proc/net/tcp6", "/proc/net/tcp")) {
            try {
                File(path).bufferedReader().use { br ->
                    val head = br.readLine()
                    if (head != null) readable = true
                    var line = br.readLine()
                    while (line != null) {
                        val c = parse(line)
                        if (c != null && seen.add(c.ip + ":" + c.port)) list.add(c)
                        line = br.readLine()
                    }
                }
            } catch (_: Exception) {
            }
        }
        return if (readable) list.take(6) else null
    }

    private fun parse(line: String): Conn? {
        val f = line.trim().split(Regex("\\s+"))
        if (f.size < 4 || f[3] != "01") return null // 01 = ESTABLISHED
        val rem = f[2].split(":")
        if (rem.size != 2) return null
        val port = rem[1].toIntOrNull(16) ?: return null
        val words = rem[0].chunked(8)
        if (words.size != 1 && words.size != 4) return null
        val bytes = ByteArray(words.size * 4)
        for ((i, w) in words.withIndex()) {
            val v = w.toLongOrNull(16) ?: return null
            bytes[i * 4] = (v and 0xFF).toByte()
            bytes[i * 4 + 1] = ((v shr 8) and 0xFF).toByte()
            bytes[i * 4 + 2] = ((v shr 16) and 0xFF).toByte()
            bytes[i * 4 + 3] = ((v shr 24) and 0xFF).toByte()
        }
        val addr = try {
            InetAddress.getByAddress(bytes)
        } catch (_: Exception) {
            return null
        }
        if (addr.isLoopbackAddress || addr.isAnyLocalAddress) return null
        val ip = addr.hostAddress ?: return null
        return Conn(ip, port, f.getOrNull(7)?.toIntOrNull() ?: -1)
    }

    fun portHint(port: Int): String = when (port) {
        443 -> "HTTPS"
        80 -> "HTTP"
        53 -> "DNS"
        5228, 5229, 5230 -> "Google / FCM"
        993, 143 -> "IMAP"
        465, 587 -> "SMTP"
        8080 -> "HTTP"
        else -> ""
    }
}

/** Menjalankan perintah lewat root (su). Harus dipanggil dari thread latar. */
object RootShell {
    fun run(cmd: String): String? {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            if (code == 0 && out.isNotEmpty()) out else null
        } catch (_: Exception) {
            null
        }
    }

    fun readConnections(): String? = run("cat /proc/net/tcp /proc/net/tcp6")

    /** Seperti run(), tapi hasilnya dipakai walau kode keluar bukan 0 (dumpsys kadang begitu). */
    fun runAny(cmd: String): String? {
        val proc: Process = try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        } catch (_: Exception) {
            return null
        }
        return try {
            val out = proc.inputStream.bufferedReader().readText()
            proc.waitFor()
            if (out.isNotBlank()) out else null
        } catch (_: Exception) {
            null
        } finally {
            try {
                proc.destroy()
            } catch (_: Exception) {
            }
        }
    }
}

/**
 * Panel yang muncul saat meter mengambang diketuk: grafik naik-turun, aplikasi yang sedang memakai
 * internet (lewat NetworkStatsManager, butuh izin Akses penggunaan), dan alamat yang sedang diakses.
 */
class TrafficPanel(
    private val ctx: Context,
    private val wm: WindowManager,
    private val prefs: Prefs,
    private val history: SpeedHistory
) {
    private val ui = Handler(Looper.getMainLooper())
    private val pm = ctx.packageManager
    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val green = Color.parseColor("#00C853")
    private val red = Color.parseColor("#FF5252")
    private val amber = Color.parseColor("#FFB300")
    private val grey = Color.argb(160, 255, 255, 255)

    private var view: LinearLayout? = null
    private var graph: SpeedGraphView? = null
    private var tvDown: TextView? = null
    private var tvUp: TextView? = null
    private var tvSpan: TextView? = null
    private var appsBox: LinearLayout? = null
    private var addrBox: LinearLayout? = null

    var lastHideMs = 0L
        private set
    val isShowing: Boolean get() = view != null

    // pengukuran per aplikasi
    private var prev: Map<Int, LongArray>? = null
    private var prevT = 0L
    private var prevDay = 0L
    private val rates = HashMap<Int, DoubleArray>() // uid -> [unduh B/s, unggah B/s]
    private val session = HashMap<Int, LongArray>() // uid -> [unduh, unggah] sejak panel dibuka
    private var rootOk: Boolean? = null // null = belum ada jawaban
    private var rootConns: List<ConnectionReader.Conn> = emptyList()
    private var rootBusy = false
    private val labelCache = HashMap<Int, Pair<String, Drawable?>>()

    private val poller = object : Runnable {
        override fun run() {
            pollApps()
            refreshLists()
            ui.postDelayed(this, 2000L)
        }
    }

    // ------------------------------------------------------------------ tampil / sembunyi

    fun show(anchorY: Int, anchorH: Int) {
        if (view != null) return
        rootOk = null
        rootConns = emptyList()
        prev = null
        rates.clear()
        session.clear()

        val (sw, sh) = screenSize()
        val width = minOf(sw - dp(16), dp(380))
        val v = build()

        val lp = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            x = (sw - width) / 2
            // Meter di setengah atas layar -> panel muncul di bawahnya; kalau di bawah -> panel di atasnya.
            if (anchorY + anchorH / 2 < sh / 2) {
                gravity = Gravity.TOP or Gravity.START
                y = anchorY + anchorH + dp(6)
            } else {
                gravity = Gravity.BOTTOM or Gravity.START
                y = (sh - anchorY + dp(6)).coerceAtLeast(0)
            }
        }

        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) {
                hide()
                true
            } else {
                false
            }
        }

        try {
            wm.addView(v, lp)
        } catch (_: Exception) {
            return
        }
        view = v
        onSample()
        ui.removeCallbacks(poller)
        ui.post(poller)
    }

    fun hide() {
        ui.removeCallbacks(poller)
        val v = view ?: return
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
        view = null
        graph = null
        tvDown = null
        tvUp = null
        tvSpan = null
        appsBox = null
        addrBox = null
        lastHideMs = SystemClock.elapsedRealtime()
    }

    /** Dipanggil service tiap ada sampel kecepatan baru. */
    fun onSample() {
        val g = graph ?: return
        val n = history.size
        if (n == 0) return
        val bits = prefs.useBits
        g.useBits = bits
        g.showUp = prefs.showUpload
        g.onSampleAdded()

        tvDown?.apply {
            text = "\u2193 " + SpeedSampler.format(history.down[n - 1], bits)
            setTextColor(if (history.trendUp()) green else red)
        }
        tvUp?.apply {
            visibility = if (prefs.showUpload) View.VISIBLE else View.GONE
            text = "\u2191 " + SpeedSampler.format(history.up[n - 1], bits)
        }
        val secs = (g.visibleCount * prefs.intervalMs / 1000f).toInt()
        tvSpan?.text = "Rentang \u00B1${secs} detik  \u2022  hijau = naik, merah = turun, abu = lurus"
    }

    // ------------------------------------------------------------------ UI

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(color)
            includeFontPadding = false
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun build(): LinearLayout {
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = 18f * d
                setColor(Color.argb(240, 14, 18, 24))
            }
        }

        // judul + tombol tutup
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            text("Trafik jaringan", 16f, Color.WHITE, true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(text("\u2715", 18f, grey).apply {
            setPadding(dp(14), dp(2), dp(2), dp(2))
            setOnClickListener { hide() }
        })
        card.addView(header)

        // angka saat ini
        val stats = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(6))
        }
        val down = text("\u2193 -", 20f, green, true)
        val up = text("\u2191 -", 14f, amber, true)
        stats.addView(down, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        stats.addView(up)
        card.addView(stats)
        tvDown = down
        tvUp = up

        // grafik
        val g = SpeedGraphView(ctx, history)
        card.addView(g, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(190)))
        graph = g

        val spanRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, 0)
        }
        val span = text("", 10f, grey)
        spanRow.addView(span, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        spanRow.addView(text("\u27F2 Reset", 11f, Color.WHITE, true).apply {
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { graph?.resetView() }
        })
        card.addView(spanRow)
        tvSpan = span
        card.addView(text("Cubit = zoom  \u2022  geser = pindah  \u2022  ketuk 2x = reset", 10f, grey).apply {
            setPadding(0, dp(2), 0, 0)
        })

        // aplikasi
        card.addView(text("Aplikasi yang memakai internet", 12f, grey, true).apply {
            setPadding(0, dp(14), 0, dp(4))
        })
        val apps = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        card.addView(apps)
        appsBox = apps

        // alamat
        card.addView(text("Alamat yang sedang diakses", 12f, grey, true).apply {
            setPadding(0, dp(14), 0, dp(4))
        })
        val addr = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        card.addView(addr)
        addrBox = addr

        return card
    }

    private fun note(t: String): TextView = text(t, 11f, grey).apply {
        setPadding(0, dp(2), 0, dp(2))
    }

    private fun refreshLists() {
        refreshApps()
        refreshAddresses()
    }

    private fun refreshApps() {
        val box = appsBox ?: return
        box.removeAllViews()

        if (!hasUsageAccess(ctx)) {
            box.addView(note("Untuk melihat trafik per aplikasi, izinkan \"Akses penggunaan\" untuk Speed Meter."))
            box.addView(text("Beri izin", 13f, Color.WHITE, true).apply {
                setPadding(dp(16), dp(8), dp(16), dp(8))
                background = GradientDrawable().apply {
                    cornerRadius = 10f * d
                    setColor(Color.parseColor("#1E88E5"))
                }
                setOnClickListener {
                    hide()
                    try {
                        ctx.startActivity(
                            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                    }
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) })
            return
        }

        val items = session.entries
            .filter { it.value[0] + it.value[1] > 0L }
            .sortedWith(
                compareByDescending<Map.Entry<Int, LongArray>> {
                    val r = rates[it.key]
                    if (r == null) 0.0 else r[0] + r[1]
                }.thenByDescending { it.value[0] + it.value[1] }
            )
            .take(5)

        if (items.isEmpty()) {
            box.addView(note("Belum ada aplikasi yang memakai internet. Menunggu data\u2026"))
            return
        }
        for (e in items) {
            box.addView(appRow(e.key, rates[e.key] ?: DoubleArray(2), e.value))
        }
    }

    private fun appRow(uid: Int, r: DoubleArray, sess: LongArray): View {
        val (label, icon) = labelFor(uid)
        val bits = prefs.useBits
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        val iv = ImageView(ctx)
        if (icon != null) iv.setImageDrawable(icon)
        row.addView(iv, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(10) })

        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(text(label, 13f, Color.WHITE, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        mid.addView(text("Sesi: " + SpeedSampler.formatSize(sess[0] + sess[1]), 10f, grey))
        row.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val right = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        right.addView(text("\u2193 " + SpeedSampler.format(r[0], bits), 12f, green, true))
        if (prefs.showUpload) {
            right.addView(text("\u2191 " + SpeedSampler.format(r[1], bits), 12f, amber, true))
        }
        row.addView(right)
        return row
    }

    private fun requestRoot() {
        if (rootBusy) return
        rootBusy = true
        Thread {
            val txt = RootShell.readConnections()
            ui.post {
                rootBusy = false
                if (view == null) return@post
                rootOk = txt != null
                rootConns = if (txt != null) ConnectionReader.parseAll(txt) else emptyList()
                refreshAddresses()
            }
        }.start()
    }

    /** Satu alamat: nama host (subdomain) jadi teks utama, IP:port di bawahnya kecil. */
    private fun addrRow(box: LinearLayout, c: ConnectionReader.Conn) {
        val hint = ConnectionReader.portHint(c.port)
        val ipPort = c.ip + ":" + c.port + (if (hint.isEmpty()) "" else "  ($hint)")
        val app = if (c.uid >= 0) labelFor(c.uid).first else ""
        if (app.isNotEmpty()) {
            box.addView(text(app, 11f, amber, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(5), 0, 0)
            })
        }

        var host = ""
        var searching = false
        if (prefs.resolveHost) {
            val cached = HostResolver.cached(c.ip)
            if (cached == null) {
                searching = true
                HostResolver.request(c.ip) {
                    ui.post { if (view != null) refreshAddresses() }
                }
            } else {
                host = cached
            }
        }

        if (host.isNotEmpty()) {
            box.addView(text(host, 12f, Color.WHITE, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setPadding(0, dp(1), 0, 0)
            })
            box.addView(text(ipPort, 10f, grey).apply {
                typeface = Typeface.MONOSPACE
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, 0, 0, dp(2))
            })
        } else {
            box.addView(text(ipPort, 11f, Color.WHITE).apply {
                typeface = Typeface.MONOSPACE
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(1), 0, 0)
            })
            if (prefs.resolveHost) {
                box.addView(text(if (searching) "mencari nama host\u2026" else "(server tidak punya nama host publik)", 10f, grey).apply {
                    setPadding(0, 0, 0, dp(2))
                })
            }
        }
    }

    private fun refreshAddresses() {
        val box = addrBox ?: return
        box.removeAllViews()

        if (prefs.rootAddr) {
            if (!rootBusy) requestRoot()
            when (rootOk) {
                null -> box.addView(note("Meminta akses root\u2026 (izinkan di Magisk/KernelSU jika muncul)"))
                false -> box.addView(note("Akses root ditolak atau HP belum di-root."))
                true -> if (rootConns.isEmpty()) {
                    box.addView(note("Tidak ada koneksi aktif."))
                } else {
                    for (c in rootConns.take(8)) addrRow(box, c)
                }
            }
            return
        }

        val res = ConnectionReader.read()
        when {
            res == null -> box.addView(
                note(
                    "Android 10 ke atas melarang aplikasi biasa membaca daftar koneksi. " +
                        "Nyalakan \"Alamat via root\" di pengaturan jika HP kamu di-root."
                )
            )
            res.isEmpty() -> box.addView(note("Tidak ada koneksi aktif."))
            else -> for (c in res) addrRow(box, c)
        }
    }

    // ------------------------------------------------------------------ data per aplikasi

    private fun startOfToday(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** Total byte per UID (unduh, unggah) sejak tengah malam, gabungan Wi-Fi + seluler. */
    @Suppress("DEPRECATION")
    private fun queryTotals(start: Long): Map<Int, LongArray> {
        val out = HashMap<Int, LongArray>()
        val nsm = ctx.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val end = System.currentTimeMillis() + 60_000L
        for (type in intArrayOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
            try {
                val st = nsm.querySummary(type, null, start, end)
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    val a = out.getOrPut(b.uid) { LongArray(2) }
                    a[0] += b.rxBytes
                    a[1] += b.txBytes
                }
                st.close()
            } catch (_: Exception) {
            }
        }
        return out
    }

    private fun pollApps() {
        if (!hasUsageAccess(ctx)) return
        val now = SystemClock.elapsedRealtime()
        val day = startOfToday()
        val cur = queryTotals(day)
        val p = prev
        if (p != null && day == prevDay) {
            val dt = (now - prevT) / 1000.0
            if (dt > 0.0) {
                for ((uid, a) in cur) {
                    val pa = p[uid]
                    val dr = (a[0] - (pa?.get(0) ?: 0L)).coerceAtLeast(0L)
                    val dtx = (a[1] - (pa?.get(1) ?: 0L)).coerceAtLeast(0L)
                    val r = rates.getOrPut(uid) { DoubleArray(2) }
                    r[0] = r[0] * 0.4 + (dr / dt) * 0.6
                    r[1] = r[1] * 0.4 + (dtx / dt) * 0.6
                    if (dr > 0L || dtx > 0L) {
                        val s = session.getOrPut(uid) { LongArray(2) }
                        s[0] += dr
                        s[1] += dtx
                    }
                }
            }
        }
        prev = cur
        prevT = now
        prevDay = day
    }

    private fun labelFor(uid: Int): Pair<String, Drawable?> = labelCache.getOrPut(uid) {
        when (uid) {
            NetworkStats.Bucket.UID_REMOVED -> Pair("Aplikasi yang sudah dihapus", null)
            NetworkStats.Bucket.UID_TETHERING -> Pair("Hotspot / tethering", null)
            0 -> Pair("Sistem (root)", null)
            1000 -> Pair("Android System", null)
            else -> try {
                val pkgs = pm.getPackagesForUid(uid)
                if (pkgs.isNullOrEmpty()) {
                    Pair("UID $uid", null)
                } else {
                    @Suppress("DEPRECATION")
                    val ai = pm.getApplicationInfo(pkgs[0], 0)
                    Pair(pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai))
                }
            } catch (_: Exception) {
                Pair("UID $uid", null)
            }
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }
}
