package com.example.netspeed

import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.os.Build
import android.telephony.TelephonyManager
import java.io.File
import java.util.Calendar

/**
 * Semua cara membaca counter byte jaringan TANPA root. Tiap cara bisa gagal / salah di HP tertentu
 * (misalnya TrafficStats tidak mencatat unggah di interface VPN), jadi SpeedSampler memakai semuanya
 * lalu mengambil angka yang paling masuk akal.
 *
 * Hasil tiap fungsi: nama interface -> [byte diterima, byte dikirim].
 */
object NetCounters {

    private const val RETRY_MS = 60_000L
    private var procFailAt = 0L
    private var sysFailAt = 0L

    /** 1) TrafficStats per interface (API Android resmi / semi-resmi). */
    @Suppress("DEPRECATION")
    fun trafficStats(names: Collection<String>): Map<String, LongArray>? {
        val unsupported = TrafficStats.UNSUPPORTED.toLong()
        val out = HashMap<String, LongArray>()
        for (n in names) {
            try {
                val rx = TrafficStats.getRxBytes(n)
                val tx = TrafficStats.getTxBytes(n)
                if (rx != unsupported && tx != unsupported) out[n] = longArrayOf(rx, tx)
            } catch (_: Throwable) {
            }
        }
        return if (out.isEmpty()) null else out
    }

    /** 2) /sys/class/net/<iface>/statistics (counter kernel; boleh dibaca di sebagian HP). */
    fun sysfs(names: Collection<String>): Map<String, LongArray>? {
        val now = System.currentTimeMillis()
        if (sysFailAt != 0L && now - sysFailAt < RETRY_MS) return null
        val out = HashMap<String, LongArray>()
        for (n in names) {
            try {
                val rx = File("/sys/class/net/$n/statistics/rx_bytes").readText().trim().toLong()
                val tx = File("/sys/class/net/$n/statistics/tx_bytes").readText().trim().toLong()
                out[n] = longArrayOf(rx, tx)
            } catch (_: Throwable) {
            }
        }
        if (out.isEmpty() && names.isNotEmpty()) {
            sysFailAt = now
            return null
        }
        sysFailAt = 0L
        return out
    }

    /** 3) /proc/net/dev dibaca langsung (di Android 10+ sering ditolak). */
    fun procNetDev(): Map<String, LongArray>? {
        val now = System.currentTimeMillis()
        if (procFailAt != 0L && now - procFailAt < RETRY_MS) return null
        return try {
            val m = parseNetDev(File("/proc/net/dev").readText())
            if (m.isEmpty()) {
                procFailAt = now
                null
            } else {
                procFailAt = 0L
                m
            }
        } catch (_: Throwable) {
            procFailAt = now
            null
        }
    }

    /**
     * 4) NetworkStatsManager (butuh izin "Akses penggunaan", Android 6+). Ini angka dari layanan
     * statistik sistem, per aplikasi dijumlahkan se-perangkat; tiap pembacaan memaksa sistem
     * memperbarui datanya dulu, jadi unggah tetap tercatat walau counter interface rusak.
     * Hasil: "__wifi__" dan "__mobile__".
     */
    @Suppress("DEPRECATION")
    fun networkStats(ctx: Context): Map<String, LongArray>? {
        if (Build.VERSION.SDK_INT < 23) return null
        if (!hasUsageAccess(ctx)) return null
        return try {
            val nsm = ctx.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val start = startOfDay()
            val end = System.currentTimeMillis() + 60_000L
            val out = HashMap<String, LongArray>()
            for ((type, key) in listOf(
                ConnectivityManager.TYPE_WIFI to "__wifi__",
                ConnectivityManager.TYPE_MOBILE to "__mobile__"
            )) {
                try {
                    val sub = if (type == ConnectivityManager.TYPE_MOBILE && Build.VERSION.SDK_INT < 29) {
                        subscriberId(ctx)
                    } else null
                    val b = nsm.querySummaryForDevice(type, sub, start, end)
                    out[key] = longArrayOf(b.rxBytes, b.txBytes)
                } catch (_: Throwable) {
                }
            }
            if (out.isEmpty()) null else out
        } catch (_: Throwable) {
            null
        }
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun subscriberId(ctx: Context): String? {
        return try {
            if (ctx.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) return null
            (ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).subscriberId
        } catch (_: Throwable) {
            null
        }
    }

    private fun startOfDay(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }
}
