package com.example.netspeed

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import android.view.View
import android.view.WindowManager
import android.text.SpannableStringBuilder
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.TextView
import java.util.concurrent.Executors

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var sampler: SpeedSampler
    private lateinit var nm: NotificationManager
    private lateinit var cm: ConnectivityManager

    private lateinit var usage: UsageStore

    private var root: LinearLayout? = null
    private var rowDown: LinearLayout? = null
    private var rowUp: LinearLayout? = null
    private var arrowDown: TextView? = null
    private var arrowUp: TextView? = null
    private var tvDown: TextView? = null
    private var tvUp: TextView? = null

    private val history = SpeedHistory()
    private var panel: TrafficPanel? = null

    // Warna pelangi: aktif saat opsi dinyalakan DAN internet tersambung.
    private var connected = false
    private var hue = 0f
    private var rainbowRunning = false
    private val shaders = java.util.WeakHashMap<TextView, RainbowShader>()

    private var downActive = false
    private var upActive = false
    private var blinkPhase = false

    private val handler = Handler(Looper.getMainLooper())
    private var started = false

    // Ukuran meter (hasil cubit dua jari)
    private var ovScale = 1f

    // Info sinyal (root) untuk notifikasi
    @Volatile private var sigDbm = "N/A"
    @Volatile private var sigBand = "LTE"
    @Volatile private var sigOk = false
    private var sigBusy = false
    private var sigFailUntil = 0L
    private val sigExec = Executors.newCachedThreadPool()
    private var sigStartMs = 0L
    private var sigWatcher: SignalWatcher? = null
    private var notifHue = 0f
    private var lastNotifHueMs = 0L

    // Pemakaian data hari ini (dihitung selama meter aktif)
    private var dayKey = ""
    private var dayWifi = 0L
    private var dayMobile = 0L
    private var lastSaveMs = 0L
    private var lastNotifMs = 0L

    private var nextTickAt = 0L

    // Jadwal tetap (bukan "selesai + interval") supaya selang antar pembacaan tidak melar dan angka tidak terlambat.
    private val ticker = object : Runnable {
        override fun run() {
            val t0 = SystemClock.uptimeMillis()
            tick()
            val iv = prefs.intervalMs
            var next = (if (nextTickAt == 0L) t0 else nextTickAt) + iv
            val now = SystemClock.uptimeMillis()
            if (next <= now) next = now + iv
            nextTickAt = next
            handler.postAtTime(this, next)
        }
    }

    private val blinker = object : Runnable {
        override fun run() {
            blinkPhase = !blinkPhase
            if (prefs.arrowMode == 2 && (downActive || upActive)) updateArrows()
            handler.postDelayed(this, 450L)
        }
    }

    private val rainbowTicker = object : Runnable {
        override fun run() {
            rainbowRunning = false
            if (!rainbowOn()) {
                applyColors() // kembali ke warna pilihan
                return
            }
            val lvl = prefs.rainbowSpeedMeter
            hue = Rainbow.hueFor(lvl)
            applyColors()
            rainbowRunning = true
            handler.postDelayed(this, Rainbow.delayMs(lvl))
        }
    }

    private val sigRunner = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            // Penjaga: kalau pembacaan sebelumnya macet (mis. su menggantung), jangan blokir selamanya.
            if (sigBusy && now - sigStartMs > 10_000L) sigBusy = false
            if ((prefs.rootSignal || prefs.noRootSignal) && !sigBusy) {
                sigBusy = true
                sigStartMs = now
                val tryRoot = prefs.rootSignal && now >= sigFailUntil
                val tryNoRoot = prefs.noRootSignal
                try {
                    sigExec.execute {
                        var r: SignalReader.Info? = null
                        // 1) Pindai sel BARU setiap 3 detik lewat API Android (butuh izin lokasi, Android 10+).
                        //    Ini yang membuat dBm benar-benar ikut berubah, tidak nyangkut di nilai lama.
                        if ((tryRoot || tryNoRoot) && Build.VERSION.SDK_INT >= 29 &&
                            SignalReader.hasLocationPermission(applicationContext)
                        ) {
                            val n = try { SignalReader.readNoRoot(applicationContext) } catch (_: Throwable) { null }
                            if (n != null && n.dbm != "N/A") r = n
                        }
                        val fromFresh = r != null
                        var rootFailed = false
                        if ((r == null || r.dbm == "N/A") && tryRoot) {
                            val rr = try { SignalReader.read() } catch (_: Exception) { null }
                            rootFailed = rr == null
                            if (rr != null) r = rr
                        }
                        // Root tidak ada / tidak memberi dBm: pakai cara biasa (tanpa root).
                        if ((r == null || r.dbm == "N/A") && tryNoRoot) {
                            val n = try { SignalReader.readNoRoot(applicationContext) } catch (_: Throwable) { null }
                            if (n != null) r = n
                        }
                        // Pendengar sinyal sistem (selalu diperbarui Android) mengalahkan data root yang bisa basi.
                        val w = SignalReader.watcherDbm
                        if (!fromFresh && w != null) r = SignalReader.Info("$w dBm", r?.band ?: "LTE")
                        val res = r
                        handler.post {
                            sigBusy = false
                            if (rootFailed) sigFailUntil = SystemClock.elapsedRealtime() + 30_000L
                            if (res == null) {
                                sigOk = false
                            } else {
                                if (sigDbm != res.dbm || sigBand != res.band) lastNotifMs = 0L // tampilkan segera
                                sigDbm = res.dbm
                                sigBand = res.band
                                sigOk = true
                            }
                        }
                    }
                } catch (_: Exception) {
                    sigBusy = false
                }
            }
            handler.postDelayed(this, 3000L)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        // Abaikan perubahan internal (posisi, ukuran panel) supaya tidak menggambar ulang terus.
        if (key == "posX" || key == "posY" || key == "panelScale" ||
            key == "pinHash" || key == "pinSalt" || key == "pinFails" || key == "pinBlockedUntil"
        ) return@OnSharedPreferenceChangeListener
        if (key == "a11yOverlay") {
            handler.post { recreateOverlay() }
            return@OnSharedPreferenceChangeListener
        }
        if (key == "floatOverlay") {
            handler.post { syncOverlay() }
            return@OnSharedPreferenceChangeListener
        }
        if (key == "overlayScale") ovScale = prefs.overlayScale
        if (key == "rootSignal") sigFailUntil = 0L
        if (key == "noRootSignal" || key == "rootSignal") {
            if (prefs.noRootSignal || prefs.rootSignal) {
                if (sigWatcher == null) sigWatcher = SignalWatcher(this)
                sigWatcher?.start()
            } else sigWatcher?.stop()
            handler.removeCallbacks(sigRunner)
            handler.post(sigRunner)
        }
        if (key == "rootCounters") {
            if (prefs.rootCounters) RootNetDev.start() else RootNetDev.stop()
            sampler.reset()
        }
        if (key == "safeNav") root?.post { clampPosition() }
        applyStyle()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /** Sumber data yang sedang dipakai pengukur (untuk layar diagnostik). */
    fun activeSources(): String = sampler.activeSources

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Layar diputar: pastikan meter tetap di area yang aman.
        root?.post { clampPosition() }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        current = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        prefs = Prefs(this)
        ovScale = prefs.overlayScale
        usage = UsageStore(this)
        sampler = SpeedSampler(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        loadDayCounters()
        // Wajib dipanggil cepat setelah startForegroundService(), termasuk saat akan berhenti.
        goForeground()

        if (intent?.action == ACTION_STOP) {
            prefs.enabled = false
            stopSelf()
            return START_NOT_STICKY
        }

        // Notifikasi + pengukuran jalan tanpa izin overlay. Meter mengambang hanya muncul
        // kalau opsinya menyala DAN izin "tampil di atas aplikasi lain" sudah diberikan.
        if (!started) {
            started = true
            prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
            sampler.reset()
            handler.removeCallbacks(ticker)
            handler.post(ticker)
            handler.removeCallbacks(blinker)
            handler.postDelayed(blinker, 450L)
            handler.removeCallbacks(sigRunner)
            handler.post(sigRunner)
        }
        syncOverlay()
        if (prefs.noRootSignal || prefs.rootSignal) {
            if (sigWatcher == null) sigWatcher = SignalWatcher(this)
            sigWatcher?.start()
        }
        if (prefs.rootCounters) RootNetDev.start()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        if (current === this) current = null
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(blinker)
        handler.removeCallbacks(rainbowTicker)
        handler.removeCallbacks(sigRunner)
        RootNetDev.stop()
        sigWatcher?.stop()
        sigWatcher = null
        try { sigExec.shutdownNow() } catch (_: Exception) {}
        panel?.hide()
        panel = null
        saveDayCounters()
        prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- pengukuran

    private fun tick() {
        val s = sampler.read(prefs.vpnAppLevel, prefs.netFilter, prefs.rootCounters)
        updateConnected()
        val down = tvDown
        val up = tvUp
        if (s == null) {
            down?.text = "N/A"
            up?.text = "N/A"
            downActive = false
            upActive = false
            history.add(0.0, 0.0, connected)
            panel?.onSample()
            updateArrows()
            ensureRainbow()
            return
        }

        addDayUsage(s.wifiBytes, s.mobileBytes)

        val bits = prefs.useBits
        down?.text = SpeedSampler.format(s.downBytesPerSec, bits)
        up?.text = SpeedSampler.format(s.upBytesPerSec, bits)

        downActive = s.downBytesPerSec >= ACTIVE_BPS
        upActive = s.upBytesPerSec >= ACTIVE_BPS
        updateArrows()
        ensureRainbow()

        history.add(s.downBytesPerSec, s.upBytesPerSec, connected)
        panel?.onSample()

        // Notifikasi cukup diperbarui sekitar 1x per detik.
        val nowMs = SystemClock.elapsedRealtime()
        if (nowMs - lastNotifMs >= 1000L) {
            lastNotifMs = nowMs
            try {
                nm.notify(NOTIF_ID, buildNotification(s.downBytesPerSec, s.upBytesPerSec))
            } catch (_: Exception) {
            }
        }
    }

    /** Terangkan warna dengan mencampurnya ke arah putih. */
    private fun brighten(c: Int): Int {
        fun f(v: Int) = v + ((255 - v) * 0.6f).toInt()
        return Color.rgb(f(Color.red(c)), f(Color.green(c)), f(Color.blue(c)))
    }

    private fun dim(c: Int): Int = Color.argb(90, Color.red(c), Color.green(c), Color.blue(c))

    private fun arrowColor(base: Int, active: Boolean): Int {
        if (!active) return base
        return when (prefs.arrowMode) {
            0 -> base
            1 -> brighten(base)
            else -> if (blinkPhase) brighten(base) else dim(base)
        }
    }

    private fun updateConnected() {
        connected = Compat.isConnected(cm)
    }

    private fun rainbowOn(): Boolean = prefs.rainbow && connected

    private fun hsv(h: Float): Int = Color.HSVToColor(floatArrayOf(h % 360f, 0.85f, 1f))

    private fun downBase(): Int = if (rainbowOn()) hsv(hue) else prefs.downColor
    private fun upBase(): Int = if (rainbowOn()) hsv(hue + 120f) else prefs.upColor

    private fun ensureRainbow() {
        if (rainbowOn() && !rainbowRunning) {
            rainbowRunning = true
            handler.post(rainbowTicker)
        }
    }

    /** Pelangi mengalir di seluruh teks (angka + satuan Kbps/Mbps), bukan hanya satu warna. */
    private fun paintText(tv: TextView?, base: Int, hueOffset: Float) {
        if (tv == null) return
        if (rainbowOn()) {
            val w = maxOf(tv.width.toFloat(), tv.paint.measureText(tv.text.toString()), 1f)
            val rs = shaders.getOrPut(tv) { RainbowShader() }
            tv.paint.shader = rs.get(w, hue + hueOffset)
            tv.invalidate()
        } else {
            tv.paint.shader = null
            tv.setTextColor(base)
        }
    }

    private fun applyColors() {
        paintText(tvDown, prefs.downColor, 0f)
        paintText(tvUp, prefs.upColor, 120f)
        updateArrows()
    }

    /** Panah hanya berubah saat ada trafik; saat tidak ada trafik kembali ke warna biasa. */
    private fun updateArrows() {
        arrowDown?.setTextColor(arrowColor(downBase(), downActive))
        arrowUp?.setTextColor(arrowColor(upBase(), upActive))
    }

    /** Ketukan singkat pada meter: buka / tutup panel trafik. */
    private fun onTap() {
        val p = panel ?: return
        // Panel hanya ditutup dengan tombol X atau dengan mengetuk meter ini lagi.
        if (p.isShowing) {
            p.hide()
            return
        }
        p.show(lp.y, root?.height ?: 0)
    }

    // ---------------------------------------------------------------- data harian

    private fun loadDayCounters() {
        dayKey = usage.dayKey()
        val u = usage.get(dayKey)
        dayWifi = u.wifi
        dayMobile = u.mobile
    }

    private fun saveDayCounters() {
        if (dayKey.isNotEmpty()) usage.set(dayKey, dayWifi, dayMobile)
    }

    private fun addDayUsage(wifi: Long, mobile: Long) {
        val t = usage.dayKey()
        if (t != dayKey) { // ganti hari -> simpan hari lama, mulai dari nol
            saveDayCounters()
            usage.prune()
            dayKey = t
            val u = usage.get(t)
            dayWifi = u.wifi
            dayMobile = u.mobile
        }
        dayWifi += wifi
        dayMobile += mobile
        val nowMs = SystemClock.elapsedRealtime()
        if (nowMs - lastSaveMs >= 5_000L) {
            lastSaveMs = nowMs
            saveDayCounters()
        }
    }

    // ---------------------------------------------------------------- overlay

    private fun screenSize(): Pair<Int, Int> = Compat.realScreenSize(wm)

    /** Tinggi layar yang aman dipakai: di atas tombol navigasi, supaya tombol Home tidak tertutup. */
    private fun usableHeight(): Int = Compat.usableHeight(this, wm, prefs.safeNav)

    private var overlayType = Compat.overlayWindowType()

    /**
     * Jendela biasa (TYPE_APPLICATION_OVERLAY) otomatis disembunyikan Android saat panel notifikasi
     * ditarik dan di beberapa layar Pengaturan. Jendela aksesibilitas tidak disembunyikan, jadi kalau
     * opsinya menyala dan layanannya aktif, kita pakai itu.
     */
    private fun pickWindowManager() {
        val a = OverlayAccessibilityService.instance
        if (prefs.a11yOverlay && a != null && Build.VERSION.SDK_INT >= 22) {
            wm = a.getSystemService(WINDOW_SERVICE) as WindowManager
            overlayType = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        } else {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            overlayType = Compat.overlayWindowType()
        }
    }

    /** Meter mengambang hanya boleh tampil kalau opsinya menyala dan izinnya ada. */
    private fun overlayWanted(): Boolean = prefs.floatOverlay && Compat.canDrawOverlays(this)

    /** Samakan keadaan jendela mengambang dengan pengaturan + izin. Notifikasi tidak terpengaruh. */
    fun syncOverlay() {
        if (!started) return
        if (overlayWanted()) {
            if (root == null) safeCreateOverlay()
        } else {
            removeOverlay()
        }
    }

    private fun safeCreateOverlay() {
        try {
            createOverlay()
        } catch (_: Throwable) {
            // Izin dicabut / jendela ditolak: tetap jalan sebagai notifikasi saja.
            removeOverlay()
        }
    }

    private fun removeOverlay() {
        panel?.hide()
        panel = null
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        rowUp = null
        rowDown = null
        arrowUp = null
        arrowDown = null
        tvUp = null
        tvDown = null
    }

    /** Buat ulang jendela meter (dipanggil saat opsi aksesibilitas berubah / layanan tersambung). */
    fun recreateOverlay() {
        if (root == null) return
        removeOverlay()
        syncOverlay()
    }

    private fun createOverlay() {
        pickWindowManager()
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }

        fun makeRow(arrowText: String): Triple<LinearLayout, TextView, TextView> {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val arrow = TextView(this).apply {
                text = arrowText
                includeFontPadding = false
            }
            val speed = TextView(this).apply {
                text = "..."
                includeFontPadding = false
                gravity = Gravity.START
            }
            // Panah menempel dekat angka (jarak kecil saja).
            val alp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(3) }
            row.addView(arrow, alp)
            row.addView(speed)
            return Triple(row, arrow, speed)
        }

        // Upload di atas, download di bawah. Panah di kiri, angka di kanan.
        val (rUp, aUp, sUp) = makeRow("\u2191")
        val (rDown, aDown, sDown) = makeRow("\u2193")
        container.addView(rUp)
        container.addView(rDown)

        rowUp = rUp
        rowDown = rDown
        arrowUp = aUp
        arrowDown = aDown
        val up = sUp
        val down = sDown

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                // Dua flag ini membuat overlay boleh digeser sampai menimpa status bar (paling atas).
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.posX
            y = prefs.posY
            // Boleh menggambar di area poni/kamera juga.
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop

        // Cubit dua jari: kecilkan / besarkan meter. Bisa dikunci dari pengaturan (lockResize).
        val scaleDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleBegin(detector: ScaleGestureDetector): Boolean = !prefs.lockResize

                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    if (prefs.lockResize) return false
                    ovScale = (ovScale * detector.scaleFactor).coerceIn(MIN_SCALE, MAX_SCALE)
                    applyStyle()
                    return true
                }

                override fun onScaleEnd(detector: ScaleGestureDetector) {
                    prefs.overlayScale = ovScale
                    root?.post { clampPosition() }
                }
            })
        scaleDetector.isQuickScaleEnabled = false

        container.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var dragging = false
            private var multi = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (!prefs.lockResize) scaleDetector.onTouchEvent(e)
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x
                        startY = lp.y
                        touchX = e.rawX
                        touchY = e.rawY
                        dragging = false
                        multi = false
                        return true
                    }
                    MotionEvent.ACTION_POINTER_DOWN -> {
                        // Jari kedua menyentuh: ini cubitan, bukan geser / ketuk.
                        multi = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (multi || e.pointerCount > 1 || scaleDetector.isInProgress) return true
                        // Kunci posisi: tidak bisa digeser, tapi tetap bisa diketuk.
                        if (prefs.locked) return true
                        val dx = e.rawX - touchX
                        val dy = e.rawY - touchY
                        if (!dragging && Math.hypot(dx.toDouble(), dy.toDouble()) < slop) return true
                        dragging = true
                        val (sw, _) = screenSize()
                        val maxX = (sw - v.width).coerceAtLeast(0)
                        val maxY = (usableHeight() - v.height).coerceAtLeast(0)
                        // y = 0 berarti tepat di tepi paling atas layar (di atas status bar).
                        lp.x = (startX + dx).toInt().coerceIn(0, maxX)
                        lp.y = (startY + dy).toInt().coerceIn(0, maxY)
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (_: Exception) {
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (multi) {
                            multi = false
                            return true
                        }
                        if (dragging) {
                            prefs.posX = lp.x
                            prefs.posY = lp.y
                        } else {
                            onTap()
                        }
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        multi = false
                        return true
                    }
                }
                return false
            }
        })

        panel = TrafficPanel(this, wm, prefs, history, overlayType)
        root = container
        tvDown = down
        tvUp = up
        applyStyle()
        wm.addView(container, lp)
        // Posisi lama bisa saja berada di atas tombol navigasi: tarik kembali ke area aman.
        container.post { clampPosition() }
    }

    /** Terapkan ketebalan huruf pada satu TextView. */
    private fun styleText(tv: TextView) {
        val sizeSp = (prefs.textSize * ovScale).coerceIn(5f, 200f)
        val weight = prefs.textWeight
        val density = resources.displayMetrics.density
        val font = prefs.fontOf(Area.FLOAT)
        tv.typeface = Fonts.typeface(font, if (weight == 0) 0 else 1)
        // "Tebal banget": bold + garis tepi tipis supaya hurufnya lebih gemuk lagi.
        tv.paint.style = if (weight >= 2) Paint.Style.FILL_AND_STROKE else Paint.Style.FILL
        tv.paint.strokeWidth = if (weight >= 2) 1.1f * density * ovScale else 0f
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        tv.invalidate()
    }

    /** Terapkan warna, ukuran, ketebalan, transparansi, kunci posisi. Dipanggil tiap pengaturan berubah. */
    private fun applyStyle() {
        val container = root ?: return
        val down = tvDown ?: return
        val up = tvUp ?: return
        val aDown = arrowDown ?: return
        val aUp = arrowUp ?: return

        for (tv in listOf(down, up, aDown, aUp)) styleText(tv)
        applyColors()

        // Lebar minimum angka tetap supaya kotak tidak menyusut-melebar saat angka berubah.
        val minW = down.paint.measureText("00.00 Mbps").toInt()
        down.minWidth = minW
        up.minWidth = minW

        rowUp?.visibility = if (prefs.showUpload) View.VISIBLE else View.GONE

        val dens = resources.displayMetrics.density
        container.setPadding(
            (10 * dens * ovScale).toInt(), (6 * dens * ovScale).toInt(),
            (10 * dens * ovScale).toInt(), (6 * dens * ovScale).toInt()
        )

        val bg = prefs.bgColor
        container.background = GradientDrawable().apply {
            cornerRadius = 12f * dens * ovScale
            setColor(Color.argb(prefs.bgAlpha, Color.red(bg), Color.green(bg), Color.blue(bg)))
        }

        // Kunci posisi hanya mematikan geser; ketukan tetap membuka panel trafik.
        try {
            wm.updateViewLayout(container, lp)
        } catch (_: Exception) {
        }
        ensureRainbow()
    }

    /** Setelah ukuran berubah, pastikan meter tidak keluar dari layar. */
    private fun clampPosition() {
        val v = root ?: return
        val (sw, _) = screenSize()
        lp.x = lp.x.coerceIn(0, (sw - v.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (usableHeight() - v.height).coerceAtLeast(0))
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
        prefs.posX = lp.x
        prefs.posY = lp.y
    }

    // ---------------------------------------------------------------- notifikasi

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        // Channel lama (IMPORTANCE_MIN) menyembunyikan ikon di status bar dan importance-nya
        // tidak bisa diubah setelah dibuat, jadi dibuat channel baru dengan IMPORTANCE_LOW.
        nm.deleteNotificationChannel("speed_meter")
        val ch = NotificationChannel(CHANNEL_ID, "Speed Meter", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)
    }

    /** Ikon status bar berisi angka kecepatan, mis. "1.5" di atas "MB/s" (Android 6+). */
    private fun speedIcon(value: String, unit: String): Icon {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        p.textSize = 62f
        val vw = p.measureText(value)
        if (vw > size) p.textSize = 62f * size / vw
        c.drawText(value, size / 2f, 54f, p)

        p.textSize = 34f
        val uw = p.measureText(unit)
        if (uw > size) p.textSize = 34f * size / uw
        c.drawText(unit, size / 2f, 90f, p)
        return Icon.createWithBitmap(bmp)
    }

    private fun pi(flags: Int): Int = if (Build.VERSION.SDK_INT >= 23) flags or PendingIntent.FLAG_IMMUTABLE else flags

    /** Warna teks notifikasi: null = otomatis (ikut tema notifikasi, terang). */
    private fun notifColor(custom: Boolean, color: Int): Int? = if (custom) color else null

    private fun setNotifText(
        rv: RemoteViews, id: Int, text: CharSequence, sizeSp: Float,
        autoColorOk: Boolean = true
    ) {
        rv.setTextViewText(id, text)
        rv.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, sizeSp)
    }

    /** Total sesuai filter jaringan: Wi-Fi saja, data seluler saja, atau keduanya. */
    private fun totalFor(u: UsageStore.Usage): Long = when (prefs.netFilter) {
        1 -> u.wifi
        2 -> u.mobile
        else -> u.total
    }

    /** Baris ringkasan minggu ini + bulan ini (hanya di notifikasi yang dibentangkan). */
    private fun periodLine(): String {
        // Hari ini masih di memori (belum tentu tersimpan), jadi simpan dulu supaya jumlahnya pas.
        saveDayCounters()
        val w = totalFor(usage.week())
        val m = totalFor(usage.month())
        return "Minggu ini \u2022 ${SpeedSampler.formatSize(w)}   Bulan ini \u2022 ${SpeedSampler.formatSize(m)}"
    }

    private fun buildNotification(downBps: Double, upBps: Double): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            pi(PendingIntent.FLAG_UPDATE_CURRENT)
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            pi(PendingIntent.FLAG_UPDATE_CURRENT)
        )
        val bits = prefs.useBits
        val upT = SpeedSampler.format(upBps, bits)
        val downT = SpeedSampler.format(downBps, bits)
        val compact = prefs.notifCompact
        val speedLine = if (compact) "\u2191 $upT   \u2193 $downT" else "Unggah: $upT \u2022 Unduh: $downT"
        // Ikuti filter jaringan: "Hanya data seluler" = hanya total data seluler, "Hanya Wi-Fi" = hanya Wi-Fi.
        val usageLine = SpeedSampler.usageLine("Hari ini", dayWifi, dayMobile, prefs.netFilter)

        val rainbow = prefs.rainbowNotif
        if (rainbow) {
            val lvl = prefs.rainbowSpeedNotif
            val nowH = SystemClock.elapsedRealtime()
            // Level 0 = diam. Selain itu warna maju satu langkah tiap selang pilihan (notifikasi sendiri diperbarui ~1x/detik).
            if (lvl > 0 && nowH - lastNotifHueMs >= Rainbow.periodMs(lvl) - 50L) {
                lastNotifHueMs = nowH
                notifHue = (notifHue + 40f) % 360f
            }
        }
        val hue: Float? = if (rainbow) notifHue else null

        val spColor = notifColor(prefs.notifSpeedCustom, prefs.notifSpeedColor)
        val inColor = notifColor(prefs.notifInfoCustom, prefs.notifInfoColor)
        val spW = prefs.notifSpeedWeight
        val inW = prefs.notifInfoWeight

        val fSpeed = prefs.fontOf(Area.NSPEED)
        val speedCs = Fonts.styled(speedLine, fSpeed, spW, spColor, hue)
        val periodCs = Fonts.styled(periodLine(), prefs.fontOf(Area.IP), 0, inColor, hue)
        val usageCs = Fonts.styled(usageLine, prefs.fontOf(Area.IP), 0, inColor, hue)

        // Baris info: IP lokal \u2022 dBm \u2022 band (dBm & band hanya jika ada data), masing-masing punya font sendiri.
        val info = SpannableStringBuilder()
        var h2 = hue
        fun part(t: String, font: Int) {
            info.append(Fonts.styled(t, font, inW, inColor, h2))
            if (h2 != null) h2 = h2!! + t.length * 18f
        }
        val sepFont = prefs.fontOf(Area.IP)
        part("IP " + SignalReader.localIp(this), sepFont)
        if ((prefs.rootSignal || prefs.noRootSignal) && sigOk) {
            part(" \u2022 ", sepFont)
            part(sigDbm, prefs.fontOf(Area.DBM))
            part(" \u2022 ", sepFont)
            part(sigBand, prefs.fontOf(Area.BAND))
        }
        val infoPlain = info.toString()
        val (value, unit) = SpeedSampler.formatParts(downBps, bits)

        // Ukuran. Saat diciutkan Android hanya memberi tinggi sekitar 64dp.
        val speedSp = prefs.notifSpeedSize.toFloat()
        val infoSp = prefs.notifInfoSize.toFloat()
        var cs = speedSp
        var ci = infoSp
        // Baris total data di notifikasi yang diciutkan (satu baris di bawah kecepatan).
        var cu = prefs.notifUsageSize.toFloat()
        var infoInCollapsed = true
        when (prefs.notifCollapsed) {
            0 -> {
                // Tinggi notifikasi diciutkan sangat terbatas (+/- 40dp untuk isi). Tiga baris
                // (info, unduh/unggah, total data) harus muat semua, jadi jumlah ukuran dibatasi.
                val tot = cs + ci + cu
                if (tot > COLLAPSED_BUDGET_SP) {
                    val k = COLLAPSED_BUDGET_SP / tot
                    cs *= k
                    ci *= k
                    cu *= k
                }
                ci = maxOf(ci, 8f)
                cs = maxOf(cs, 10f)
            }
            1 -> {
                infoInCollapsed = false
                cs = minOf(cs, 24f)
                cu = minOf(cu, 16f)
            }
            else -> Unit
        }

        val small = RemoteViews(packageName, R.layout.notif_speed).apply {
            setNotifText(this, R.id.n_info, info, ci)
            setNotifText(this, R.id.n_speed, speedCs, cs)
            setNotifText(this, R.id.n_usage, usageCs, maxOf(7f, cu))
            setViewVisibility(R.id.n_info, if (infoInCollapsed) View.VISIBLE else View.GONE)
            if (inColor != null) {
                setTextColor(R.id.n_info, inColor)
                setTextColor(R.id.n_usage, inColor)
            }
            if (spColor != null) setTextColor(R.id.n_speed, spColor)
        }
        val big = RemoteViews(packageName, R.layout.notif_speed_big).apply {
            setNotifText(this, R.id.n_info, info, infoSp)
            // Unggah dan unduh sebaris (tidak dipisah dua baris lagi).
            setNotifText(this, R.id.n_speed, speedCs, minOf(speedSp, 20f))
            // "Hari ini" mengikuti ukurannya sendiri; minggu ini / bulan ini punya ukuran sendiri (hanya tampil saat ditarik ke bawah).
            setNotifText(this, R.id.n_usage, usageCs, prefs.notifUsageSize.toFloat())
            setNotifText(this, R.id.n_usage2, periodCs, prefs.notifPeriodSize.toFloat())
            if (inColor != null) {
                setTextColor(R.id.n_info, inColor)
                setTextColor(R.id.n_usage, inColor)
                setTextColor(R.id.n_usage2, inColor)
            }
            if (spColor != null) setTextColor(R.id.n_speed, spColor)
        }

        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        if (Build.VERSION.SDK_INT >= 23) b.setSmallIcon(speedIcon(value, unit))
        else b.setSmallIcon(R.drawable.ic_stat)
        b.setContentTitle(speedLine)
        b.setContentText(infoPlain)
        if (Build.VERSION.SDK_INT >= 24) {
            b.setStyle(Notification.DecoratedCustomViewStyle())
            b.setCustomContentView(small)
            b.setCustomBigContentView(big)
        } else {
            b.setContent(small)
        }
        b.setContentIntent(openIntent)
        @Suppress("DEPRECATION")
        b.addAction(R.drawable.ic_stat, "Stop", stopIntent)
        b.setOnlyAlertOnce(true)
        b.setShowWhen(false)
        b.setOngoing(true)
        if (Build.VERSION.SDK_INT < 26) {
            @Suppress("DEPRECATION")
            b.setPriority(Notification.PRIORITY_LOW)
        }
        val n = b.build()
        if (Build.VERSION.SDK_INT < 24) n.bigContentView = big
        return n
    }

    private fun goForeground() {
        val n = buildNotification(0.0, 0.0)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    companion object {
        const val ACTION_STOP = "com.example.netspeed.STOP"
        private const val CHANNEL_ID = "speed_meter_v2"
        private const val NOTIF_ID = 1001
        private const val MIN_SCALE = 0.5f
        private const val MAX_SCALE = 4f

        /** Jumlah ukuran (sp) tiga baris notifikasi diciutkan agar tidak terpotong. */
        private const val COLLAPSED_BUDGET_SP = 34f

        /** Di bawah ini dianggap "tidak ada trafik" (menghindari panah menyala karena trafik latar kecil). */
        private const val ACTIVE_BPS = 512.0

        @Volatile
        var running = false

        @Volatile
        var current: OverlayService? = null
            private set
    }
}
