package com.example.netspeed

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var lp: WindowManager.LayoutParams

    private var root: LinearLayout? = null
    private var tvDown: TextView? = null
    private var tvUp: TextView? = null

    private val handler = Handler(Looper.getMainLooper())
    private val sampler = SpeedSampler()

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, prefs.intervalMs)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        applyStyle()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Wajib dipanggil cepat setelah startForegroundService(), termasuk saat akan berhenti.
        goForeground()

        if (intent?.action == ACTION_STOP) {
            prefs.enabled = false
            stopSelf()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            prefs.enabled = false
            stopSelf()
            return START_NOT_STICKY
        }

        if (root == null) {
            createOverlay()
            prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
            sampler.reset()
            handler.removeCallbacks(ticker)
            handler.post(ticker)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(ticker)
        prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- pengukuran

    private fun tick() {
        val s = sampler.read()
        val down = tvDown ?: return
        val up = tvUp ?: return
        if (s == null) {
            down.text = "↓ N/A"
            up.text = "↑ N/A"
            return
        }
        val bits = prefs.useBits
        down.text = "↓ " + SpeedSampler.format(s.downBytesPerSec, bits).padStart(10)
        up.text = "↑ " + SpeedSampler.format(s.upBytesPerSec, bits).padStart(10)
    }

    // ---------------------------------------------------------------- overlay

    private fun createOverlay() {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        val down = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            text = "↓ ..."
            includeFontPadding = false
        }
        val up = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            text = "↑ ..."
            includeFontPadding = false
        }
        container.addView(down)
        container.addView(up)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.posX
            y = prefs.posY
        }

        container.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (prefs.locked) return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x
                        startY = lp.y
                        touchX = e.rawX
                        touchY = e.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = (startX + (e.rawX - touchX)).toInt().coerceAtLeast(0)
                        lp.y = (startY + (e.rawY - touchY)).toInt().coerceAtLeast(0)
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (_: Exception) {
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        prefs.posX = lp.x
                        prefs.posY = lp.y
                        return true
                    }
                }
                return false
            }
        })

        root = container
        tvDown = down
        tvUp = up
        applyStyle()
        wm.addView(container, lp)
    }

    /** Terapkan warna, ukuran, transparansi, kunci posisi. Dipanggil tiap pengaturan berubah. */
    private fun applyStyle() {
        val container = root ?: return
        val down = tvDown ?: return
        val up = tvUp ?: return

        down.setTextColor(prefs.downColor)
        up.setTextColor(prefs.upColor)
        down.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.textSize.toFloat())
        up.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.textSize.toFloat())
        up.visibility = if (prefs.showUpload) View.VISIBLE else View.GONE

        val bg = prefs.bgColor
        container.background = GradientDrawable().apply {
            cornerRadius = 12f * resources.displayMetrics.density
            setColor(Color.argb(prefs.bgAlpha, Color.red(bg), Color.green(bg), Color.blue(bg)))
        }

        val notTouchable = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        lp.flags = if (prefs.locked) lp.flags or notTouchable else lp.flags and notTouchable.inv()
        try {
            wm.updateViewLayout(container, lp)
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- notifikasi

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL_ID, "Speed Meter", NotificationManager.IMPORTANCE_MIN)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun goForeground() {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Speed Meter aktif")
            .setContentText("Ketuk untuk membuka pengaturan")
            .setContentIntent(openIntent)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    companion object {
        const val ACTION_STOP = "com.example.netspeed.STOP"
        private const val CHANNEL_ID = "speed_meter"
        private const val NOTIF_ID = 1001

        @Volatile
        var running = false
            private set
    }
}
