package com.example.netspeed

import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Rect
import android.os.SystemClock
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView

object Rainbow {
    /** Pelangi di panel trafik & grafik hanya ganti warna setiap sekian ms (hemat baterai/CPU). */
    const val PANEL_REFRESH_MS = 5000L

    fun color(h: Float): Int {
        val hh = ((h % 360f) + 360f) % 360f
        return Color.HSVToColor(floatArrayOf(hh, 0.85f, 1f))
    }

    fun shader(widthPx: Float, hue: Float): Shader {
        val w = if (widthPx < 1f) 1f else widthPx
        val cols = IntArray(7) { color(hue + it * 50f) }
        return LinearGradient(0f, 0f, w, 0f, cols, null, Shader.TileMode.CLAMP)
    }

    /** Posisi warna (derajat) berdasarkan waktu, jadi gerakan tetap halus walau ada frame yang telat. */
    fun timeHue(degPerSec: Float = 80f): Float =
        ((SystemClock.uptimeMillis() % 3_600_000L) / 1000f * degPerSec) % 360f

    fun collect(v: View, out: MutableList<TextView>) {
        if (v is TextView) out.add(v)
        if (v is ViewGroup) for (i in 0 until v.childCount) collect(v.getChildAt(i), out)
    }

    /** Tombol biasa (bukan Switch / RadioButton) tidak diberi warna pilihan, hanya pelangi. */
    fun isPlainButton(v: View): Boolean = v is Button && v.javaClass == Button::class.java
}

/**
 * Gradien pelangi yang dibuat SEKALI per lebar teks lalu hanya digeser (setLocalMatrix).
 * Jauh lebih ringan daripada membuat LinearGradient + array warna baru di setiap frame.
 */
class RainbowShader {
    private var w = -1f
    private var sh: LinearGradient? = null
    private val m = Matrix()

    fun get(widthPx: Float, hue: Float): Shader {
        val width = if (widthPx < 1f) 1f else widthPx
        var s = sh
        if (s == null || w != width) {
            // 13 titik warna = satu putaran penuh (0..360), diulang (REPEAT) supaya geser tanpa patah.
            val cols = IntArray(13) { Rainbow.color(it * 30f) }
            s = LinearGradient(0f, 0f, width, 0f, cols, null, Shader.TileMode.REPEAT)
            sh = s
            w = width
        }
        m.setTranslate(-((((hue % 360f) + 360f) % 360f) / 360f) * width, 0f)
        s.setLocalMatrix(m)
        return s
    }
}

/**
 * Menjalankan animasi pelangi pada semua TextView selama aktif.
 * enabled() dicek tiap putaran; saat dimatikan, warna dikembalikan lewat restore().
 */
class RainbowSweeper(
    private val enabled: () -> Boolean,
    private val views: () -> List<TextView>,
    private val restore: (TextView) -> Unit,
    private val periodMs: Long = 33L
) {
    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var wasOn = false
    private val cache = java.util.WeakHashMap<TextView, RainbowShader>()
    private val vis = Rect()

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val on = enabled()
            if (on) {
                val hue = Rainbow.timeHue()
                for (tv in views()) {
                    if (tv.text.isNullOrEmpty()) continue
                    // Teks yang tidak terlihat (di luar layar) tidak perlu digambar ulang.
                    if (!tv.getGlobalVisibleRect(vis)) continue
                    val rs = cache.getOrPut(tv) { RainbowShader() }
                    tv.paint.shader = rs.get(tv.width.toFloat(), hue)
                    tv.invalidate()
                }
            } else if (wasOn) {
                for (tv in views()) {
                    tv.paint.shader = null
                    restore(tv)
                    tv.invalidate()
                }
            }
            wasOn = on
            h.postDelayed(this, periodMs)
        }
    }

    fun start() {
        if (running) return
        running = true
        h.post(tick)
    }

    fun stop() {
        running = false
        h.removeCallbacks(tick)
    }
}
