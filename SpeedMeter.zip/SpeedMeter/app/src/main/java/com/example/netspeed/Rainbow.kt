package com.example.netspeed

import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView

object Rainbow {
    fun color(h: Float): Int {
        val hh = ((h % 360f) + 360f) % 360f
        return Color.HSVToColor(floatArrayOf(hh, 0.85f, 1f))
    }

    fun shader(widthPx: Float, hue: Float): Shader {
        val w = if (widthPx < 1f) 1f else widthPx
        val cols = IntArray(7) { color(hue + it * 50f) }
        return LinearGradient(0f, 0f, w, 0f, cols, null, Shader.TileMode.CLAMP)
    }

    fun collect(v: View, out: MutableList<TextView>) {
        if (v is TextView) out.add(v)
        if (v is ViewGroup) for (i in 0 until v.childCount) collect(v.getChildAt(i), out)
    }

    /** Tombol biasa (bukan Switch / RadioButton) tidak diberi warna pilihan, hanya pelangi. */
    fun isPlainButton(v: View): Boolean = v is Button && v.javaClass == Button::class.java
}

/**
 * Menjalankan animasi pelangi pada semua TextView selama aktif.
 * enabled() dicek tiap putaran; saat dimatikan, warna dikembalikan lewat restore().
 */
class RainbowSweeper(
    private val enabled: () -> Boolean,
    private val views: () -> List<TextView>,
    private val restore: (TextView) -> Unit,
    private val periodMs: Long = 90L
) {
    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var wasOn = false
    private var hue = 0f

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val on = enabled()
            if (on) {
                hue = (hue + 7f) % 360f
                for (tv in views()) {
                    if (tv.text.isNullOrEmpty()) continue
                    tv.paint.shader = Rainbow.shader(tv.width.toFloat(), hue)
                    tv.invalidate()
                }
            } else if (wasOn) {
                for (tv in views()) {
                    tv.paint.shader = null
                    restore(tv)
                    tv.invalidate()
                }
            }
            wasOn = on
            h.postDelayed(this, periodMs)
        }
    }

    fun start() {
        if (running) return
        running = true
        h.post(tick)
    }

    fun stop() {
        running = false
        h.removeCallbacks(tick)
    }
}
