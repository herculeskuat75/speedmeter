package com.example.netspeed

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.util.TypedValue
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/** Riwayat kecepatan terakhir (byte/detik). Diisi oleh OverlayService tiap pengukuran. */
class SpeedHistory(val cap: Int = 900) {
    val down = ArrayList<Double>()
    val up = ArrayList<Double>()
    /** true = ada internet tersambung saat sampel ini diambil */
    val conn = ArrayList<Boolean>()

    val size: Int get() = down.size

    /** jumlah seluruh sampel yang pernah masuk (tidak berkurang saat riwayat dipangkas) */
    var total = 0L
        private set

    fun add(d: Double, u: Double, connected: Boolean = true) {
        down.add(d)
        up.add(u)
        conn.add(connected)
        total++
        if (down.size > cap) {
            down.removeAt(0)
            up.removeAt(0)
            conn.removeAt(0)
        }
    }

    /** true = download sedang naik dibanding rata-rata beberapa detik sebelumnya (hijau), false = turun (merah). */
    fun trendUp(): Boolean {
        val n = down.size
        if (n < 2) return true
        val from = maxOf(0, n - 6)
        var s = 0.0
        var c = 0
        for (i in from until n - 1) {
            s += down[i]
            c++
        }
        return down[n - 1] >= s / c
    }
}

/**
 * Grafik ala monitor jantung (EKG) rumah sakit:
 *  - garis dasar di TENGAH; sebuah titik menyapu dari kiri ke kanan, menggambar jejaknya, lalu
 *    kembali ke kiri dan menimpa jejak lama (ada celah kosong di depan titik);
 *  - tinggi garis = kecepatan dibanding rata-rata beberapa detik terakhir:
 *    di tengah = tidak ada perubahan / tidak ada internet (garis lurus biru),
 *    naik ke atas (hijau) saat kecepatan naik, turun ke bawah (merah) saat melambat;
 *  - titik di ujung kanan: biru = lurus, hijau = naik, merah = turun, dan sebuah panah berkedip
 *    menunjukkan arah (hijau terang naik / merah terang turun);
 *  - cubit dua jari = zoom (horizontal = rentang waktu, vertikal = skala), geser = pindah,
 *    ketuk 2x = kembali ke tampilan awal (live).
 */
class SpeedGraphView(context: Context, private val history: SpeedHistory) : View(context) {

    var useBits = false
    var showUp = true

    /** true = cubit dua jari di grafik mengubah zoom grafik; false = cubit dikendalikan panel (seluruh panel mengecil). */
    var pinchEnabled = false

    /** true = angka sumbu / keterangan di grafik berwarna pelangi */
    var rainbowText = false

    /** titik penyapu berkedip */
    var dotBlink = true

    /** kecepatan pelangi 0..10 (0 = diam) */
    var rainbowSpeed = 1

    /** true = titik memakai dotColorValue, false = ikut warna tren (hijau / merah / biru) */
    var dotCustom = false
    var dotColorValue = Color.parseColor("#00E5FF")

    // gradien pelangi di-cache; warnanya hanya diganti tiap Rainbow.PANEL_REFRESH_MS
    private var rbBucket = -1L
    private var rbWidth = -1f
    private var rbShader: android.graphics.Shader? = null

    /** font untuk semua tulisan di grafik */
    var textTypeface: Typeface = Typeface.MONOSPACE
        set(v) {
            field = v
            axisText.typeface = v
            hintText.typeface = v
            tagText.typeface = Typeface.create(v, Typeface.BOLD)
            invalidate()
        }

    /** selang antar sampel (ms), dipakai untuk menggerakkan titik dengan mulus di antara dua sampel */
    var intervalMs = 1000L
    private var lastSampleMs = SystemClock.uptimeMillis()

    /** jumlah sampel yang terlihat di lebar grafik */
    var visibleCount = DEFAULT_VISIBLE
        private set
    private var offset = 0f      // berapa sampel ke belakang dari yang terbaru (0 = live)
    private var yZoom = 1.0
    private var yPan = 0.0       // pergeseran titik tengah (satuan byte/detik)

    private val d = resources.displayMetrics.density
    private fun spPx(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private val blue = Color.parseColor("#448AFF")
    private val green = Color.parseColor("#00E676")
    private val red = Color.parseColor("#FF1744")

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(40, 255, 255, 255)
        strokeWidth = d
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(4f * d, 4f * d), 0f)
    }
    private val midPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 255, 255, 255)
        strokeWidth = d
        style = Paint.Style.STROKE
    }
    private val axisText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 255, 255, 255)
        textSize = spPx(9f)
        typeface = Typeface.MONOSPACE
    }
    private val hintText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(190, 255, 255, 255)
        textSize = spPx(9f)
    }
    private val segPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val upPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(170, 255, 179, 0)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val arrowFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tagText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = spPx(9f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val fillPath = Path()
    private val upPath = Path()
    private val arrowPath = Path()
    private val tagRect = RectF()

    // buffer garis per warna (x1,y1,x2,y2 berurutan)
    private val bufGreen = FloatArray(history.cap * 4)
    private val bufRed = FloatArray(history.cap * 4)
    private val bufBlue = FloatArray(history.cap * 4)

    // selisih terhadap rata-rata bergerak (EMA): 0 = di tengah
    private val dispD = DoubleArray(history.cap + 8)
    private val dispU = DoubleArray(history.cap + 8)

    // ukuran terakhir hasil onDraw, dipakai saat menggeser
    private var lastStep = 1f
    private var lastPlotH = 1f
    private var lastRange = 1.0
    private var lastBaseAmp = 1.0

    // ------------------------------------------------------------------ sentuhan

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(det: ScaleGestureDetector): Boolean {
                val minSpan = 20f * d
                val px = det.previousSpanX
                val py = det.previousSpanY
                // Cubitan mendatar mengubah rentang waktu, cubitan tegak mengubah skala kecepatan.
                var rx = if (px > minSpan) (det.currentSpanX / px).coerceIn(0.5f, 2f) else 1f
                val ry = if (py > minSpan) (det.currentSpanY / py).coerceIn(0.5f, 2f) else 1f
                // Jari terlalu dekat di kedua sumbu: pakai faktor skala biasa untuk waktu.
                if (rx == 1f && ry == 1f) rx = det.scaleFactor.coerceIn(0.5f, 2f)
                if (rx == 1f && ry == 1f) return true
                visibleCount = (visibleCount / rx).coerceIn(MIN_VISIBLE, history.cap.toFloat())
                yZoom = (yZoom * ry).coerceIn(0.1, 60.0)
                clampOffset()
                invalidate()
                return true
            }
        })

    private val gestures = GestureDetector(context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (scaleDetector.isInProgress) return false
                // dx/dy = posisi lama dikurangi posisi baru, jadi tandanya dibalik.
                offset -= dx / lastStep
                clampOffset()
                yPan += (-dy / lastPlotH).toDouble() * lastRange
                yPan = yPan.coerceIn(-lastBaseAmp * 3.0, lastBaseAmp * 3.0)
                invalidate()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                resetView()
                return true
            }
        })

    init {
        scaleDetector.isQuickScaleEnabled = false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) parent?.requestDisallowInterceptTouchEvent(true)
        if (pinchEnabled) scaleDetector.onTouchEvent(e)
        gestures.onTouchEvent(e)
        return true
    }

    fun resetView() {
        visibleCount = DEFAULT_VISIBLE
        offset = 0f
        yZoom = 1.0
        yPan = 0.0
        invalidate()
    }

    /** Dipanggil panel tiap sampel baru: kalau sedang melihat riwayat, tampilan dibiarkan diam. */
    fun onSampleAdded() {
        lastSampleMs = SystemClock.uptimeMillis()
        if (offset > 0f) offset += 1f
        clampOffset()
        invalidate()
    }

    private fun clampOffset() {
        val maxOff = (history.size - 2).coerceAtLeast(0).toFloat()
        offset = offset.coerceIn(0f, maxOff)
    }

    val isLive: Boolean get() = offset <= 0f

    // ------------------------------------------------------------------ gambar

    private fun niceMax(v: Double): Double {
        val m = maxOf(v, 20.0 * 1024.0)
        val e = Math.pow(10.0, Math.floor(Math.log10(m)))
        val f = m / e
        val nf = when {
            f <= 1.0 -> 1.0
            f <= 2.0 -> 2.0
            f <= 5.0 -> 5.0
            else -> 10.0
        }
        return nf * e
    }

    private fun computeDisp(n: Int) {
        var ed = history.down[0]
        var eu = history.up[0]
        for (i in 0 until n) {
            ed += (history.down[i] - ed) * EMA_ALPHA
            eu += (history.up[i] - eu) * EMA_ALPHA
            dispD[i] = history.down[i] - ed
            dispU[i] = history.up[i] - eu
        }
    }

    /** 1 = naik, -1 = turun, 0 = lurus / tidak ada internet */
    private fun trend(n: Int, amp: Double): Int {
        if (n < 2 || !history.conn[n - 1]) return 0
        val from = maxOf(0, n - 6)
        var s = 0.0
        var c = 0
        for (i in from until n - 1) {
            s += history.down[i]
            c++
        }
        val diff = history.down[n - 1] - s / c
        val thr = amp * 0.05
        return if (diff > thr) 1 else if (diff < -thr) -1 else 0
    }

    private fun signed(v: Double): String {
        if (Math.abs(v) < 1.0) return "0"
        val t = SpeedSampler.format(Math.abs(v), useBits)
        return if (v > 0) "+$t" else "-$t"
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val n = history.size

        if (rainbowText) {
            val per = Rainbow.periodMs(rainbowSpeed)
            val bucket = if (per <= 0L) 0L else SystemClock.uptimeMillis() / per
            if (rbShader == null || bucket != rbBucket || w != rbWidth) {
                rbShader = Rainbow.shader(w, Rainbow.hueFor(rainbowSpeed))
                rbBucket = bucket
                rbWidth = w
            }
            axisText.shader = rbShader
            hintText.shader = rbShader
        } else {
            axisText.shader = null
            hintText.shader = null
        }

        val labelW = tagText.measureText("1023.9 KB/s") + 8f * d
        val left = 4f * d
        val right = w - labelW
        val top = 10f * d
        val bottom = h - 10f * d
        val plotW = right - left
        val plotH = bottom - top
        if (plotW <= 0f || plotH <= 0f) return

        // Mode "monitor jantung": titik menyapu dari kiri ke kanan lalu kembali ke kiri dan menimpa
        // garis lama. Kalau pengguna menggeser ke riwayat, berganti ke mode gulir biasa.
        val sweep = offset <= 0f
        val count = visibleCount.coerceIn(MIN_VISIBLE, history.cap.toFloat())
        val cols = count.toInt().coerceAtLeast(10)
        val step = plotW / (if (sweep) cols - 1f else count - 1f)
        val base = history.total - n               // nomor urut mutlak sampel ke-0 di daftar
        val endF = (maxOf(n, 1) - 1).toFloat() - offset
        val startF = maxOf(0f, endF - (count - 1f))
        val i0: Int
        val i1: Int
        if (sweep) {
            i0 = maxOf(0, n - cols)
            i1 = maxOf(0, n - 1)
        } else {
            i0 = Math.floor(startF.toDouble()).toInt().coerceIn(0, maxOf(0, n - 1))
            i1 = Math.ceil(endF.toDouble()).toInt().coerceIn(0, maxOf(0, n - 1))
        }
        val gap = maxOf(2, cols / 25)              // celah kosong di depan titik (seperti monitor RS)

        fun col(i: Int): Int = ((base + i) % cols).toInt()
        val p = if (n > 0) col(n - 1) else 0
        fun hidden(i: Int): Boolean {
            if (!sweep) return false
            val dc = (col(i) - p + cols) % cols
            return dc in 1..gap
        }
        fun xOf(i: Int): Float =
            if (sweep) left + col(i) * step else left + (i - startF) * step
        // dua sampel berurutan disambung garis, kecuali melewati ujung kanan -> kiri atau celah
        fun linked(i: Int): Boolean {
            if (!sweep) return true
            return col(i) + 1 == col(i + 1) && !hidden(i) && !hidden(i + 1)
        }

        if (n >= 1) computeDisp(n)

        // skala: simetris di sekitar tengah, otomatis dari data yang terlihat, lalu zoom & geser pengguna
        var peak = 0.0
        if (n >= 1) {
            for (i in i0..i1) {
                val a = Math.abs(dispD[i])
                if (a > peak) peak = a
                if (showUp) {
                    val b = Math.abs(dispU[i])
                    if (b > peak) peak = b
                }
            }
        }
        val baseAmp = niceMax(peak * 1.15)
        val range = 2.0 * baseAmp / yZoom
        val viewMin = yPan - range / 2.0
        lastStep = step
        lastPlotH = plotH
        lastRange = range
        lastBaseAmp = baseAmp

        fun yOf(v: Double): Float = bottom - ((v - viewMin) / range).toFloat() * plotH

        // garis kisi: tengah (0) lebih jelas, label di kanan
        for (k in -2..2) {
            val v = baseAmp * k / 2.0
            val y = yOf(v)
            if (y < top - 2f * d || y > bottom + 2f * d) continue
            canvas.drawLine(left, y, right, y, if (k == 0) midPaint else gridPaint)
            val ty = (y + axisText.textSize / 3f).coerceIn(top + axisText.textSize / 2f, h)
            canvas.drawText(signed(v), right + 4f * d, ty, axisText)
        }

        val zeroY = yOf(0.0)
        val lastConn = n >= 1 && history.conn[n - 1]
        val tr = trend(n, baseAmp)
        val trendCol = if (tr > 0) green else if (tr < 0) red else blue
        val dotCol = if (dotCustom) dotColorValue else trendCol
        // kedipan titik: 0.15..1.0 (atau tetap 1 bila kedip dimatikan)
        val blinkK = if (dotBlink) (0.15 + 0.85 * (0.5 + 0.5 * Math.sin(SystemClock.uptimeMillis() / 160.0))).toFloat() else 1f
        val dotCore = Color.argb((255 * blinkK).toInt(), Color.red(dotCol), Color.green(dotCol), Color.blue(dotCol))
        val dotHalo = Color.argb((70 * blinkK).toInt(), Color.red(dotCol), Color.green(dotCol), Color.blue(dotCol))

        if (n < 2) {
            // belum ada data: titik besar di kiri-tengah
            dotPaint.color = dotHalo
            canvas.drawCircle(left + 8f * d, zeroY, 11f * d, dotPaint)
            dotPaint.color = dotCore
            canvas.drawCircle(left + 8f * d, zeroY, 6f * d, dotPaint)
            postInvalidateDelayed(if (dotBlink) 50 else 200)
            return
        }

        canvas.save()
        canvas.clipRect(left, 0f, right + 1f, h)

        // upload (di belakang, tipis)
        if (showUp) {
            upPath.reset()
            var started = false
            for (i in i0..i1) {
                if (sweep && hidden(i)) {
                    started = false
                    continue
                }
                val x = xOf(i)
                val y = yOf(dispU[i])
                if (!started || (sweep && i > i0 && !linked(i - 1))) {
                    upPath.moveTo(x, y)
                    started = true
                } else {
                    upPath.lineTo(x, y)
                }
            }
            canvas.drawPath(upPath, upPaint)
        }

        // mode gulir: area antara garis dan garis tengah
        if (!sweep) {
            fillPath.reset()
            fillPath.moveTo(xOf(i0), zeroY)
            for (i in i0..i1) fillPath.lineTo(xOf(i), yOf(dispD[i]))
            fillPath.lineTo(xOf(i1), zeroY)
            fillPath.close()
            fillPaint.color = Color.argb(45, Color.red(trendCol), Color.green(trendCol), Color.blue(trendCol))
            canvas.drawPath(fillPath, fillPaint)
        }

        // garis per segmen: hijau = naik, merah = turun, biru = lurus / tidak ada internet
        val flatThr = range * 0.012
        var ng = 0
        var nr = 0
        var nb = 0
        for (i in i0 until i1) {
            if (!linked(i)) continue
            val a = dispD[i]
            val b = dispD[i + 1]
            val x1 = xOf(i)
            val y1 = yOf(a)
            val x2 = xOf(i + 1)
            val y2 = yOf(b)
            val flat = !history.conn[i + 1] || Math.abs(b - a) < flatThr
            if (flat) {
                bufBlue[nb++] = x1; bufBlue[nb++] = y1; bufBlue[nb++] = x2; bufBlue[nb++] = y2
            } else if (b > a) {
                bufGreen[ng++] = x1; bufGreen[ng++] = y1; bufGreen[ng++] = x2; bufGreen[ng++] = y2
            } else {
                bufRed[nr++] = x1; bufRed[nr++] = y1; bufRed[nr++] = x2; bufRed[nr++] = y2
            }
        }
        segPaint.color = blue
        canvas.drawLines(bufBlue, 0, nb, segPaint)
        segPaint.color = green
        canvas.drawLines(bufGreen, 0, ng, segPaint)
        segPaint.color = red
        canvas.drawLines(bufRed, 0, nr, segPaint)

        var dotY = zeroY
        if (sweep) {
            // titik penyapu: bergerak mulus ke kanan di antara dua sampel, menyisakan garis lurus di belakangnya
            val iv = intervalMs.coerceAtLeast(200L)
            val frac = ((SystemClock.uptimeMillis() - lastSampleMs).toFloat() / iv).coerceIn(0f, 1f)
            val sx = xOf(n - 1)
            val lx = minOf(sx + frac * step, right)
            dotY = yOf(dispD[n - 1])
            segPaint.color = trendCol
            canvas.drawLine(sx, dotY, lx, dotY, segPaint)

            dotPaint.color = dotHalo
            canvas.drawCircle(lx, dotY, 11f * d, dotPaint)
            dotPaint.color = dotCore
            canvas.drawCircle(lx, dotY, 6f * d, dotPaint)

            // panah berkedip: hijau terang = naik, merah terang = turun
            if (tr != 0) {
                val phase = 0.5 + 0.5 * Math.sin(SystemClock.uptimeMillis() / 230.0)
                val alpha = (60 + 195 * phase).toInt().coerceIn(0, 255)
                val c = if (tr > 0) green else red
                arrowFill.color = Color.argb(alpha, Color.red(c), Color.green(c), Color.blue(c))
                val cx = (lx - 22f * d).coerceIn(left + 12f * d, right - 12f * d)
                val cy = (dotY + (if (tr > 0) -24f * d else 24f * d)).coerceIn(top + 12f * d, bottom - 12f * d)
                drawBigArrow(canvas, cx, cy, tr > 0)
            }
        }
        canvas.restore()

        if (sweep) {
            val txt = SpeedSampler.format(history.down[n - 1], useBits)
            val tagH = 16f * d
            val tagTop = (dotY - tagH / 2f).coerceIn(0f, h - tagH)
            tagRect.set(right + 2f * d, tagTop, w - 1f * d, tagTop + tagH)
            tagPaint.color = trendCol
            canvas.drawRoundRect(tagRect, 4f * d, 4f * d, tagPaint)
            canvas.drawText(txt, tagRect.centerX(), tagRect.centerY() + tagText.textSize / 3f, tagText)
        }

        if (!lastConn) {
            canvas.drawText("Tidak ada internet", left + 6f * d, top + hintText.textSize, hintText)
        } else if (!sweep) {
            canvas.drawText(
                "Riwayat \u2022 ketuk 2x untuk kembali live",
                left + 6f * d, top + hintText.textSize, hintText
            )
        }

        // gerak titik & kedipan panah butuh gambar ulang terus selama mode live
        if (sweep) postInvalidateDelayed(50) else if (rainbowText && rainbowSpeed > 0) postInvalidateDelayed(maxOf(33L, Rainbow.periodMs(rainbowSpeed)))
    }

    /** Panah gemuk menunjuk ke atas (naik) atau ke bawah (turun), berpusat di (cx, cy). */
    private fun drawBigArrow(c: Canvas, cx: Float, cy: Float, up: Boolean) {
        val s = if (up) 1f else -1f
        arrowPath.reset()
        arrowPath.moveTo(cx, cy - s * 11f * d)
        arrowPath.lineTo(cx + 9f * d, cy)
        arrowPath.lineTo(cx + 3.5f * d, cy)
        arrowPath.lineTo(cx + 3.5f * d, cy + s * 11f * d)
        arrowPath.lineTo(cx - 3.5f * d, cy + s * 11f * d)
        arrowPath.lineTo(cx - 3.5f * d, cy)
        arrowPath.lineTo(cx - 9f * d, cy)
        arrowPath.close()
        c.drawPath(arrowPath, arrowFill)
    }

    companion object {
        const val DEFAULT_VISIBLE = 60f
        const val MIN_VISIBLE = 10f
        private const val EMA_ALPHA = 0.07
    }
}
