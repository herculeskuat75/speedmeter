package com.example.netspeed

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.util.TypedValue
import android.view.View

/** Riwayat kecepatan terakhir (byte/detik). Diisi oleh OverlayService tiap pengukuran. */
class SpeedHistory(val cap: Int = 90) {
    val down = ArrayList<Double>()
    val up = ArrayList<Double>()

    val size: Int get() = down.size

    fun add(d: Double, u: Double) {
        down.add(d)
        up.add(u)
        if (down.size > cap) {
            down.removeAt(0)
            up.removeAt(0)
        }
    }

    /** true = download sedang naik dibanding rata-rata beberapa detik sebelumnya (hijau), false = turun (merah). */
    fun trendUp(): Boolean {
        val n = down.size
        if (n < 2) return true
        val from = maxOf(0, n - 6)
        var s = 0.0
        var c = 0
        for (i in from until n - 1) {
            s += down[i]
            c++
        }
        return down[n - 1] >= s / c
    }
}

/**
 * Grafik garis naik-turun seperti grafik saham: garis download (hijau saat naik, merah saat turun)
 * dengan area berwarna di bawahnya, garis upload tipis, garis putus-putus + label harga di kanan.
 */
class SpeedGraphView(context: Context, private val history: SpeedHistory) : View(context) {

    var useBits = false
    var showUp = true

    private val d = resources.displayMetrics.density
    private fun spPx(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private val up = Color.parseColor("#FFB300")
    private val green = Color.parseColor("#00C853")
    private val red = Color.parseColor("#FF5252")

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 255, 255, 255)
        strokeWidth = d
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(4f * d, 4f * d), 0f)
    }
    private val axisText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 255, 255, 255)
        textSize = spPx(9f)
        typeface = Typeface.MONOSPACE
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val upPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(220, 255, 179, 0)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tagText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = spPx(9f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val lastLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
        pathEffect = DashPathEffect(floatArrayOf(3f * d, 3f * d), 0f)
    }

    private val linePath = Path()
    private val fillPath = Path()
    private val upPath = Path()
    private val tagRect = RectF()

    private fun niceMax(v: Double): Double {
        val m = maxOf(v, 20.0 * 1024.0)
        val e = Math.pow(10.0, Math.floor(Math.log10(m)))
        val f = m / e
        val nf = when {
            f <= 1.0 -> 1.0
            f <= 2.0 -> 2.0
            f <= 5.0 -> 5.0
            else -> 10.0
        }
        return nf * e
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val n = history.size

        val labelW = tagText.measureText("1023.9 KB/s") + 8f * d
        val left = 4f * d
        val right = w - labelW
        val top = 10f * d
        val bottom = h - 10f * d
        val plotW = right - left
        val plotH = bottom - top
        if (plotW <= 0f || plotH <= 0f) return

        var peak = 0.0
        for (v in history.down) if (v > peak) peak = v
        if (showUp) for (v in history.up) if (v > peak) peak = v
        val maxV = niceMax(peak * 1.1)

        fun yOf(v: Double): Float = bottom - (v / maxV).coerceIn(0.0, 1.0).toFloat() * plotH

        // garis kisi + label sumbu Y
        for (i in 0..3) {
            val y = top + plotH * i / 3f
            canvas.drawLine(left, y, right, y, gridPaint)
            val label = SpeedSampler.format(maxV * (1.0 - i / 3.0), useBits)
            val ty = (y + axisText.textSize / 3f).coerceIn(top + axisText.textSize / 2f, h)
            canvas.drawText(label, right + 4f * d, ty, axisText)
        }

        if (n < 2) return

        val step = plotW / (history.cap - 1).toFloat()
        fun xOf(i: Int): Float = right - (n - 1 - i) * step

        // upload (di belakang)
        if (showUp) {
            upPath.reset()
            for (i in 0 until n) {
                val x = xOf(i)
                val y = yOf(history.up[i])
                if (i == 0) upPath.moveTo(x, y) else upPath.lineTo(x, y)
            }
            canvas.drawPath(upPath, upPaint)
        }

        // download
        val col = if (history.trendUp()) green else red
        linePath.reset()
        fillPath.reset()
        for (i in 0 until n) {
            val x = xOf(i)
            val y = yOf(history.down[i])
            if (i == 0) {
                linePath.moveTo(x, y)
                fillPath.moveTo(x, bottom)
                fillPath.lineTo(x, y)
            } else {
                linePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(xOf(n - 1), bottom)
        fillPath.close()

        fillPaint.shader = LinearGradient(
            0f, top, 0f, bottom,
            Color.argb(120, Color.red(col), Color.green(col), Color.blue(col)),
            Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(fillPath, fillPaint)
        linePaint.color = col
        canvas.drawPath(linePath, linePaint)

        // titik + garis putus-putus + label nilai terakhir
        val lx = xOf(n - 1)
        val ly = yOf(history.down[n - 1])
        lastLine.color = Color.argb(170, Color.red(col), Color.green(col), Color.blue(col))
        canvas.drawLine(left, ly, right, ly, lastLine)

        dotPaint.color = Color.argb(70, Color.red(col), Color.green(col), Color.blue(col))
        canvas.drawCircle(lx, ly, 7f * d, dotPaint)
        dotPaint.color = col
        canvas.drawCircle(lx, ly, 3.5f * d, dotPaint)

        val txt = SpeedSampler.format(history.down[n - 1], useBits)
        val tagH = 16f * d
        val tagTop = (ly - tagH / 2f).coerceIn(0f, h - tagH)
        tagRect.set(right + 2f * d, tagTop, w - 1f * d, tagTop + tagH)
        tagPaint.color = col
        canvas.drawRoundRect(tagRect, 4f * d, 4f * d, tagPaint)
        canvas.drawText(txt, tagRect.centerX(), tagRect.centerY() + tagText.textSize / 3f, tagText)
    }
}
