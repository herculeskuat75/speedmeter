package com.example.netspeed

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.util.TypedValue
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/** Riwayat kecepatan terakhir (byte/detik). Diisi oleh OverlayService tiap pengukuran. */
class SpeedHistory(val cap: Int = 900) {
    val down = ArrayList<Double>()
    val up = ArrayList<Double>()
    /** true = ada internet tersambung saat sampel ini diambil */
    val conn = ArrayList<Boolean>()

    val size: Int get() = down.size

    fun add(d: Double, u: Double, connected: Boolean = true) {
        down.add(d)
        up.add(u)
        conn.add(connected)
        if (down.size > cap) {
            down.removeAt(0)
            up.removeAt(0)
            conn.removeAt(0)
        }
    }

    /** true = download sedang naik dibanding rata-rata beberapa detik sebelumnya (hijau), false = turun (merah). */
    fun trendUp(): Boolean {
        val n = down.size
        if (n < 2) return true
        val from = maxOf(0, n - 6)
        var s = 0.0
        var c = 0
        for (i in from until n - 1) {
            s += down[i]
            c++
        }
        return down[n - 1] >= s / c
    }
}

/**
 * Grafik seperti layar saham:
 *  - digambar dari KIRI ke KANAN, data terbaru di kanan, terus bergerak;
 *  - lurus (abu-abu) saat tidak ada internet / tidak ada trafik, naik (hijau) saat kecepatan naik,
 *    turun (merah) saat melambat;
 *  - panah oranye/merah mengikuti tiap rangkaian naik / turun, seperti contoh gambar analisis saham;
 *  - cubit dua jari = zoom (horizontal = rentang waktu, vertikal = skala kecepatan),
 *    geser satu jari = pindah ke mana saja, ketuk 2x = kembali ke tampilan awal (live).
 */
class SpeedGraphView(context: Context, private val history: SpeedHistory) : View(context) {

    var useBits = false
    var showUp = true

    /** jumlah sampel yang terlihat di lebar grafik */
    var visibleCount = DEFAULT_VISIBLE
        private set
    private var offset = 0f      // berapa sampel ke belakang dari yang terbaru (0 = live)
    private var yZoom = 1.0
    private var yPan = 0.0

    private val d = resources.displayMetrics.density
    private fun spPx(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private val green = Color.parseColor("#00C853")
    private val red = Color.parseColor("#FF5252")
    private val grey = Color.argb(200, 170, 180, 190)
    private val orange = Color.parseColor("#FF9800")

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 255, 255, 255)
        strokeWidth = d
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(4f * d, 4f * d), 0f)
    }
    private val axisText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 255, 255, 255)
        textSize = spPx(9f)
        typeface = Typeface.MONOSPACE
    }
    private val hintText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(190, 255, 255, 255)
        textSize = spPx(9f)
    }
    private val segPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val upPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.3f * d
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(200, 255, 179, 0)
    }
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tagText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = spPx(9f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val lastLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
        pathEffect = DashPathEffect(floatArrayOf(3f * d, 3f * d), 0f)
    }

    private val fillPath = Path()
    private val upPath = Path()
    private val tagRect = RectF()

    // buffer garis per warna (x1,y1,x2,y2 berurutan)
    private val bufGreen = FloatArray(history.cap * 4)
    private val bufRed = FloatArray(history.cap * 4)
    private val bufGrey = FloatArray(history.cap * 4)

    // ukuran terakhir hasil onDraw, dipakai saat menggeser
    private var lastStep = 1f
    private var lastPlotH = 1f
    private var lastRange = 1.0
    private var lastBaseMax = 1.0

    // ------------------------------------------------------------------ sentuhan

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(det: ScaleGestureDetector): Boolean {
                val minSpan = 30f * d
                val px = det.previousSpanX
                val py = det.previousSpanY
                // Cubitan mendatar mengubah rentang waktu, cubitan tegak mengubah skala kecepatan.
                val rx = if (px > minSpan) (det.currentSpanX / px).coerceIn(0.5f, 2f) else 1f
                val ry = if (py > minSpan) (det.currentSpanY / py).coerceIn(0.5f, 2f) else 1f
                if (rx == 1f && ry == 1f) return true
                visibleCount = (visibleCount / rx).coerceIn(MIN_VISIBLE, history.cap.toFloat())
                yZoom = (yZoom * ry).coerceIn(0.2, 60.0)
                clampOffset()
                invalidate()
                return true
            }
        })

    private val gestures = GestureDetector(context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (scaleDetector.isInProgress) return false
                // dx/dy = jarak jari bergerak dikurangi... (lama - baru), jadi tandanya dibalik.
                offset -= dx / lastStep
                clampOffset()
                yPan += (-dy / lastPlotH).toDouble() * lastRange
                yPan = yPan.coerceIn(-lastBaseMax * 0.5, lastBaseMax * 3.0)
                invalidate()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                resetView()
                return true
            }
        })

    init {
        scaleDetector.isQuickScaleEnabled = false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) parent?.requestDisallowInterceptTouchEvent(true)
        scaleDetector.onTouchEvent(e)
        gestures.onTouchEvent(e)
        return true
    }

    fun resetView() {
        visibleCount = DEFAULT_VISIBLE
        offset = 0f
        yZoom = 1.0
        yPan = 0.0
        invalidate()
    }

    /** Dipanggil panel tiap sampel baru: kalau sedang melihat riwayat, tampilan dibiarkan diam. */
    fun onSampleAdded() {
        if (offset > 0f) offset += 1f
        clampOffset()
        invalidate()
    }

    private fun clampOffset() {
        val maxOff = (history.size - 2).coerceAtLeast(0).toFloat()
        offset = offset.coerceIn(0f, maxOff)
    }

    val isLive: Boolean get() = offset <= 0f

    // ------------------------------------------------------------------ gambar

    private fun niceMax(v: Double): Double {
        val m = maxOf(v, 20.0 * 1024.0)
        val e = Math.pow(10.0, Math.floor(Math.log10(m)))
        val f = m / e
        val nf = when {
            f <= 1.0 -> 1.0
            f <= 2.0 -> 2.0
            f <= 5.0 -> 5.0
            else -> 10.0
        }
        return nf * e
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val n = history.size

        val labelW = tagText.measureText("1023.9 KB/s") + 8f * d
        val left = 4f * d
        val right = w - labelW
        val top = 10f * d
        val bottom = h - 10f * d
        val plotW = right - left
        val plotH = bottom - top
        if (plotW <= 0f || plotH <= 0f) return

        val count = visibleCount.coerceIn(MIN_VISIBLE, history.cap.toFloat())
        val step = plotW / (count - 1f)
        val endF = (n - 1).toFloat() - offset
        val startF = maxOf(0f, endF - (count - 1f))
        val i0 = Math.floor(startF.toDouble()).toInt().coerceIn(0, maxOf(0, n - 1))
        val i1 = Math.ceil(endF.toDouble()).toInt().coerceIn(0, maxOf(0, n - 1))

        // skala sumbu Y: otomatis dari data yang terlihat, lalu dipengaruhi zoom & geser pengguna
        var peak = 0.0
        for (i in i0..i1) {
            if (i >= n) break
            if (history.down[i] > peak) peak = history.down[i]
            if (showUp && history.up[i] > peak) peak = history.up[i]
        }
        val baseMax = niceMax(peak * 1.1)
        val range = baseMax / yZoom
        val viewMin = yPan
        val viewMax = yPan + range
        lastStep = step
        lastPlotH = plotH
        lastRange = range
        lastBaseMax = baseMax

        fun yOf(v: Double): Float = bottom - ((v - viewMin) / range).toFloat() * plotH
        fun xOf(i: Int): Float = left + (i - startF) * step

        // garis kisi + label sumbu Y
        for (i in 0..3) {
            val y = top + plotH * i / 3f
            canvas.drawLine(left, y, right, y, gridPaint)
            val value = (viewMax - range * i / 3.0).coerceAtLeast(0.0)
            val label = SpeedSampler.format(value, useBits)
            val ty = (y + axisText.textSize / 3f).coerceIn(top + axisText.textSize / 2f, h)
            canvas.drawText(label, right + 4f * d, ty, axisText)
        }

        if (n < 2) {
            canvas.drawText("Menunggu data\u2026", left + 6f * d, top + plotH / 2f, hintText)
            return
        }

        val live = offset <= 0f
        val lastConn = history.conn[n - 1]

        canvas.save()
        canvas.clipRect(left, 0f, right + 1f, h)

        // upload (di belakang, tipis)
        if (showUp) {
            upPath.reset()
            for (i in i0..i1) {
                val x = xOf(i)
                val y = yOf(history.up[i])
                if (i == i0) upPath.moveTo(x, y) else upPath.lineTo(x, y)
            }
            canvas.drawPath(upPath, upPaint)
        }

        // area di bawah garis download, warna mengikuti tren terakhir
        val trendCol = if (!lastConn) grey else if (history.trendUp()) green else red
        fillPath.reset()
        fillPath.moveTo(xOf(i0), bottom)
        for (i in i0..i1) fillPath.lineTo(xOf(i), yOf(history.down[i]))
        fillPath.lineTo(xOf(i1), bottom)
        fillPath.close()
        fillPaint.shader = LinearGradient(
            0f, top, 0f, bottom,
            Color.argb(110, Color.red(trendCol), Color.green(trendCol), Color.blue(trendCol)),
            Color.argb(0, Color.red(trendCol), Color.green(trendCol), Color.blue(trendCol)),
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(fillPath, fillPaint)

        // garis download per segmen: hijau = naik, merah = turun, abu-abu = lurus / tidak ada internet
        var ng = 0
        var nr = 0
        var nz = 0
        for (i in i0 until i1) {
            val a = history.down[i]
            val b = history.down[i + 1]
            val x1 = xOf(i)
            val y1 = yOf(a)
            val x2 = xOf(i + 1)
            val y2 = yOf(b)
            val flat = !history.conn[i + 1] || (a <= 0.0 && b <= 0.0)
            if (flat) {
                bufGrey[nz++] = x1; bufGrey[nz++] = y1; bufGrey[nz++] = x2; bufGrey[nz++] = y2
            } else if (b >= a) {
                bufGreen[ng++] = x1; bufGreen[ng++] = y1; bufGreen[ng++] = x2; bufGreen[ng++] = y2
            } else {
                bufRed[nr++] = x1; bufRed[nr++] = y1; bufRed[nr++] = x2; bufRed[nr++] = y2
            }
        }
        segPaint.color = grey
        canvas.drawLines(bufGrey, 0, nz, segPaint)
        segPaint.color = green
        canvas.drawLines(bufGreen, 0, ng, segPaint)
        segPaint.color = red
        canvas.drawLines(bufRed, 0, nr, segPaint)

        // panah tren di setiap rangkaian naik / turun
        drawTrendArrows(canvas, i0, i1, range * 0.06, { i -> xOf(i) }, { v -> yOf(v) })

        // titik + garis putus-putus nilai terakhir (hanya saat melihat yang terbaru)
        if (live) {
            val ly = yOf(history.down[n - 1])
            val lx = xOf(n - 1)
            lastLine.color = Color.argb(170, Color.red(trendCol), Color.green(trendCol), Color.blue(trendCol))
            canvas.drawLine(left, ly, right, ly, lastLine)
            dotPaint.color = Color.argb(70, Color.red(trendCol), Color.green(trendCol), Color.blue(trendCol))
            canvas.drawCircle(lx, ly, 7f * d, dotPaint)
            dotPaint.color = trendCol
            canvas.drawCircle(lx, ly, 3.5f * d, dotPaint)
        }
        canvas.restore()

        if (live) {
            val ly = yOf(history.down[n - 1])
            val txt = SpeedSampler.format(history.down[n - 1], useBits)
            val tagH = 16f * d
            val tagTop = (ly - tagH / 2f).coerceIn(0f, h - tagH)
            tagRect.set(right + 2f * d, tagTop, w - 1f * d, tagTop + tagH)
            tagPaint.color = trendCol
            canvas.drawRoundRect(tagRect, 4f * d, 4f * d, tagPaint)
            canvas.drawText(txt, tagRect.centerX(), tagRect.centerY() + tagText.textSize / 3f, tagText)
        }

        if (!lastConn) {
            canvas.drawText("Tidak ada internet", left + 6f * d, top + hintText.textSize, hintText)
        } else if (!live) {
            canvas.drawText(
                "Riwayat \u2022 ketuk 2x untuk kembali live",
                left + 6f * d, top + hintText.textSize, hintText
            )
        }
    }

    /**
     * Algoritma zig-zag sederhana: tiap kali arah berubah lebih dari [thr], satu rangkaian naik/turun
     * selesai dan digambarkan satu panah dari awal ke ujung rangkaian itu.
     */
    private fun drawTrendArrows(
        canvas: Canvas, i0: Int, i1: Int, thr: Double,
        xOf: (Int) -> Float, yOf: (Double) -> Float
    ) {
        if (i1 - i0 < 2 || thr <= 0.0) return
        val v = history.down
        var start = i0
        var ext = i0
        var dir = 0
        fun arrow(s: Int, e: Int, up: Boolean) = drawArrow(
            canvas, xOf(s), yOf(v[s]), xOf(e), yOf(v[e]), up
        )
        for (i in i0 + 1..i1) {
            val x = v[i]
            when (dir) {
                0 -> {
                    if (x - v[start] >= thr) { dir = 1; ext = i }
                    else if (v[start] - x >= thr) { dir = -1; ext = i }
                }
                1 -> {
                    if (x >= v[ext]) ext = i
                    else if (v[ext] - x >= thr) {
                        arrow(start, ext, true)
                        start = ext; dir = -1; ext = i
                    }
                }
                else -> {
                    if (x <= v[ext]) ext = i
                    else if (x - v[ext] >= thr) {
                        arrow(start, ext, false)
                        start = ext; dir = 1; ext = i
                    }
                }
            }
        }
        if (dir == 1) arrow(start, ext, true) else if (dir == -1) arrow(start, ext, false)
    }

    private fun drawArrow(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, up: Boolean) {
        // geser sedikit dari garis supaya panah tidak menutupi garis grafik
        val shift = if (up) 9f * d else -9f * d
        val ax = x1
        val ay = y1 + shift
        val bx = x2
        val by = y2 + shift
        val len = Math.hypot((bx - ax).toDouble(), (by - ay).toDouble()).toFloat()
        if (len < 16f * d) return
        arrowPaint.color = if (up) orange else red
        c.drawLine(ax, ay, bx, by, arrowPaint)
        val ang = Math.atan2((by - ay).toDouble(), (bx - ax).toDouble())
        val head = 7f * d
        val spread = Math.toRadians(28.0)
        for (sgn in intArrayOf(-1, 1)) {
            val a2 = ang + Math.PI + sgn * spread
            c.drawLine(
                bx, by,
                bx + (head * Math.cos(a2)).toFloat(),
                by + (head * Math.sin(a2)).toFloat(),
                arrowPaint
            )
        }
    }

    companion object {
        const val DEFAULT_VISIBLE = 60f
        const val MIN_VISIBLE = 10f
    }
}
