package com.example.netspeed

import android.content.Context
import java.util.Calendar
import java.util.Locale

/**
 * Menyimpan pemakaian data per hari (Wi-Fi dan seluler) untuk ringkasan hari ini / minggu ini /
 * bulan ini. Hanya trafik yang terukur saat meter aktif yang tercatat.
 */
class UsageStore(context: Context) {

    data class Usage(val wifi: Long, val mobile: Long) {
        val total: Long get() = wifi + mobile
    }

    private val sp = context.applicationContext.getSharedPreferences("usage", Context.MODE_PRIVATE)

    fun dayKey(cal: Calendar = Calendar.getInstance()): String = String.format(
        Locale.US, "%04d%02d%02d",
        cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)
    )

    fun get(key: String): Usage {
        val v = sp.getString("d_$key", null) ?: return Usage(0L, 0L)
        val p = v.split(":")
        val w = p.getOrNull(0)?.toLongOrNull() ?: 0L
        val m = p.getOrNull(1)?.toLongOrNull() ?: 0L
        return Usage(w, m)
    }

    fun set(key: String, wifi: Long, mobile: Long) {
        sp.edit().putString("d_$key", "$wifi:$mobile").apply()
    }

    fun today(): Usage = get(dayKey())

    /** Minggu berjalan, mulai Senin. */
    fun week(): Usage {
        val c = Calendar.getInstance()
        val back = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Senin = 0
        c.add(Calendar.DAY_OF_YEAR, -back)
        return sum(c)
    }

    /** Bulan berjalan, mulai tanggal 1. */
    fun month(): Usage {
        val c = Calendar.getInstance()
        c.set(Calendar.DAY_OF_MONTH, 1)
        return sum(c)
    }

    private fun sum(start: Calendar): Usage {
        val endKey = dayKey()
        val c = start.clone() as Calendar
        var w = 0L
        var m = 0L
        var guard = 0
        while (dayKey(c) <= endKey && guard++ < 40) {
            val u = get(dayKey(c))
            w += u.wifi
            m += u.mobile
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return Usage(w, m)
    }

    /** Hapus catatan yang lebih tua dari 120 hari. */
    fun prune() {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -120)
        val cutoff = "d_" + dayKey(c)
        val ed = sp.edit()
        for (k in sp.all.keys) {
            if (k.startsWith("d_") && k < cutoff) ed.remove(k)
        }
        ed.apply()
    }
}
