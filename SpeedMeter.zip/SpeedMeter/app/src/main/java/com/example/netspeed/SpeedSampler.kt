package com.example.netspeed

import android.net.TrafficStats
import android.os.SystemClock
import java.util.Locale

data class Speed(val downBytesPerSec: Double, val upBytesPerSec: Double)

/**
 * Pengukur kecepatan berbasis selisih counter kernel (TrafficStats).
 *
 * Kunci akurasi:
 *  - Counter byte dibaca langsung dari kernel (semua interface: WiFi + data seluler).
 *  - Waktu diukur dengan elapsedRealtimeNanos (monoton, tidak terpengaruh jam sistem),
 *    dan kecepatan = selisih byte / selisih waktu NYATA, bukan interval yang diasumsikan.
 *    Jadi kalau tick telat (HP sibuk), hasil tetap benar.
 *  - Counter yang turun (reset, ganti interface) dianggap 0 untuk tick itu, bukan angka negatif/raksasa.
 */
class SpeedSampler {

    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L
    private var primed = false

    fun reset() {
        primed = false
    }

    /** Mengembalikan null kalau perangkat tidak mendukung TrafficStats. */
    fun read(): Speed? {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        val unsupported = TrafficStats.UNSUPPORTED.toLong()
        if (rx == unsupported || tx == unsupported) return null

        val now = SystemClock.elapsedRealtimeNanos()

        if (!primed) {
            lastRx = rx
            lastTx = tx
            lastT = now
            primed = true
            return Speed(0.0, 0.0)
        }

        val dt = (now - lastT) / 1_000_000_000.0
        val dRx = (rx - lastRx).coerceAtLeast(0L)
        val dTx = (tx - lastTx).coerceAtLeast(0L)

        lastRx = rx
        lastTx = tx
        lastT = now

        if (dt <= 0.0) return null
        return Speed(dRx / dt, dTx / dt)
    }

    companion object {
        /** Format kecepatan jadi teks lebar tetap supaya angka tidak "bergoyang". */
        fun format(bytesPerSec: Double, useBits: Boolean): String {
            return if (useBits) {
                val bps = bytesPerSec * 8.0
                when {
                    bps >= 1_000_000.0 -> String.format(Locale.US, "%.2f Mbps", bps / 1_000_000.0)
                    bps >= 1_000.0 -> String.format(Locale.US, "%.1f Kbps", bps / 1_000.0)
                    else -> String.format(Locale.US, "%.0f bps", bps)
                }
            } else {
                when {
                    bytesPerSec >= 1024.0 * 1024.0 ->
                        String.format(Locale.US, "%.2f MB/s", bytesPerSec / (1024.0 * 1024.0))
                    bytesPerSec >= 1024.0 ->
                        String.format(Locale.US, "%.1f KB/s", bytesPerSec / 1024.0)
                    else -> String.format(Locale.US, "%.0f B/s", bytesPerSec)
                }
            }
        }
    }
}
