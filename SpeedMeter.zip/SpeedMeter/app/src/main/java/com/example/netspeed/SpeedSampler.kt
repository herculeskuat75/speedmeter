package com.example.netspeed

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.SystemClock
import java.util.Locale

/**
 * @param downBytesPerSec kecepatan unduh (byte/detik)
 * @param upBytesPerSec kecepatan unggah (byte/detik)
 * @param wifiBytes total byte (unduh + unggah) lewat Wi-Fi/non-seluler sejak pembacaan terakhir
 * @param mobileBytes total byte (unduh + unggah) lewat data seluler sejak pembacaan terakhir
 */
data class Speed(
    val downBytesPerSec: Double,
    val upBytesPerSec: Double,
    val wifiBytes: Long,
    val mobileBytes: Long
)

/**
 * Pengukur kecepatan berbasis selisih counter kernel (TrafficStats) PER INTERFACE.
 *
 * Kenapa per interface (bukan getTotalRxBytes): saat VPN aktif, setiap paket dihitung dua kali,
 * sekali di interface fisik (wlan0 / rmnet) dan sekali lagi di interface VPN (tun0). Hasilnya
 * angka total hampir dua kali lipat dan terlihat "tidak akurat". Di sini interface VPN dilewati
 * (bisa diatur), jadi yang dihitung hanya trafik yang benar-benar lewat Wi-Fi / data seluler.
 *
 * Kunci akurasi lainnya:
 *  - Waktu diukur dengan elapsedRealtimeNanos, kecepatan = selisih byte / selisih waktu NYATA.
 *  - Interface yang baru muncul (pindah Wi-Fi <-> seluler) tidak dihitung pada tick pertamanya,
 *    supaya tidak muncul lonjakan palsu.
 *  - Counter yang turun (reset) dianggap 0, bukan angka negatif.
 */
class SpeedSampler(context: Context) {

    private enum class Kind { WIFI, MOBILE }

    private data class Snap(val rx: Long, val tx: Long, val kind: Kind)

    private val cm = context.applicationContext
        .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private var last: Map<String, Snap> = emptyMap()
    private var lastT = 0L
    private var primed = false

    fun reset() {
        primed = false
        last = emptyMap()
    }

    /** Mengembalikan null kalau perangkat tidak mendukung TrafficStats. */
    fun read(ignoreVpn: Boolean): Speed? {
        val now = SystemClock.elapsedRealtimeNanos()
        val cur = snapshot(ignoreVpn) ?: return null

        if (!primed) {
            last = cur
            lastT = now
            primed = true
            return Speed(0.0, 0.0, 0L, 0L)
        }

        val dt = (now - lastT) / 1_000_000_000.0
        var dRx = 0L
        var dTx = 0L
        var wifi = 0L
        var mobile = 0L
        for ((name, c) in cur) {
            val p = last[name] ?: continue
            val r = (c.rx - p.rx).coerceAtLeast(0L)
            val t = (c.tx - p.tx).coerceAtLeast(0L)
            dRx += r
            dTx += t
            if (c.kind == Kind.MOBILE) mobile += r + t else wifi += r + t
        }

        last = cur
        lastT = now

        if (dt <= 0.0) return null
        return Speed(dRx / dt, dTx / dt, wifi, mobile)
    }

    /** Baca counter semua interface fisik yang aktif. */
    @Suppress("DEPRECATION")
    private fun snapshot(ignoreVpn: Boolean): Map<String, Snap>? {
        val unsupported = TrafficStats.UNSUPPORTED.toLong()
        val out = HashMap<String, Snap>()

        try {
            for (net in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(net) ?: continue
                if (ignoreVpn && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                val name = cm.getLinkProperties(net)?.interfaceName ?: continue
                if (name.startsWith("lo")) continue
                val rx = TrafficStats.getRxBytes(name)
                val tx = TrafficStats.getTxBytes(name)
                if (rx == unsupported || tx == unsupported) continue
                val kind = if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))
                    Kind.MOBILE else Kind.WIFI
                out[name] = Snap(rx, tx, kind)
            }
        } catch (_: Exception) {
            // jatuh ke cara cadangan di bawah
        }

        if (out.isNotEmpty()) return out

        // Cadangan: tidak ada interface yang terbaca, pakai total seluruh perangkat.
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx == unsupported || tx == unsupported) return null
        out["__total__"] = Snap(rx, tx, Kind.WIFI)
        return out
    }

    companion object {
        /** Format kecepatan jadi teks, mis. "1.5 MB/s". */
        fun format(bytesPerSec: Double, useBits: Boolean): String {
            return if (useBits) {
                val bps = bytesPerSec * 8.0
                when {
                    bps >= 1_000_000.0 -> String.format(Locale.US, "%.2f Mbps", bps / 1_000_000.0)
                    bps >= 1_000.0 -> String.format(Locale.US, "%.1f Kbps", bps / 1_000.0)
                    else -> String.format(Locale.US, "%.0f bps", bps)
                }
            } else {
                when {
                    bytesPerSec >= 1024.0 * 1024.0 ->
                        String.format(Locale.US, "%.2f MB/s", bytesPerSec / (1024.0 * 1024.0))
                    bytesPerSec >= 1024.0 ->
                        String.format(Locale.US, "%.1f KB/s", bytesPerSec / 1024.0)
                    else -> String.format(Locale.US, "%.0f B/s", bytesPerSec)
                }
            }
        }

        /** Pecah jadi (angka, satuan) singkat untuk ikon status bar, mis. ("1.5", "MB/s"). */
        fun formatParts(bytesPerSec: Double, useBits: Boolean): Pair<String, String> {
            val (v, unit) = if (useBits) {
                val bps = bytesPerSec * 8.0
                when {
                    bps >= 1_000_000.0 -> Pair(bps / 1_000_000.0, "Mbps")
                    bps >= 1_000.0 -> Pair(bps / 1_000.0, "Kbps")
                    else -> Pair(bps, "bps")
                }
            } else {
                when {
                    bytesPerSec >= 1024.0 * 1024.0 -> Pair(bytesPerSec / (1024.0 * 1024.0), "MB/s")
                    bytesPerSec >= 1024.0 -> Pair(bytesPerSec / 1024.0, "KB/s")
                    else -> Pair(bytesPerSec, "B/s")
                }
            }
            val text = if (v < 10.0 && unit != "B/s" && unit != "bps")
                String.format(Locale.US, "%.1f", v)
            else
                String.format(Locale.US, "%.0f", v)
            return Pair(text, unit)
        }

        /** Format ukuran data, mis. "0.00 B", "12.34 MB", "1.20 GB". */
        fun formatSize(bytes: Long): String {
            val b = bytes.toDouble()
            return when {
                b >= 1024.0 * 1024.0 * 1024.0 ->
                    String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024.0 * 1024.0))
                b >= 1024.0 * 1024.0 -> String.format(Locale.US, "%.2f MB", b / (1024.0 * 1024.0))
                b >= 1024.0 -> String.format(Locale.US, "%.2f KB", b / 1024.0)
                else -> String.format(Locale.US, "%.2f B", b)
            }
        }
    }
}
