package com.example.netspeed

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.SystemClock
import java.util.Locale

/**
 * @param downBytesPerSec kecepatan unduh (byte/detik)
 * @param upBytesPerSec kecepatan unggah (byte/detik)
 * @param wifiBytes total byte (unduh + unggah) lewat Wi-Fi/non-seluler sejak pembacaan terakhir
 * @param mobileBytes total byte (unduh + unggah) lewat data seluler sejak pembacaan terakhir
 */
data class Speed(
    val downBytesPerSec: Double,
    val upBytesPerSec: Double,
    val wifiBytes: Long,
    val mobileBytes: Long
)

/**
 * Pengukur kecepatan berbasis selisih counter byte PER INTERFACE.
 *
 * Kenapa per interface (bukan getTotalRxBytes): saat VPN aktif, setiap paket dihitung dua kali,
 * sekali di interface fisik (wlan0 / rmnet) dan sekali lagi di interface VPN (tun0). Di sini hanya
 * SATU sisi yang dipakai (lihat pilihan interface).
 *
 * Banyak sumber data dipakai bersamaan (root /proc/net/dev, TrafficStats, /sys/class/net,
 * /proc/net/dev langsung, NetworkStatsManager). Pada sebagian HP salah satu sumber tidak mencatat
 * UNGGAH (selalu 0) padahal sumber lain mencatatnya, jadi tiap arah (unduh / unggah) diambil dari
 * sumber yang angkanya paling besar. Sumber yang rusak hanya mengecil, tidak pernah membesar-besarkan.
 */
class SpeedSampler(context: Context) {

    private enum class Kind { WIFI, MOBILE }

    private class Net(val name: String, val vpn: Boolean, val cellular: Boolean)

    private class Delta(
        val dt: Double,
        val rx: Long,
        val tx: Long,
        val wifi: Long,
        val mobile: Long
    )

    private class Src(val label: String) {
        var last: Map<String, LongArray>? = null
        var lastT = 0L
        var lastDelta: Delta? = null
        var okAt = 0L // kapan terakhir memberi data
    }

    private val ctx = context.applicationContext
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val sRoot = Src("root /proc/net/dev")
    private val sTs = Src("TrafficStats")
    private val sSys = Src("/sys/class/net")
    private val sProc = Src("/proc/net/dev")
    private val sNsm = Src("NetworkStats")
    private val all = listOf(sRoot, sTs, sSys, sProc, sNsm)

    private var needNsm = false
    private var nsmUntil = 0L
    private var lastNsmTry = 0L

    /** Ringkasan sumber yang sedang memberi data (untuk layar diagnostik). */
    @Volatile
    var activeSources: String = "-"
        private set

    fun reset() {
        for (s in all) {
            s.last = null
            s.lastDelta = null
        }
    }

    /** Mengembalikan null kalau perangkat tidak mendukung pembacaan sama sekali. */
    fun read(appLevel: Boolean, filter: Int = 0, useRoot: Boolean = false): Speed? {
        val nets = discover()
        val physical = nets.filter { !it.vpn }
        val vpns = nets.filter { it.vpn }
        val physKind = if (physical.any { !it.cellular } || physical.isEmpty()) Kind.WIFI else Kind.MOBILE
        val chosen = if (appLevel && vpns.isNotEmpty()) vpns else physical
        val kindOf = HashMap<String, Kind>()
        for (n in chosen) kindOf[n.name] = if (n.vpn) physKind else if (n.cellular) Kind.MOBILE else Kind.WIFI
        kindOf["__wifi__"] = Kind.WIFI
        kindOf["__mobile__"] = Kind.MOBILE

        val names = chosen.map { it.name }
        val deltas = ArrayList<Pair<Src, Delta>>()
        var anyData = false

        fun feed(src: Src, t: Long, cur: Map<String, LongArray>?, onlyNames: Boolean = true) {
            if (cur == null) return
            val m = if (onlyNames) cur.filterKeys { it in kindOf } else cur
            if (m.isEmpty()) return
            anyData = true
            src.okAt = SystemClock.elapsedRealtime()
            if (src.lastT == t && src.lastDelta != null) {
                deltas.add(src to src.lastDelta!!)
                return
            }
            val d = delta(src, t, m, kindOf, filter)
            src.lastDelta = d ?: src.lastDelta
            if (d != null) deltas.add(src to d)
        }

        // 1) root (kalau diizinkan dan sedang berjalan)
        if (useRoot) {
            val rs = RootNetDev.snapshot()
            if (rs != null) feed(sRoot, rs.t, rs.map)
        } else {
            sRoot.last = null
        }

        val now = SystemClock.elapsedRealtimeNanos()
        if (names.isNotEmpty()) {
            // 2) TrafficStats, 3) sysfs, 4) /proc langsung
            feed(sTs, now, NetCounters.trafficStats(names))
            feed(sSys, now, NetCounters.sysfs(names))
            val p = NetCounters.procNetDev()
            feed(sProc, now, p)
        } else {
            // Tidak ada interface terdeteksi: total seluruh perangkat saja.
            @Suppress("DEPRECATION")
            val rx = TrafficStats.getTotalRxBytes()
            @Suppress("DEPRECATION")
            val tx = TrafficStats.getTotalTxBytes()
            val u = TrafficStats.UNSUPPORTED.toLong()
            if (rx != u && tx != u) {
                kindOf["__total__"] = Kind.WIFI
                feed(sTs, now, mapOf("__total__" to longArrayOf(rx, tx)))
            }
        }

        // 5) NetworkStatsManager: hanya bila sumber lain menunjukkan unduh jalan tapi unggah nol
        //    (tanda counter unggah rusak), supaya hemat baterai.
        val ms = SystemClock.elapsedRealtime()
        if (needNsm && ms - lastNsmTry >= 900L) {
            lastNsmTry = ms
            feed(sNsm, SystemClock.elapsedRealtimeNanos(), NetCounters.networkStats(ctx))
        }
        if (!needNsm) sNsm.last = null

        if (deltas.isEmpty()) {
            return if (anyData) Speed(0.0, 0.0, 0L, 0L) else null
        }

        var down = 0.0
        var up = 0.0
        var downO = 0.0
        var upO = 0.0
        var best: Pair<Src, Delta>? = null
        for (pr in deltas) {
            val d = pr.second
            if (d.dt <= 0.0) continue
            val isNsm = pr.first === sNsm
            // NetworkStats hanya dipakai untuk UNGGAH (itu yang rusak di sebagian HP); angka unduh
            // darinya mencakup overhead VPN, jadi tidak ikut.
            if (!isNsm) {
                down = maxOf(down, d.rx / d.dt)
                downO = down
                upO = maxOf(upO, d.tx / d.dt)
                if (best == null || d.rx + d.tx > best.second.rx + best.second.tx) best = pr
            }
            up = maxOf(up, d.tx / d.dt)
        }

        // Tanda unggah rusak: ada unduh jelas, tetapi tidak ada sumber biasa yang melihat unggah.
        // NetworkStats dinyalakan beberapa detik (tidak langsung mati begitu unggah terlihat).
        if (downO > 2048.0 && upO <= 0.0) nsmUntil = ms + 8000L
        needNsm = ms < nsmUntil

        activeSources = deltas.joinToString(" + ") { it.first.label }
        val b = best?.second
        return Speed(down, up, b?.wifi ?: 0L, b?.mobile ?: 0L)
    }

    private fun delta(
        src: Src,
        t: Long,
        cur: Map<String, LongArray>,
        kindOf: Map<String, Kind>,
        filter: Int
    ): Delta? {
        val p = src.last
        val pt = src.lastT
        src.last = cur
        src.lastT = t
        if (p == null) return null
        val dt = (t - pt) / 1_000_000_000.0
        if (dt <= 0.0) return null
        if (dt > 15.0) return null // terlalu lama tidak dibaca, jangan dirata-ratakan
        var dRx = 0L
        var dTx = 0L
        var wifi = 0L
        var mobile = 0L
        for ((name, c) in cur) {
            val q = p[name] ?: continue
            val r = (c[0] - q[0]).coerceAtLeast(0L)
            val x = (c[1] - q[1]).coerceAtLeast(0L)
            val k = kindOf[name] ?: Kind.WIFI
            // Pemakaian harian selalu menghitung semuanya; filter hanya memengaruhi angka kecepatan.
            if (k == Kind.MOBILE) mobile += r + x else wifi += r + x
            val pass = filter == 0 || (filter == 1 && k == Kind.WIFI) || (filter == 2 && k == Kind.MOBILE)
            if (pass) {
                dRx += r
                dTx += x
            }
        }
        return Delta(dt, dRx, dTx, wifi, mobile)
    }

    private fun discover(): List<Net> {
        val out = ArrayList<Net>()
        try {
            @Suppress("DEPRECATION")
            for (net in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(net) ?: continue
                val name = cm.getLinkProperties(net)?.interfaceName ?: continue
                if (name.startsWith("lo")) continue
                out.add(
                    Net(
                        name,
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN),
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    )
                )
            }
        } catch (_: Throwable) {
        }
        return out
    }

    companion object {
        /** Format kecepatan jadi teks, mis. "1.5 MB/s". */
        fun format(bytesPerSec: Double, useBits: Boolean): String {
            return if (useBits) {
                val bps = bytesPerSec * 8.0
                when {
                    bps >= 1_000_000.0 -> String.format(Locale.US, "%.2f Mbps", bps / 1_000_000.0)
                    bps >= 1_000.0 -> String.format(Locale.US, "%.1f Kbps", bps / 1_000.0)
                    else -> String.format(Locale.US, "%.0f bps", bps)
                }
            } else {
                when {
                    bytesPerSec >= 1024.0 * 1024.0 ->
                        String.format(Locale.US, "%.2f MB/s", bytesPerSec / (1024.0 * 1024.0))
                    bytesPerSec >= 1024.0 -> String.format(Locale.US, "%.1f KB/s", bytesPerSec / 1024.0)
                    else -> String.format(Locale.US, "%.0f B/s", bytesPerSec)
                }
            }
        }

        /** Pecah jadi (angka, satuan) singkat untuk ikon status bar, mis. ("1.5", "MB/s"). */
        fun formatParts(bytesPerSec: Double, useBits: Boolean): Pair<String, String> {
            val (v, unit) = if (useBits) {
                val bps = bytesPerSec * 8.0
                when {
                    bps >= 1_000_000.0 -> Pair(bps / 1_000_000.0, "Mbps")
                    bps >= 1_000.0 -> Pair(bps / 1_000.0, "Kbps")
                    else -> Pair(bps, "bps")
                }
            } else {
                when {
                    bytesPerSec >= 1024.0 * 1024.0 -> Pair(bytesPerSec / (1024.0 * 1024.0), "MB/s")
                    bytesPerSec >= 1024.0 -> Pair(bytesPerSec / 1024.0, "KB/s")
                    else -> Pair(bytesPerSec, "B/s")
                }
            }
            val text = if (v < 10.0 && unit != "B/s" && unit != "bps")
                String.format(Locale.US, "%.1f", v)
            else
                String.format(Locale.US, "%.0f", v)
            return Pair(text, unit)
        }

        /** Format ukuran data, mis. "0.00 B", "12.34 MB", "1.20 GB". */
        fun formatSize(bytes: Long): String {
            val b = bytes.toDouble()
            return when {
                b >= 1024.0 * 1024.0 * 1024.0 ->
                    String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024.0 * 1024.0))
                b >= 1024.0 * 1024.0 -> String.format(Locale.US, "%.2f MB", b / (1024.0 * 1024.0))
                b >= 1024.0 -> String.format(Locale.US, "%.2f KB", b / 1024.0)
                else -> String.format(Locale.US, "%.2f B", b)
            }
        }
    }
}
