package com.example.netspeed

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.SystemClock
import java.io.File
import java.util.Locale

/**
 * @param downBytesPerSec kecepatan unduh (byte/detik)
 * @param upBytesPerSec kecepatan unggah (byte/detik)
 * @param wifiBytes total byte (unduh + unggah) lewat Wi-Fi/non-seluler sejak pembacaan terakhir
 * @param mobileBytes total byte (unduh + unggah) lewat data seluler sejak pembacaan terakhir
 */
data class Speed(
    val downBytesPerSec: Double,
    val upBytesPerSec: Double,
    val wifiBytes: Long,
    val mobileBytes: Long
)

/**
 * Pengukur kecepatan berbasis selisih counter kernel (TrafficStats) PER INTERFACE.
 *
 * Kenapa per interface (bukan getTotalRxBytes): saat VPN aktif, setiap paket dihitung dua kali,
 * sekali di interface fisik (wlan0 / rmnet) dan sekali lagi di interface VPN (tun0). Hasilnya
 * angka total hampir dua kali lipat. Di sini hanya SATU sisi yang dipakai (lihat snapshot()).
 *
 * Kunci akurasi lainnya:
 *  - Waktu diukur dengan elapsedRealtimeNanos, kecepatan = selisih byte / selisih waktu NYATA.
 *  - Interface yang baru muncul (pindah Wi-Fi <-> seluler) tidak dihitung pada tick pertamanya,
 *    supaya tidak muncul lonjakan palsu.
 *  - Counter yang turun (reset) dianggap 0, bukan angka negatif.
 */
class SpeedSampler(context: Context) {

    private enum class Kind { WIFI, MOBILE }

    private data class Snap(val rx: Long, val tx: Long, val kind: Kind)

    private val cm = context.applicationContext
        .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private var last: Map<String, Snap> = emptyMap()
    private var lastT = 0L
    private var primed = false
    private var procUsable = true
    private var lastSrc = 0
    private var lastSpeed: Speed? = null

    fun reset() {
        primed = false
        last = emptyMap()
    }

    /** Mengembalikan null kalau perangkat tidak mendukung TrafficStats. */
    fun read(appLevel: Boolean, filter: Int = 0, useRoot: Boolean = false): Speed? {
        // Sumber utama (jika root): counter kernel langsung. Cadangan: TrafficStats.
        val rs = if (useRoot) RootNetDev.snapshot() else null
        val src = if (rs != null) 1 else 0
        if (src != lastSrc) {
            // Ganti sumber: angka dua sumber tidak boleh dikurangkan satu sama lain.
            primed = false
            lastSrc = src
        }
        val now = rs?.t ?: SystemClock.elapsedRealtimeNanos()
        if (rs != null && primed && now == lastT) {
            // Belum ada pembacaan root baru sejak tick lalu: pakai angka terakhir.
            val ls = lastSpeed
            return if (ls != null) Speed(ls.downBytesPerSec, ls.upBytesPerSec, 0L, 0L) else null
        }
        val cur = snapshot(appLevel, rs?.map) ?: return null

        if (!primed) {
            last = cur
            lastT = now
            primed = true
            return Speed(0.0, 0.0, 0L, 0L)
        }

        val dt = (now - lastT) / 1_000_000_000.0
        var dRx = 0L
        var dTx = 0L
        var wifi = 0L
        var mobile = 0L
        for ((name, c) in cur) {
            val p = last[name] ?: continue
            val r = (c.rx - p.rx).coerceAtLeast(0L)
            val t = (c.tx - p.tx).coerceAtLeast(0L)
            // Pemakaian harian selalu menghitung semuanya; filter hanya memengaruhi angka kecepatan.
            if (c.kind == Kind.MOBILE) mobile += r + t else wifi += r + t
            val pass = filter == 0 ||
                (filter == 1 && c.kind == Kind.WIFI) ||
                (filter == 2 && c.kind == Kind.MOBILE)
            if (pass) {
                dRx += r
                dTx += t
            }
        }

        last = cur
        lastT = now

        if (dt <= 0.0) return null
        val res = Speed(dRx / dt, dTx / dt, wifi, mobile)
        lastSpeed = res
        return res
    }

    /**
     * Baca counter interface yang dipilih.
     *  - appLevel = true dan ada VPN aktif: hanya interface VPN (tun*) yang dihitung. Ini trafik yang
     *    benar-benar diterima/dikirim aplikasi (sama seperti kecepatan di 1DM+, browser, dll), tanpa
     *    overhead tunnel/injeksi.
     *  - selain itu: hanya interface fisik (Wi-Fi / seluler).
     * Keduanya tidak pernah dijumlahkan, jadi tidak ada hitungan ganda.
     */
    @Suppress("DEPRECATION")
    private fun snapshot(appLevel: Boolean, rootMap: Map<String, LongArray>? = null): Map<String, Snap>? {
        val unsupported = TrafficStats.UNSUPPORTED.toLong()

        class Net(val name: String, val vpn: Boolean, val cellular: Boolean)

        val nets = ArrayList<Net>()
        try {
            for (net in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(net) ?: continue
                val name = cm.getLinkProperties(net)?.interfaceName ?: continue
                if (name.startsWith("lo")) continue
                nets.add(
                    Net(
                        name,
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN),
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    )
                )
            }
        } catch (_: Exception) {
            // jatuh ke cara cadangan di bawah
        }

        val physical = nets.filter { !it.vpn }
        val vpns = nets.filter { it.vpn }
        // Jenis jaringan asli (untuk hitungan "Wi-Fi" vs "Data"): ada Wi-Fi -> Wi-Fi, selain itu seluler.
        val physKind = if (physical.any { !it.cellular } || physical.isEmpty()) Kind.WIFI else Kind.MOBILE

        val chosen = if (appLevel && vpns.isNotEmpty()) vpns else physical

        val out = HashMap<String, Snap>()
        var proc: Map<String, LongArray>? = null
        var procLoaded = false
        for (n in chosen) {
            var rx: Long
            var tx: Long
            val rm = rootMap?.get(n.name)
            if (rm != null) {
                rx = rm[0]
                tx = rm[1]
            } else {
                rx = TrafficStats.getRxBytes(n.name)
                tx = TrafficStats.getTxBytes(n.name)
            }
            if (rx == unsupported || tx == unsupported) {
                // Salah satu counter tidak terbaca (sering terjadi di interface VPN): coba /proc/net/dev.
                if (!procLoaded) {
                    proc = readProcNetDev()
                    procLoaded = true
                }
                val pd = proc?.get(n.name) ?: continue
                rx = pd[0]
                tx = pd[1]
            }
            val kind = if (n.vpn) physKind else if (n.cellular) Kind.MOBILE else Kind.WIFI
            out[n.name] = Snap(rx, tx, kind)
        }
        if (out.isNotEmpty()) return out

        // Cadangan: tidak ada interface yang terbaca, pakai total seluruh perangkat.
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx == unsupported || tx == unsupported) return null
        out["__total__"] = Snap(rx, tx, Kind.WIFI)
        return out
    }

    /** Cadangan: baca counter dari /proc/net/dev (di Android baru bisa ditolak, lalu dilewati). */
    private fun readProcNetDev(): Map<String, LongArray>? {
        if (!procUsable) return null
        return try {
            val m = HashMap<String, LongArray>()
            File("/proc/net/dev").bufferedReader().useLines { lines ->
                for (line in lines) {
                    val i = line.indexOf(':')
                    if (i < 0) continue
                    val name = line.substring(0, i).trim()
                    val f = line.substring(i + 1).trim().split(Regex("\\s+"))
                    if (f.size < 9) continue
                    val rx = f[0].toLongOrNull() ?: continue
                    val tx = f[8].toLongOrNull() ?: continue
                    m[name] = longArrayOf(rx, tx)
                }
            }
            if (m.isEmpty()) {
                procUsable = false
                null
            } else m
        } catch (_: Exception) {
            procUsable = false
            null
        }
    }

    companion object {
        /** Format kecepatan jadi teks, mis. "1.5 MB/s". */
        fun format(bytesPerSec: Double, useBits: Boolean): String {
            return if (useBits) {
                val bps = bytesPerSec * 8.0
                when {
                    bps >= 1_000_000.0 -> String.format(Locale.US, "%.2f Mbps", bps / 1_000_000.0)
                    bps >= 1_000.0 -> String.format(Locale.US, "%.1f Kbps", bps / 1_000.0)
                    else -> String.format(Locale.US, "%.0f bps", bps)
                }
            } else {
                when {
                    bytesPerSec >= 1024.0 * 1024.0 ->
                        String.format(Locale.US, "%.2f MB/s", bytesPerSec / (1024.0 * 1024.0))
                    bytesPerSec >= 1024.0 ->
                        String.format(Locale.US, "%.1f KB/s", bytesPerSec / 1024.0)
                    else -> String.format(Locale.US, "%.0f B/s", bytesPerSec)
                }
            }
        }

        /** Pecah jadi (angka, satuan) singkat untuk ikon status bar, mis. ("1.5", "MB/s"). */
        fun formatParts(bytesPerSec: Double, useBits: Boolean): Pair<String, String> {
            val (v, unit) = if (useBits) {
                val bps = bytesPerSec * 8.0
                when {
                    bps >= 1_000_000.0 -> Pair(bps / 1_000_000.0, "Mbps")
                    bps >= 1_000.0 -> Pair(bps / 1_000.0, "Kbps")
                    else -> Pair(bps, "bps")
                }
            } else {
                when {
                    bytesPerSec >= 1024.0 * 1024.0 -> Pair(bytesPerSec / (1024.0 * 1024.0), "MB/s")
                    bytesPerSec >= 1024.0 -> Pair(bytesPerSec / 1024.0, "KB/s")
                    else -> Pair(bytesPerSec, "B/s")
                }
            }
            val text = if (v < 10.0 && unit != "B/s" && unit != "bps")
                String.format(Locale.US, "%.1f", v)
            else
                String.format(Locale.US, "%.0f", v)
            return Pair(text, unit)
        }

        /** Format ukuran data, mis. "0.00 B", "12.34 MB", "1.20 GB". */
        fun formatSize(bytes: Long): String {
            val b = bytes.toDouble()
            return when {
                b >= 1024.0 * 1024.0 * 1024.0 ->
                    String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024.0 * 1024.0))
                b >= 1024.0 * 1024.0 -> String.format(Locale.US, "%.2f MB", b / (1024.0 * 1024.0))
                b >= 1024.0 -> String.format(Locale.US, "%.2f KB", b / 1024.0)
                else -> String.format(Locale.US, "%.2f B", b)
            }
        }
    }
}
