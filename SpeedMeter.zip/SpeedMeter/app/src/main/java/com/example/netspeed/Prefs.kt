package com.example.netspeed

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** Semua pengaturan disimpan di sini. Service membaca ulang saat nilai berubah, jadi efeknya langsung terlihat. */
class Prefs(context: Context) {

    val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("speed_prefs", Context.MODE_PRIVATE)

    var downColor: Int
        get() = sp.getInt("downColor", Color.parseColor("#4CAF50"))
        set(v) = sp.edit().putInt("downColor", v).apply()

    var upColor: Int
        get() = sp.getInt("upColor", Color.parseColor("#FFB300"))
        set(v) = sp.edit().putInt("upColor", v).apply()

    var bgColor: Int
        get() = sp.getInt("bgColor", Color.BLACK)
        set(v) = sp.edit().putInt("bgColor", v).apply()

    /** 0..255 */
    var bgAlpha: Int
        get() = sp.getInt("bgAlpha", 150)
        set(v) = sp.edit().putInt("bgAlpha", v).apply()

    /** ukuran teks dalam sp */
    var textSize: Int
        get() = sp.getInt("textSize", 14)
        set(v) = sp.edit().putInt("textSize", v).apply()

    /** interval pengukuran (ms) */
    var intervalMs: Long
        get() = sp.getLong("intervalMs", 1000L)
        set(v) = sp.edit().putLong("intervalMs", v).apply()

    /** true = tampilkan dalam bit (Mbps), false = byte (MB/s) */
    var useBits: Boolean
        get() = sp.getBoolean("useBits", false)
        set(v) = sp.edit().putBoolean("useBits", v).apply()

    var showUpload: Boolean
        get() = sp.getBoolean("showUpload", true)
        set(v) = sp.edit().putBoolean("showUpload", v).apply()

    /** kunci posisi: sentuhan menembus overlay, tidak bisa digeser */
    var locked: Boolean
        get() = sp.getBoolean("locked", false)
        set(v) = sp.edit().putBoolean("locked", v).apply()

    var autoStart: Boolean
        get() = sp.getBoolean("autoStart", false)
        set(v) = sp.edit().putBoolean("autoStart", v).apply()

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    var posX: Int
        get() = sp.getInt("posX", 24)
        set(v) = sp.edit().putInt("posX", v).apply()

    var posY: Int
        get() = sp.getInt("posY", 200)
        set(v) = sp.edit().putInt("posY", v).apply()

    /** saat VPN aktif, ukur trafik di level aplikasi (interface VPN), bukan interface fisik */
    var vpnAppLevel: Boolean
        get() = sp.getBoolean("vpnAppLevel", true)
        set(v) = sp.edit().putBoolean("vpnAppLevel", v).apply()

    /** 0 = normal, 1 = tebal, 2 = tebal banget */
    var textWeight: Int
        get() = sp.getInt("textWeight", 1)
        set(v) = sp.edit().putInt("textWeight", v).apply()

    /** animasi panah saat ada trafik: 0 = mati, 1 = menyala, 2 = berkedip */
    var arrowMode: Int
        get() = sp.getInt("arrowMode", 2)
        set(v) = sp.edit().putInt("arrowMode", v).apply()

    /** warna pelangi yang berubah sendiri pada angka & panah saat internet tersambung */
    var rainbow: Boolean
        get() = sp.getBoolean("rainbow", false)
        set(v) = sp.edit().putBoolean("rainbow", v).apply()

    /** tampilkan alamat yang diakses lewat akses root (su) */
    var rootAddr: Boolean
        get() = sp.getBoolean("rootAddr", false)
        set(v) = sp.edit().putBoolean("rootAddr", v).apply()
}
