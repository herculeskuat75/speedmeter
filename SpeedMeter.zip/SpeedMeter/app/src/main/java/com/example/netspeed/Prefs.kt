package com.example.netspeed

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** Semua pengaturan disimpan di sini. Service membaca ulang saat nilai berubah, jadi efeknya langsung terlihat. */
class Prefs(context: Context) {

    val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("speed_prefs", Context.MODE_PRIVATE)

    var downColor: Int
        get() = sp.getInt("downColor", Color.parseColor("#4CAF50"))
        set(v) = sp.edit().putInt("downColor", v).apply()

    var upColor: Int
        get() = sp.getInt("upColor", Color.parseColor("#FFB300"))
        set(v) = sp.edit().putInt("upColor", v).apply()

    var bgColor: Int
        get() = sp.getInt("bgColor", Color.BLACK)
        set(v) = sp.edit().putInt("bgColor", v).apply()

    /** 0..255 */
    var bgAlpha: Int
        get() = sp.getInt("bgAlpha", 150)
        set(v) = sp.edit().putInt("bgAlpha", v).apply()

    /** ukuran teks dalam sp */
    var textSize: Int
        get() = sp.getInt("textSize", 14)
        set(v) = sp.edit().putInt("textSize", v).apply()

    /** interval pengukuran (ms) */
    var intervalMs: Long
        get() = sp.getLong("intervalMs", 1000L)
        set(v) = sp.edit().putLong("intervalMs", v).apply()

    /** true = tampilkan dalam bit (Mbps), false = byte (MB/s) */
    var useBits: Boolean
        get() = sp.getBoolean("useBits", false)
        set(v) = sp.edit().putBoolean("useBits", v).apply()

    var showUpload: Boolean
        get() = sp.getBoolean("showUpload", true)
        set(v) = sp.edit().putBoolean("showUpload", v).apply()

    /** kunci posisi: sentuhan menembus overlay, tidak bisa digeser */
    var locked: Boolean
        get() = sp.getBoolean("locked", false)
        set(v) = sp.edit().putBoolean("locked", v).apply()

    var autoStart: Boolean
        get() = sp.getBoolean("autoStart", false)
        set(v) = sp.edit().putBoolean("autoStart", v).apply()

    /** Meter mengambang di layar. Terpisah dari notifikasi; butuh izin "tampil di atas aplikasi lain". */
    var floatOverlay: Boolean
        get() = sp.getBoolean("floatOverlay", true)
        set(v) = sp.edit().putBoolean("floatOverlay", v).apply()

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    var posX: Int
        get() = sp.getInt("posX", 24)
        set(v) = sp.edit().putInt("posX", v).apply()

    var posY: Int
        get() = sp.getInt("posY", 200)
        set(v) = sp.edit().putInt("posY", v).apply()

    /** saat VPN aktif, ukur trafik di level aplikasi (interface VPN), bukan interface fisik */
    var vpnAppLevel: Boolean
        get() = sp.getBoolean("vpnAppLevel", true)
        set(v) = sp.edit().putBoolean("vpnAppLevel", v).apply()

    /** 0 = normal, 1 = tebal, 2 = tebal banget */
    var textWeight: Int
        get() = sp.getInt("textWeight", 1)
        set(v) = sp.edit().putInt("textWeight", v).apply()

    /** animasi panah saat ada trafik: 0 = mati, 1 = menyala, 2 = berkedip */
    var arrowMode: Int
        get() = sp.getInt("arrowMode", 2)
        set(v) = sp.edit().putInt("arrowMode", v).apply()

    /** warna pelangi yang berubah sendiri pada angka & panah saat internet tersambung */
    var rainbow: Boolean
        get() = sp.getBoolean("rainbow", false)
        set(v) = sp.edit().putBoolean("rainbow", v).apply()

    /** tampilkan alamat yang diakses lewat akses root (su) */
    var rootAddr: Boolean
        get() = sp.getBoolean("rootAddr", false)
        set(v) = sp.edit().putBoolean("rootAddr", v).apply()

    /** 0 = semua jaringan, 1 = hanya Wi-Fi, 2 = hanya data seluler */
    var netFilter: Int
        get() = sp.getInt("netFilter", 0)
        set(v) = sp.edit().putInt("netFilter", v).apply()

    /** warna teks di layar pengaturan aplikasi */
    var appTextColor: Int
        get() = sp.getInt("appTextColor", Color.BLACK)
        set(v) = sp.edit().putInt("appTextColor", v).apply()

    /** skala ukuran meter mengambang (cubit dua jari), 1.0 = ukuran dasar */
    var overlayScale: Float
        get() = sp.getFloat("overlayScale", 1f)
        set(v) = sp.edit().putFloat("overlayScale", v).apply()

    /** true = cubit dua jari TIDAK mengubah ukuran meter */
    var lockResize: Boolean
        get() = sp.getBoolean("lockResize", false)
        set(v) = sp.edit().putBoolean("lockResize", v).apply()

    /** tampilkan dBm & band di notifikasi (dibaca lewat root: dumpsys) */
    var rootSignal: Boolean
        get() = sp.getBoolean("rootSignal", true)
        set(v) = sp.edit().putBoolean("rootSignal", v).apply()

    /** ubah alamat IP jadi nama host (reverse DNS) di panel trafik */
    var resolveHost: Boolean
        get() = sp.getBoolean("resolveHost", true)
        set(v) = sp.edit().putBoolean("resolveHost", v).apply()

    /** baca counter jaringan langsung dari kernel lewat root (lebih akurat, terutama untuk upload) */
    var rootCounters: Boolean
        get() = sp.getBoolean("rootCounters", true)
        set(v) = sp.edit().putBoolean("rootCounters", v).apply()

    /** true = pakai jendela aksesibilitas supaya meter tetap tampil di atas panel notifikasi & Pengaturan */
    var a11yOverlay: Boolean
        get() = sp.getBoolean("a11yOverlay", false)
        set(v) = sp.edit().putBoolean("a11yOverlay", v).apply()

    /** tinggi grafik di panel trafik (dp) */
    var graphHeightDp: Int
        get() = sp.getInt("graphHeightDp", 190)
        set(v) = sp.edit().putInt("graphHeightDp", v).apply()

    // ------------------------------------------------------------------ font

    /** Font global: 0 = ikut font HP, 1 = bawaan aplikasi, dst (lihat Fonts.names). */
    var fontGlobal: Int
        get() = sp.getInt("fontGlobal", 0)
        set(v) = sp.edit().putInt("fontGlobal", v).apply()

    /** Nilai mentah per area: -1 = ikuti font global. */
    fun fontRaw(area: Int): Int =
        sp.getInt("font_$area", if (area == Area.FLOAT || area == Area.GRAPH) 1 else -1)

    fun setFontRaw(area: Int, v: Int) = sp.edit().putInt("font_$area", v).apply()

    /** Font yang benar-benar dipakai untuk satu area. */
    fun fontOf(area: Int): Int {
        val v = fontRaw(area)
        return if (v < 0) fontGlobal else v
    }

    // ------------------------------------------------------------------ pelangi per area

    var rainbowApp: Boolean
        get() = sp.getBoolean("rainbowApp", false)
        set(v) = sp.edit().putBoolean("rainbowApp", v).apply()

    var rainbowNotif: Boolean
        get() = sp.getBoolean("rainbowNotif", false)
        set(v) = sp.edit().putBoolean("rainbowNotif", v).apply()

    var rainbowGraph: Boolean
        get() = sp.getBoolean("rainbowGraph", false)
        set(v) = sp.edit().putBoolean("rainbowGraph", v).apply()

    /** Saklar utama: nyalakan / matikan pelangi di semua teks sekaligus. */
    var rainbowAll: Boolean
        get() = rainbow && rainbowApp && rainbowNotif && rainbowGraph
        set(v) {
            sp.edit().putBoolean("rainbow", v).putBoolean("rainbowApp", v)
                .putBoolean("rainbowNotif", v).putBoolean("rainbowGraph", v).apply()
        }

    // ------------------------------------------------------------------ notifikasi

    /** false = warna otomatis (ikut tema notifikasi, terang), true = warna pilihan */
    var notifSpeedCustom: Boolean
        get() = sp.getBoolean("notifSpeedCustom", false)
        set(v) = sp.edit().putBoolean("notifSpeedCustom", v).apply()

    var notifSpeedColor: Int
        get() = sp.getInt("notifSpeedColor", Color.WHITE)
        set(v) = sp.edit().putInt("notifSpeedColor", v).apply()

    var notifInfoCustom: Boolean
        get() = sp.getBoolean("notifInfoCustom", false)
        set(v) = sp.edit().putBoolean("notifInfoCustom", v).apply()

    var notifInfoColor: Int
        get() = sp.getInt("notifInfoColor", Color.WHITE)
        set(v) = sp.edit().putInt("notifInfoColor", v).apply()

    /** ukuran teks unduh/unggah di notifikasi (sp) */
    var notifSpeedSize: Int
        get() = sp.getInt("notifSpeedSize", 16)
        set(v) = sp.edit().putInt("notifSpeedSize", v).apply()

    /** ukuran teks IP / dBm / band di notifikasi (sp) */
    var notifInfoSize: Int
        get() = sp.getInt("notifInfoSize", 13)
        set(v) = sp.edit().putInt("notifInfoSize", v).apply()

    /** 0 = normal, 1 = tebal, 2 = tebal banget */
    var notifSpeedWeight: Int
        get() = sp.getInt("notifSpeedWeight", 1)
        set(v) = sp.edit().putInt("notifSpeedWeight", v).apply()

    var notifInfoWeight: Int
        get() = sp.getInt("notifInfoWeight", 1)
        set(v) = sp.edit().putInt("notifInfoWeight", v).apply()

    /** saat notifikasi diciutkan: 0 = otomatis muat, 1 = sembunyikan baris info, 2 = ukuran penuh (boleh terpotong) */
    var notifCollapsed: Int
        get() = sp.getInt("notifCollapsed", 0)
        set(v) = sp.edit().putInt("notifCollapsed", v).apply()

    /** true = tulis "↑ 1.2 MB/s  ↓ 3.4 MB/s" (lebih pendek) */
    var notifCompact: Boolean
        get() = sp.getBoolean("notifCompact", false)
        set(v) = sp.edit().putBoolean("notifCompact", v).apply()

    // ------------------------------------------------------------------ sinyal tanpa root

    /** dBm & band lewat API Android biasa (tanpa root) bila root tidak ada / dimatikan */
    var noRootSignal: Boolean
        get() = sp.getBoolean("noRootSignal", true)
        set(v) = sp.edit().putBoolean("noRootSignal", v).apply()

    // ------------------------------------------------------------------ panel & overlay

    /** skala seluruh panel trafik (cubit dua jari / tombol - +) */
    var panelScale: Float
        get() = sp.getFloat("panelScale", 1f)
        set(v) = sp.edit().putFloat("panelScale", v).apply()

    /** jangan biarkan meter / panel menutupi tombol navigasi (Home, Back, Recent) */
    var safeNav: Boolean
        get() = sp.getBoolean("safeNav", true)
        set(v) = sp.edit().putBoolean("safeNav", v).apply()

    // ------------------------------------------------------------------ kunci PIN

    var pinHash: String
        get() = sp.getString("pinHash", "") ?: ""
        set(v) = sp.edit().putString("pinHash", v).apply()

    var pinSalt: String
        get() = sp.getString("pinSalt", "") ?: ""
        set(v) = sp.edit().putString("pinSalt", v).apply()

    val pinEnabled: Boolean get() = pinHash.isNotEmpty()

    /** kunci lagi setelah aplikasi ditinggalkan selama sekian detik (0 = langsung) */
    var lockDelaySec: Int
        get() = sp.getInt("lockDelaySec", 0)
        set(v) = sp.edit().putInt("lockDelaySec", v).apply()

    /** panjang PIN (supaya otomatis masuk begitu angkanya cukup) */
    var pinLen: Int
        get() = sp.getInt("pinLen", 4)
        set(v) = sp.edit().putInt("pinLen", v).apply()

    var pinFails: Int
        get() = sp.getInt("pinFails", 0)
        set(v) = sp.edit().putInt("pinFails", v).apply()

    var pinBlockedUntil: Long
        get() = sp.getLong("pinBlockedUntil", 0L)
        set(v) = sp.edit().putLong("pinBlockedUntil", v).apply()
}

/** Nomor area teks yang fontnya bisa diatur sendiri-sendiri. */
object Area {
    const val APP = 0      // semua teks di layar pengaturan
    const val TITLE = 1    // nama aplikasi (judul)
    const val FLOAT = 2    // meter mengambang
    const val NSPEED = 3   // notifikasi: unduh / unggah
    const val IP = 4       // notifikasi: IP lokal
    const val DBM = 5      // notifikasi: dBm
    const val BAND = 6     // notifikasi: band
    const val GRAPH = 7    // panel trafik & grafik
    const val COUNT = 8
}
