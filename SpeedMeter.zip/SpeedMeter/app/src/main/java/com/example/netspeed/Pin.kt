package com.example.netspeed

import java.security.MessageDigest
import java.security.SecureRandom

/** Kunci aplikasi dengan PIN. PIN tidak disimpan, hanya hash SHA-256 + garam acak. */
object Pin {
    private fun hex(b: ByteArray): String = b.joinToString("") { String.format("%02x", it) }

    private fun hash(pin: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        var d = (salt + ":" + pin).toByteArray(Charsets.UTF_8)
        // sedikit pengulangan supaya menebak lebih lambat
        for (i in 0 until 2000) d = md.digest(d)
        return hex(d)
    }

    fun set(prefs: Prefs, pin: String) {
        val saltBytes = ByteArray(16)
        SecureRandom().nextBytes(saltBytes)
        val salt = hex(saltBytes)
        prefs.pinSalt = salt
        prefs.pinHash = hash(pin, salt)
        prefs.pinFails = 0
        prefs.pinBlockedUntil = 0L
    }

    fun verify(prefs: Prefs, pin: String): Boolean {
        if (!prefs.pinEnabled) return true
        return hash(pin, prefs.pinSalt) == prefs.pinHash
    }

    fun clear(prefs: Prefs) {
        prefs.pinHash = ""
        prefs.pinSalt = ""
        prefs.pinFails = 0
        prefs.pinBlockedUntil = 0L
    }
}
