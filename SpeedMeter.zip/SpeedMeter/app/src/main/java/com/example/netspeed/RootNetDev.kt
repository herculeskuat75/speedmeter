package com.example.netspeed

import android.os.SystemClock

/** Hasil baca /proc/net/dev: nama interface -> [byte diterima, byte dikirim]. */
fun parseNetDev(text: String): Map<String, LongArray> {
    val m = HashMap<String, LongArray>()
    for (line in text.lines()) {
        val i = line.indexOf(':')
        if (i < 0) continue
        val name = line.substring(0, i).trim()
        val f = line.substring(i + 1).trim().split(Regex("\\s+"))
        if (f.size < 9) continue
        val rx = f[0].toLongOrNull() ?: continue
        val tx = f[8].toLongOrNull() ?: continue
        m[name] = longArrayOf(rx, tx)
    }
    return m
}

/**
 * Membaca counter interface langsung dari kernel (/proc/net/dev) lewat satu shell root yang
 * dibiarkan terbuka, dua kali per detik. Angka ini sama dengan yang kamu lihat di Termux, tidak
 * lewat TrafficStats Android (yang di sebagian HP/VPN tidak mencatat upload dengan benar).
 */
object RootNetDev {
    class Snap(val map: Map<String, LongArray>, val t: Long)

    @Volatile
    private var latest: Snap? = null

    @Volatile
    private var running = false
    private var thread: Thread? = null

    val isRunning: Boolean get() = running

    fun start() {
        if (running) return
        running = true
        val t = Thread { loop() }
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
        latest = null
    }

    /** Pembacaan terbaru, atau null kalau belum ada / sudah basi (root tidak tersedia). */
    fun snapshot(): Snap? {
        val s = latest ?: return null
        return if (SystemClock.elapsedRealtimeNanos() - s.t < 3_000_000_000L) s else null
    }

    private fun loop() {
        val proc = try {
            Runtime.getRuntime().exec("su")
        } catch (_: Exception) {
            running = false
            return
        }
        try {
            val w = proc.outputStream.bufferedWriter()
            val r = proc.inputStream.bufferedReader()
            while (running) {
                w.write("cat /proc/net/dev 2>/dev/null; echo __END__\n")
                w.flush()
                val sb = StringBuilder()
                while (true) {
                    val line = r.readLine() ?: throw java.io.IOException("shell root berhenti")
                    if (line.startsWith("__END__")) break
                    sb.append(line).append('\n')
                }
                val m = parseNetDev(sb.toString())
                if (m.isNotEmpty()) latest = Snap(m, SystemClock.elapsedRealtimeNanos())
                Thread.sleep(500L)
            }
        } catch (_: Exception) {
            // root ditolak / shell berhenti: pembaca TrafficStats biasa dipakai sebagai cadangan
        } finally {
            running = false
            latest = null
            try {
                proc.destroy()
            } catch (_: Exception) {
            }
        }
    }
}
