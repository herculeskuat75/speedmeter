# Speed Meter (Android 5.0+)

Versi 8: minSdk 21 (Android 5), unggah tanpa root (4 sumber data), notifikasi bisa diatur warna/ukuran/font/pelangi,
font per bagian, pelangi di semua teks, kunci PIN, panel trafik bisa dikecilkan dengan cubit, tombol Salin,
dBm & band tanpa root (izin lokasi), dan meter tidak menutupi tombol navigasi.

Dibuat oleh alfy47 - alfysilverfunks@gmail.com

Indikator kecepatan internet yang mengambang di atas semua aplikasi.

## Fitur
- Upload (↑) di atas, download (↓) di bawah, real-time, WiFi dan data seluler, huruf tebal
- Bisa digeser sampai tepi paling atas layar (menimpa status bar)
- Notifikasi menampilkan kecepatan (juga sebagai ikon status bar) dan pemakaian data hari ini (Wi-Fi / Data)
- Panah di kiri angka (rapat), berkedip/menyala saat ada trafik, kembali normal saat tidak ada
- Ketebalan huruf: Normal / Tebal / Tebal banget
- Total pemakaian data hari ini, minggu ini, bulan ini di layar pengaturan
- Latar belakang layar pengaturan bisa diganti gambar dari galeri (tanpa gambar = putih; dengan gambar = gambar saja, tanpa lapisan putih)
- Ketuk meter yang mengambang untuk membuka panel: grafik ala saham, aplikasi yang sedang memakai internet, dan alamat koneksi (jika HP mengizinkan)
- Grafik digambar kiri ke kanan dan terus bergerak: lurus abu-abu saat tidak ada internet/trafik, hijau saat naik, merah saat melambat, dengan panah tren di tiap rangkaian naik/turun. Cubit untuk zoom (mendatar = rentang waktu, tegak = skala kecepatan), geser untuk pindah, ketuk 2x untuk reset
- Alamat yang diakses ditampilkan sebagai nama host (reverse DNS), IP:port di bawahnya
- Ukuran meter mengambang bisa diubah dengan cubit dua jari (ada opsi kunci ukuran + reset)
- Filter jaringan: semua / hanya Wi-Fi / hanya data seluler
- Warna teks layar pengaturan bisa diubah
- Notifikasi menampilkan IP lokal, dan (via root) dBm + band seperti script Termux
- Opsi warna pelangi otomatis saat internet tersambung
- Ikon aplikasi: speedometer (tanpa tulisan 5G+)
- Mengambang di atas aplikasi lain, bisa digeser dengan jari, posisi tersimpan
- Warna download, upload, dan latar bisa diubah (slider RGB + warna cepat)
- Atur transparansi latar, ukuran teks, interval pengukuran (250 ms - 2 detik)
- Satuan byte (KB/s, MB/s) atau bit (Kbps, Mbps)
- Kunci posisi, mulai otomatis setelah HP restart
- Tanpa library tambahan. Izin INTERNET hanya dipakai untuk reverse DNS (nama host); bisa dimatikan di pengaturan, aplikasi tidak mengirim data apa pun selain query DNS itu

## Build APK lewat GitHub
1. Upload ISI folder ini (bukan folder induknya) ke repository GitHub, pastikan `.github/workflows/build.yml` ikut.
2. Buka tab **Actions** > **Build APK** > (otomatis jalan saat push, atau tekan **Run workflow**).
3. Setelah selesai, unduh artifact **SpeedMeter-debug-apk** (isinya file APK yang bisa langsung dipasang).

## Panel trafik
- Trafik per aplikasi memakai `NetworkStatsManager` dan butuh izin **Akses penggunaan**
  (tombol ada di layar pengaturan).
- Alamat yang diakses: tanpa root, dibaca dari `/proc/net/tcp` (diblokir Android 10+). Dengan opsi
  **"Alamat via root"** aplikasi meminta akses `su` dan membaca daftar koneksi beserta nama aplikasi
  pemiliknya.

## Info sinyal (root)
`SignalReader.kt` menjalankan `su -c "dumpsys telephony.registry; dumpsys phone"` tiap 3 detik, membaca sel
yang `mRegistered=YES` lebih dulu, lalu jatuh ke pola yang sama dengan script Termux (mDbm / rsrp / mBand /
earfcn). Peta EARFCN memuat band 1, 2, 3, 4, 5, 7, 8, 20, 28, 38, 40, 41.

## Cara build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru), tunggu Gradle sync selesai.
2. Colok HP (USB debugging aktif) lalu tekan **Run**, atau pilih
   *Build > Build APK(s)* untuk mendapatkan file APK.
3. Buka aplikasi, tekan **NYALAKAN METER**, berikan izin
   "Tampil di atas aplikasi lain", lalu kembali ke aplikasi.

## Tentang akurasi
Angka dibaca dari counter byte kernel (`TrafficStats`) **per interface** (wlan0, rmnet, dst),
lalu dihitung `selisih byte / selisih waktu nyata` memakai jam monoton (`elapsedRealtimeNanos`).
- Saat VPN/tunnel aktif, trafik tercatat dua kali (interface fisik + `tun0`). Opsi
  **"Saat VPN aktif, ukur level aplikasi"** (aktif secara default) hanya menghitung `tun0`, yaitu
  kecepatan yang benar-benar diterima aplikasi (sama seperti angka di 1DM+). Kalau dimatikan, yang
  dihitung interface fisik (termasuk overhead tunnel). Keduanya tidak pernah dijumlahkan.
- Interval 1000 ms (1 detik) adalah pilihan seimbang. 250-500 ms lebih responsif tetapi angkanya
  lebih "loncat-loncat" dan sedikit lebih boros baterai.
- Pemakaian data "Hari ini" dihitung selama meter aktif, jadi data yang terpakai saat meter mati
  tidak ikut terhitung. Reset otomatis tiap pergantian hari.

## Struktur
- `OverlayService.kt` - service foreground + jendela overlay + loop pengukuran
- `SpeedSampler.kt` - perhitungan kecepatan dan format teks
- `MainActivity.kt` - layar pengaturan (dibuat lewat kode, tanpa XML layout)
- `Prefs.kt` - penyimpanan pengaturan
- `UsageStore.kt` - catatan pemakaian data per hari
- `BootReceiver.kt` - mulai otomatis setelah boot
