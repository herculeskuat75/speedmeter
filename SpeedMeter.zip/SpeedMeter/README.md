# Speed Meter (Android)

Indikator kecepatan internet yang mengambang di atas semua aplikasi.

## Fitur
- Download (↓) dan upload (↑) real-time, WiFi dan data seluler
- Mengambang di atas aplikasi lain, bisa digeser dengan jari, posisi tersimpan
- Warna download, upload, dan latar bisa diubah (slider RGB + warna cepat)
- Atur transparansi latar, ukuran teks, interval pengukuran (250 ms - 2 detik)
- Satuan byte (KB/s, MB/s) atau bit (Kbps, Mbps)
- Kunci posisi, mulai otomatis setelah HP restart
- Tanpa library tambahan, tanpa izin internet (aplikasi tidak mengirim data apa pun)

## Cara build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru), tunggu Gradle sync selesai.
2. Colok HP (USB debugging aktif) lalu tekan **Run**, atau pilih
   *Build > Build APK(s)* untuk mendapatkan file APK.
3. Buka aplikasi, tekan **NYALAKAN METER**, berikan izin
   "Tampil di atas aplikasi lain", lalu kembali ke aplikasi.

## Tentang akurasi
Angka dibaca dari counter byte kernel (`TrafficStats`), lalu dihitung
`selisih byte / selisih waktu nyata` memakai jam monoton (`elapsedRealtimeNanos`).
Jadi hasilnya tetap benar walau pengukuran sempat telat. Catatan:
- Yang diukur adalah lalu lintas seluruh perangkat (semua aplikasi, WiFi + seluler).
- Angka ini kecepatan di level jaringan HP, sedikit lebih besar dari kecepatan unduh
  aplikasi karena termasuk overhead protokol (header TCP/IP, TLS). Sama dengan
  yang ditampilkan meter bawaan ROM dan aplikasi sejenis.
- Interval 1 detik adalah pilihan seimbang. 250-500 ms lebih responsif tetapi angkanya lebih
  "loncat-loncat" dan sedikit lebih boros baterai.

## Struktur
- `OverlayService.kt` - service foreground + jendela overlay + loop pengukuran
- `SpeedSampler.kt` - perhitungan kecepatan dan format teks
- `MainActivity.kt` - layar pengaturan (dibuat lewat kode, tanpa XML layout)
- `Prefs.kt` - penyimpanan pengaturan
- `BootReceiver.kt` - mulai otomatis setelah boot
