# Speed Meter (Android)

Indikator kecepatan internet yang mengambang di atas semua aplikasi.

## Fitur
- Upload (↑) di atas, download (↓) di bawah, real-time, WiFi dan data seluler, huruf tebal
- Bisa digeser sampai tepi paling atas layar (menimpa status bar)
- Notifikasi menampilkan kecepatan (juga sebagai ikon status bar) dan pemakaian data hari ini (Wi-Fi / Data)
- Panah di kiri angka (rapat), berkedip/menyala saat ada trafik, kembali normal saat tidak ada
- Ketebalan huruf: Normal / Tebal / Tebal banget
- Total pemakaian data hari ini, minggu ini, bulan ini di layar pengaturan
- Latar belakang layar pengaturan bisa diganti gambar dari galeri
- Ikon aplikasi "5G+"
- Mengambang di atas aplikasi lain, bisa digeser dengan jari, posisi tersimpan
- Warna download, upload, dan latar bisa diubah (slider RGB + warna cepat)
- Atur transparansi latar, ukuran teks, interval pengukuran (250 ms - 2 detik)
- Satuan byte (KB/s, MB/s) atau bit (Kbps, Mbps)
- Kunci posisi, mulai otomatis setelah HP restart
- Tanpa library tambahan, tanpa izin internet (aplikasi tidak mengirim data apa pun)

## Cara build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru), tunggu Gradle sync selesai.
2. Colok HP (USB debugging aktif) lalu tekan **Run**, atau pilih
   *Build > Build APK(s)* untuk mendapatkan file APK.
3. Buka aplikasi, tekan **NYALAKAN METER**, berikan izin
   "Tampil di atas aplikasi lain", lalu kembali ke aplikasi.

## Tentang akurasi
Angka dibaca dari counter byte kernel (`TrafficStats`) **per interface** (wlan0, rmnet, dst),
lalu dihitung `selisih byte / selisih waktu nyata` memakai jam monoton (`elapsedRealtimeNanos`).
- Saat VPN/tunnel aktif, trafik tercatat dua kali (interface fisik + `tun0`). Opsi
  **"Saat VPN aktif, ukur level aplikasi"** (aktif secara default) hanya menghitung `tun0`, yaitu
  kecepatan yang benar-benar diterima aplikasi (sama seperti angka di 1DM+). Kalau dimatikan, yang
  dihitung interface fisik (termasuk overhead tunnel). Keduanya tidak pernah dijumlahkan.
- Interval 1000 ms (1 detik) adalah pilihan seimbang. 250-500 ms lebih responsif tetapi angkanya
  lebih "loncat-loncat" dan sedikit lebih boros baterai.
- Pemakaian data "Hari ini" dihitung selama meter aktif, jadi data yang terpakai saat meter mati
  tidak ikut terhitung. Reset otomatis tiap pergantian hari.

## Struktur
- `OverlayService.kt` - service foreground + jendela overlay + loop pengukuran
- `SpeedSampler.kt` - perhitungan kecepatan dan format teks
- `MainActivity.kt` - layar pengaturan (dibuat lewat kode, tanpa XML layout)
- `Prefs.kt` - penyimpanan pengaturan
- `UsageStore.kt` - catatan pemakaian data per hari
- `BootReceiver.kt` - mulai otomatis setelah boot
