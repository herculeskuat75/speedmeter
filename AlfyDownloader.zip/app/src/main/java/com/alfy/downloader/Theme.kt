package com.alfy.downloader

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun AlfyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF80CBC4), background = Color(0xFF212121), surface = Color(0xFF303030),
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}
