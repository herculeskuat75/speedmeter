package com.alfy.downloader

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

class AlfyAccessibilityService : AccessibilityService() {
    private val skip = listOf("subscription", "live", "tren", "beranda", "notifikasi", "anda", "shorts", "disulih", "bagikan",
        "simpan", "remix", "suka", "komentar", "like", "share", "comment", "subscribe", "telusuri", "search", "lainnya",
        "kembali", "back", "more", "home", "library", "trending", "explore", "jelajahi", "buat", "create", "iklan", "sponsor")

    private val urlRe = Regex("https?://[^\\s\"'<>)]+")
    private val hostRe = Regex("^[\\w.-]+\\.[a-zA-Z]{2,}(/\\S*)?$")
    private val barIds = listOf(
        "url_bar", "url_field", "location_bar_edit_text", "mozac_browser_toolbar_url_view",
        "url_bar_title", "omnibarTextInput", "toolbar_url", "search_box_text", "url_edit_text"
    )

    private val ht = android.os.HandlerThread("alfy-scan").also { it.start() }
    private val bg = android.os.Handler(ht.looper)
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    @Volatile private var busy = false
    private var last = 0L
    private var lastFull = 0L
    private var candQ = ""
    private var doneQ = ""
    private var lastPkg = ""
    @Volatile private var titleClickAt = 0L

    companion object { @Volatile var inst: AlfyAccessibilityService? = null }

    private val cmgr by lazy { getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager }
    private var lastClipTxt = ""
    private val clipL = android.content.ClipboardManager.OnPrimaryClipChangedListener {
        // layanan aksesibilitas boleh membaca clipboard di latar belakang -> otomatis, tanpa paste
        main.post { if (!readClipDirect()) FloatingService.inst?.pullClip() ?: NetSniffer.readClipRootOnce() }
    }

    /** Baca clipboard langsung dari layanan aksesibilitas. true bila ada tautan yang ditemukan. */
    fun readClipDirect(): Boolean {
        return try {
            val t = cmgr.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: return false
            if (t.isBlank()) return false
            val urls = urlRe.findAll(t).map { it.value.trimEnd('.', ',', ';', ')') }.toList()
            if (urls.isEmpty()) return t.isNotBlank()
            urls.forEach { Resolver.rescan(it) }
            lastClipTxt = t
            Resolver.diag = "Clipboard: memindai ${urls.size} tautan…"
            true
        } catch (e: Exception) { false }
    }

    override fun onServiceConnected() {
        super.onServiceConnected(); inst = this
        try { cmgr.addPrimaryClipChangedListener(clipL) } catch (e: Exception) { }
        try {
            val i = serviceInfo
            if (i != null) {
                i.eventTypes = i.eventTypes or AccessibilityEvent.TYPE_VIEW_CLICKED or AccessibilityEvent.TYPE_VIEW_LONG_CLICKED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
                i.notificationTimeout = 50
                serviceInfo = i
            }
        } catch (e: Exception) { }
    }

    fun keyboardShown(): Boolean = try { windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } } catch (e: Exception) { false }

    /** Ambil jendela aplikasi yang sedang dibuka (bukan jendela AlfyDownloader sendiri). */
    private fun appRoot(): AccessibilityNodeInfo? {
        try {
            val r = rootInActiveWindow
            if (r != null && r.packageName?.toString() != packageName) return r
        } catch (e: Exception) { }
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val x = w.root ?: continue
                if (x.packageName?.toString() != packageName) return x
            }
        } catch (e: Exception) { }
        return null
    }

    /** Pindai layar yang sedang terbuka (tombol 🔍): langsung, tanpa menunggu. */
    fun scanNow() {
        bg.post {
            var roots = allRoots()
            for (i in 0 until 4) {
                if (roots.isNotEmpty()) break
                try { Thread.sleep(200) } catch (e: Exception) { }
                roots = allRoots()
            }
            if (roots.isEmpty()) { Resolver.diag = "Layar belum terbaca, coba lagi"; return@post }
            Resolver.diag = "Memindai layar…"
            var found = 0
            for (root in roots) try { found += process(root, root.packageName?.toString() ?: "", true, false) } catch (e: Exception) { }
            if (found == 0 && Resolver.diag == "Memindai layar…") Resolver.diag = "Layar dipindai: tidak ada tautan/video terbaca"
        }
    }

    private fun clipSoon() {
        for (d in longArrayOf(300, 1200)) main.postDelayed({
            if (readClipDirect()) return@postDelayed
            val f = FloatingService.inst
            if (f != null) f.pullClip() else NetSniffer.readClipRootOnce()
        }, d)
    }

    /** Semua jendela aplikasi (bukan AlfyDownloader) — termasuk popup/bottom sheet. */
    private fun allRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION && w.type != AccessibilityWindowInfo.TYPE_SYSTEM) continue
                val x = w.root ?: continue
                if (x.packageName?.toString() != packageName) out.add(x)
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) appRoot()?.let { out.add(it) }
        return out
    }

    private fun isNavText(t: String): Boolean { val l = t.lowercase().trim(); return skip.any { l == it || l.startsWith("$it ") } }

    /** Teks keterangan thumbnail YouTube: "Judul - 5 menit - Buka saluran X - 1 jt x ditonton ..." -> ambil judul. */
    private fun titleFromDesc(d: String): String? {
        val parts = d.split(" - ", " – ", " • ").map { it.trim() }.filter { it.isNotEmpty() }
        val t = parts.firstOrNull() ?: return null
        if (t.length < 4 || isNavText(t)) return null
        return t.take(120)
    }

    /** Setelah klik video/tautan: pindai layar di latar belakang (tunggu layar baru muncul). */
    private fun burst(pkg: String) {
        for (d in longArrayOf(1500, 3500)) bg.postDelayed({
            try {
                val r = appRoot() ?: return@postDelayed
                process(r, r.packageName?.toString() ?: pkg, false, true)
            } catch (ex: Exception) { }
        }, d)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val type = e.eventType
        val txt = (e.text?.joinToString(" ") ?: "") + " " + (e.contentDescription ?: "")
        val low = txt.lowercase()

        // Klik / tahan video atau tautan -> langsung pindai di latar belakang
        if (type == AccessibilityEvent.TYPE_VIEW_CLICKED || type == AccessibilityEvent.TYPE_VIEW_LONG_CLICKED) {
            val sb = StringBuilder(txt)
            try {
                var n: AccessibilityNodeInfo? = e.source
                var d = 0
                while (n != null && d < 4) {
                    sb.append(' ').append(n.text ?: "").append(' ').append(n.contentDescription ?: "")
                    n = n.parent; d++
                }
            } catch (ex: Exception) { }
            val all = sb.toString()
            urlRe.findAll(all).forEach { Resolver.submit(it.value.trimEnd('.', ',', ';', ')'), null, true) }
            if (pkg.contains("youtube", true)) {
                // thumbnail yang diklik: judulnya ada di deskripsi -> langsung cari video itu
                val cds = ArrayList<String>()
                try {
                    var n: AccessibilityNodeInfo? = e.source; var d = 0
                    while (n != null && d < 5) { n.contentDescription?.toString()?.let { cds.add(it) }; n.text?.toString()?.let { cds.add(it) }; n = n.parent; d++ }
                } catch (ex: Exception) { }
                cds.add(txt)
                val t = cds.filter { it.length > 12 && !isNavText(it) }.maxByOrNull { it.length }?.let { titleFromDesc(it) }
                if (t != null) { titleClickAt = SystemClock.uptimeMillis(); candQ = t; doneQ = t; Resolver.latestYt = t; Resolver.searchYoutube(t, false, true) }
            }
            val l = all.lowercase()
            if (l.contains("salin") || l.contains("copy") || l.contains("copied")) clipSoon()
            burst(pkg)
            return
        }

        // Toast "tautan disalin" / pratinjau clipboard sistem -> baca clipboard terbaru
        if (type == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED || pkg.contains("systemui")) {
            if (low.contains("disalin") || low.contains("copied") || low.contains("salin") || low.contains("clipboard") ||
                low.contains("papan klip") || low.contains("tautan") || low.contains("link")) clipSoon()
            urlRe.findAll(txt).forEach { Resolver.submit(it.value) }
            if (type == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        }
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != lastPkg) { lastPkg = pkg; burst(pkg) }
        if (busy) return
        val now = SystemClock.uptimeMillis()
        if (now - last < 200) return
        last = now
        busy = true
        bg.post {
            try {
                val root = rootInActiveWindow ?: return@post
                process(root, pkg, false, false)
            } catch (ex: Exception) { } finally { busy = false }
        }
    }

    override fun onDestroy() { inst = null; try { cmgr.removePrimaryClipChangedListener(clipL) } catch (e: Exception) { }; try { ht.quitSafely() } catch (e: Exception) { }; super.onDestroy() }

    private fun process(root: AccessibilityNodeInfo, pkg: String, manual: Boolean, click: Boolean): Int {
        var found = 0
        for (n in barIds) {
            root.findAccessibilityNodeInfosByViewId("$pkg:id/$n")?.forEach { v ->
                v.text?.toString()?.let { handleBar(it) }
            }
        }
        val yt = pkg.contains("youtube", true)
        if (yt) {
            if (manual) {
                val q = ytQuery(root)
                if (q == null) Resolver.diag = "YouTube: teks video di layar tidak terbaca"
                else { candQ = q.first; doneQ = q.first; Resolver.searchYoutube(q.first, q.second, true) }
            } else if (click) {
                if (SystemClock.uptimeMillis() - titleClickAt > 6000 && onPlayer(root)) {
                    val q = ytQuery(root)
                    if (q != null && q.first != doneQ) { candQ = q.first; doneQ = q.first; Resolver.latestYt = q.first; Resolver.searchYoutube(q.first, q.second, true) }
                }
            } else if (onPlayer(root)) {
                ytAuto(root)
            }
        }
        // Pindai semua teks layar untuk alamat http(s) (otomatis, dibatasi agar ringan)
        val now = SystemClock.uptimeMillis()
        if (manual || click || now - lastFull > 1200) {
            lastFull = now
            found += scan(root, 0, IntArray(1), manual || click)
        }
        return found
    }

    /** Teks YouTube di layar: handle channel + keterangan video. Mengembalikan (query, apakah Shorts). */
    private fun ytQuery(root: AccessibilityNodeInfo): Pair<String, Boolean>? {
        val texts = LinkedHashSet<String>()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 25 || texts.size > 150) return
            n.text?.toString()?.trim()?.let { if (it.isNotEmpty()) texts.add(it) }
            n.contentDescription?.toString()?.trim()?.let { if (it.isNotEmpty()) texts.add(it) }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        val handleRe = Regex("@[A-Za-z0-9._-]{3,}")
        val handle = texts.firstNotNullOfOrNull { handleRe.find(it)?.value }
        val cap = texts.filter { t ->
            t.length in 6..140 && !t.matches(Regex("[\\d.,: KkMmRrbBtT]+")) && t != handle &&
                (handle == null || !t.contains(handle)) && skip.none { t.lowercase().startsWith(it) }
        }.maxByOrNull { it.length }
        if (handle == null && cap == null) return null
        val shorts = texts.any { it.equals("shorts", true) }
        return Pair(((handle ?: "") + " " + (cap ?: "")).trim(), shorts)
    }

    /** Otomatis: tunggu layar stabil sebentar (geser Shorts), baru cari video yang sedang tampil. */
    private fun ytAuto(root: AccessibilityNodeInfo) {
        val r = ytQuery(root) ?: return
        val q = r.first
        if (q == candQ) return
        candQ = q
        if (q == doneQ) return
        bg.postDelayed({
            if (candQ == q && doneQ != q) { doneQ = q; Resolver.latestYt = q; Resolver.searchYoutube(q, r.second) }
        }, 800)
    }

    /** Layar pemutar YouTube (Shorts / halaman tonton) = ada tombol bagikan + aksi suka/simpan/remix. */
    private fun onPlayer(root: AccessibilityNodeInfo): Boolean {
        var share = false; var act = false; var n = 0
        fun walk(x: AccessibilityNodeInfo?, d: Int) {
            if (x == null || d > 25 || n++ > 400 || (share && act)) return
            val t = ((x.text?.toString() ?: "") + " " + (x.contentDescription?.toString() ?: "")).lowercase()
            if (t.contains("bagikan") || t.contains("share")) share = true
            if (t.contains("remix") || t.contains("simpan") || t.contains("save") || t.contains("suka") || t.contains("like")) act = true
            for (i in 0 until x.childCount) walk(x.getChild(i), d + 1)
        }
        walk(root, 0)
        return share || act
    }

    private fun handleBar(t: String) {
        var s = t.trim()
        if (s.contains(' ')) return
        if (!s.startsWith("http")) {
            if (hostRe.matches(s)) s = "https://$s" else return
        }
        Resolver.lastPage = s
        Resolver.submit(s)
        Resolver.sniff(s)
    }

    private fun scan(n: AccessibilityNodeInfo?, d: Int, cnt: IntArray, force: Boolean): Int {
        if (n == null || d > 30 || cnt[0]++ > 1200) return 0
        var f = 0
        for (t in listOf(n.text?.toString(), n.contentDescription?.toString())) {
            if (t != null && t.contains("http")) {
                urlRe.findAll(t).forEach { m -> f++; Resolver.submit(m.value.trimEnd('.', ',', ';', ')'), null, force) }
            }
        }
        for (i in 0 until n.childCount) f += scan(n.getChild(i), d + 1, cnt, force)
        return f
    }

    override fun onInterrupt() {}
}
