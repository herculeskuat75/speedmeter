package com.alfy.downloader

import android.app.Application
import android.os.StrictMode
import android.util.Log
import com.yausername.youtubedl_android.YoutubeDL

object Engine {
    @Volatile var ready = false
    @Volatile var error: String? = null
    fun await() {
        var n = 0
        while (!ready && n < 400) { Thread.sleep(300); n++ }
        if (!ready) throw Exception("Mesin unduh belum siap: $error")
    }
}

class AlfyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Repo.init(this)
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
        Thread {
            try {
                YoutubeDL.getInstance().init(this)
                Engine.ready = true
                updateEngine()
            } catch (e: Throwable) {
                Engine.error = e.message
                Log.e("Alfy", "init gagal", e)
            }
        }.start()
    }
}

/** Perbarui yt-dlp ke versi terbaru (YouTube sering berubah; versi lama memunculkan "Please sign in"). */
fun Application.updateEngine() {
    try {
        val yd = YoutubeDL.getInstance()
        for (chan in listOf("NIGHTLY", "STABLE")) {
            for (m in yd.javaClass.methods.filter { it.name == "updateYoutubeDL" }) {
                try {
                    val pt = m.parameterTypes
                    val args = arrayOfNulls<Any>(pt.size)
                    for (k in pt.indices) {
                        args[k] = when {
                            android.content.Context::class.java.isAssignableFrom(pt[k]) -> this
                            else -> {
                                val cls = pt[k]
                                val f = cls.fields.firstOrNull { it.name.equals(chan, true) || it.name.equals("_$chan", true) }
                                f?.get(null) ?: cls.enumConstants?.firstOrNull { it.toString().equals(chan, true) }
                                    ?: cls.declaredClasses.firstOrNull { it.simpleName.equals(chan, true) || it.simpleName.equals("_$chan", true) }
                                        ?.getField("INSTANCE")?.get(null)
                            }
                        }
                    }
                    if (args.any { it == null }) continue
                    m.invoke(yd, *args)
                    Resolver.diag = "yt-dlp diperbarui ($chan)"
                    return
                } catch (e: Throwable) { }
            }
        }
    } catch (e: Throwable) { }
}
