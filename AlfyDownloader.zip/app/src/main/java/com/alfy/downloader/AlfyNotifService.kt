package com.alfy.downloader

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService

/** Pendeteksi tanpa root: membaca judul + channel video YouTube/ReVanced yang sedang diputar lewat MediaSession (butuh izin Akses Notifikasi). */
class AlfyNotifService : NotificationListenerService() {
    companion object {
        @Volatile var status = "Notifikasi: belum diizinkan (tekan tombol di 📖)"
        fun enabled(c: android.content.Context): Boolean =
            (android.provider.Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: "").contains(c.packageName)
    }

    private var msm: MediaSessionManager? = null
    private val ctrls = HashMap<String, Pair<MediaController, MediaController.Callback>>()
    private var lastQ = ""
    private val listener = MediaSessionManager.OnActiveSessionsChangedListener { l -> attach(l) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            val m = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            msm = m
            val cn = ComponentName(this, AlfyNotifService::class.java)
            m.addOnActiveSessionsChangedListener(listener, cn)
            attach(m.getActiveSessions(cn))
            status = "Notifikasi: aktif ✓ (menunggu video diputar)"
        } catch (e: Exception) { status = "Notifikasi: gagal ${(e.message ?: "").take(60)}" }
    }

    private fun attach(list: List<MediaController>?) {
        if (list == null) return
        for (c in list) {
            val pkg = c.packageName ?: continue
            if (!pkg.contains("youtube", true)) continue
            ctrls.remove(pkg)?.let { try { it.first.unregisterCallback(it.second) } catch (e: Exception) { } }
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) { handle(metadata) }
            }
            try { c.registerCallback(cb); ctrls[pkg] = Pair(c, cb); handle(c.metadata) } catch (e: Exception) { }
        }
    }

    private fun handle(m: MediaMetadata?) {
        if (m == null) return
        val t = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val a = m.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val q = (a + " " + t).trim()
        if (t.length < 3 || q == lastQ) return
        lastQ = q
        status = "Notifikasi: ✓ ${q.take(40)}"
        Resolver.latestYt = q
        Resolver.searchYoutube(q, false)
    }

    override fun onListenerDisconnected() {
        status = "Notifikasi: terputus"
        try { msm?.removeOnActiveSessionsChangedListener(listener) } catch (e: Exception) { }
        super.onListenerDisconnected()
    }
}
