package com.alfy.downloader

import java.io.BufferedReader
import java.io.InputStreamReader

/** Sniffer lalu lintas jaringan (butuh root): logcat semua aplikasi + tcpdump (jika tersedia). */
object NetSniffer {
    @Volatile private var running = false
    @Volatile var status = "Sniffer: memulai…"
    private val procs = mutableListOf<Process>()
    private val urlRe = Regex("https?://[^\\s\"'<>\\\\)]+")

    /** Tombol AKTIFKAN: minta root, beri izin, nyalakan (ulang) pemantau. */
    fun enable(pkg: String) {
        Thread {
            status = "Meminta akses root…"
            val ok = try {
                val me = "$pkg/$pkg.AlfyAccessibilityService"
                val d = "\$"
                val cmd = "appops set $pkg SYSTEM_ALERT_WINDOW allow; pm grant $pkg android.permission.READ_LOGS; pm grant $pkg android.permission.POST_NOTIFICATIONS; pm grant $pkg android.permission.READ_EXTERNAL_STORAGE; pm grant $pkg android.permission.WRITE_EXTERNAL_STORAGE; dumpsys deviceidle whitelist +$pkg; " +
                    "cur=${d}(settings get secure enabled_accessibility_services); " +
                    "case \"${d}cur\" in *$me*) ;; *) settings put secure enabled_accessibility_services \"${d}{cur#null}:$me\" ;; esac; " +
                    "settings put secure accessibility_enabled 1; id"
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                val out = p.inputStream.bufferedReader().readText()
                p.waitFor(); out.contains("uid=0")
            } catch (e: Exception) { false }
            if (!ok) { status = "Root DITOLAK/tidak ada. Izinkan di Magisk lalu tekan tombol lagi."; return@Thread }
            stop(); start()
        }.start()
    }

    /** Coba pasang tcpdump lewat Termux (jika Termux terpasang). */
    fun installTcpdump() {
        Thread {
            val tp = "/data/data/com.termux/files/usr"
            status = "Memasang tcpdump via Termux… (butuh internet)"
            try {
                val cmd = "[ -x $tp/bin/pkg ] || exit 7; export PREFIX=$tp HOME=$tp/../home PATH=$tp/bin LD_LIBRARY_PATH=$tp/lib; " +
                    "yes | $tp/bin/pkg install -y tcpdump 2>&1 | tail -3; [ -x $tp/bin/tcpdump ]"
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                p.inputStream.readBytes(); val code = p.waitFor()
                status = if (code == 0) "tcpdump terpasang ✓" else if (code == 7) "Termux belum terpasang. Pasang Termux dulu (F-Droid)." else "Pasang tcpdump gagal. Buka Termux lalu ketik: pkg install tcpdump"
                if (code == 0) { stop(); start() }
            } catch (e: Exception) { status = "Pasang tcpdump gagal: ${e.message}" }
        }.start()
    }

    @Synchronized fun start() {
        if (running) return
        running = true
        status = "Memulai pemantau…"
        // logcat selalu aktif (hanya link media/googlevideo asli); logcat penuh + tcpdump hanya bila "pantau semua" dinyalakan
        Thread { logcat() }.apply { isDaemon = true }.start()
        if (Repo.prefs().getBoolean("sniffAll", false)) Thread { dump() }.apply { isDaemon = true }.start()
        Thread { media() }.apply { isDaemon = true }.start()
        Thread { clip() }.apply { isDaemon = true }.start()
    }

    @Synchronized fun stop() {
        running = false
        procs.forEach { try { it.destroy() } catch (e: Exception) { } }
        procs.clear()
    }

    private fun su(cmd: String): Process? = try {
        Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).also { synchronized(this) { procs.add(it) } }
    } catch (e: Exception) { null }

    private fun feed(line: String) {
        if (!line.contains("http")) return
        val all = Repo.prefs().getBoolean("sniffAll", false)
        urlRe.findAll(line).forEach {
            val u = it.value.trimEnd('.', ',', ';').replace("\\u0026", "&")
            // mode normal: hanya link media asli (googlevideo/videoplayback, mp4, m3u8, mp3, ...)
            if (all || Resolver.isMedia(u)) Resolver.submit(u)
        }
    }

    /** URL yang dicatat pemutar media/aplikasi di logcat. */
    private fun logcat() {
        val p = su("pm grant com.alfy.downloader android.permission.READ_LOGS; logcat -b all -v raw -T 1 *:V")
        if (p == null) { status = "Root: tidak tersedia"; return }
        status = "Root: aktif • pemantau link aktif"
        try {
            BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                while (running) feed(r.readLine() ?: break)
            }
        } catch (e: Exception) { }
    }

    /** Paket HTTP polos (port 80 / 8080) via tcpdump bila ada di HP. */
    private fun dump() {
        val which = su("which tcpdump; ls /system/xbin/tcpdump /system/bin/tcpdump /data/local/tmp/tcpdump /data/adb/modules/*/system/*bin/tcpdump /data/data/com.termux/files/usr/bin/tcpdump 2>/dev/null")
            ?: return
        val bin = try {
            which.inputStream.bufferedReader().readLines().firstOrNull { it.contains("tcpdump") }?.trim()
        } catch (e: Exception) { null }
        if (bin == null) return
        status += " • tcpdump aktif"
        val p = su("LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib:\$LD_LIBRARY_PATH $bin -i any -l -A -s 1500 'tcp and (port 80 or port 8080)'") ?: return
        var path: String? = null
        try {
            BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                while (running) {
                    val l = r.readLine() ?: break
                    Regex("(?:GET|HEAD) (\\S+) HTTP").find(l)?.let { path = it.groupValues[1] }
                    Regex("Host: (\\S+)").find(l)?.let { m ->
                        val pa = path
                        if (pa != null) {
                            Resolver.submit(if (pa.startsWith("http")) pa else "http://${m.groupValues[1]}$pa")
                            path = null
                        }
                    }
                    feed(l)
                }
            }
        } catch (e: Exception) { }
    }

    /** Deteksi aplikasi YouTube: baca judul video yang sedang diputar (media session) lalu cari URL-nya. */
    private fun media() {
        val p = su("while true; do dumpsys media_session 2>/dev/null | grep -E 'package=|metadata:'; echo ---; sleep 2; done") ?: return
        var pkg = ""
        var last = ""
        try {
            BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                while (running) {
                    val l = (r.readLine() ?: break).trim()
                    if (l.startsWith("package=")) pkg = l.substringAfter("package=").trim()
                    else if (l == "---") pkg = ""
                    else if (l.startsWith("metadata:") && pkg.contains("youtube", true)) {
                        val d = l.substringAfter("description=", "").trim()
                            .removeSuffix(", null").removeSuffix(", null").trim()
                        if (d.length > 3 && d != last && d != "null") {
                            last = d
                            Resolver.searchYoutube(d)
                        }
                    }
                }
            }
        } catch (e: Exception) { }
    }

    // ---------- Clipboard via root (tanpa mencuri fokus layar, jadi tidak mengganggu saat mengetik) ----------
    @Volatile var clipRoot = false
    @Volatile private var clipCmd: String? = null
    @Volatile private var lastClip = ""
    private val clipUrlRe = Regex("https?://[^\\s\\u0000-\\u001F\\\"<>]+")

    private fun clipVariants(): List<String> {
        val sdk = android.os.Build.VERSION.SDK_INT
        val args = listOf("s16 %s i32 0", "s16 %s s16 null i32 0", "s16 %s s16 null i32 0 i32 0")
        val order = when { sdk <= 30 -> listOf(0, 1, 2); sdk <= 34 -> listOf(1, 2, 0); else -> listOf(2, 1, 0) }
        val out = ArrayList<String>()
        for (i in order) for (pkg in listOf("android", "root", "com.android.shell")) out.add("service call clipboard 3 " + args[i].format(pkg))
        for (i in order) out.add("su 2000 -c 'service call clipboard 3 " + args[i].format("com.android.shell") + "'")
        return out
    }

    private fun parseParcel(out: String): Pair<Boolean, String>? {
        val i = out.indexOf("Parcel(")
        if (i < 0) return null
        val body = out.substring(i + 7).replace(Regex("'[^']*'"), " ").replace(Regex("0x[0-9a-fA-F]+:"), " ")
        val words = Regex("\\b[0-9a-fA-F]{8}\\b").findAll(body).map { it.value }.toList()
        if (words.isEmpty()) return null
        val bytes = ByteArray(words.size * 4)
        words.forEachIndexed { k, w ->
            val v = w.toLong(16)
            for (b in 0..3) bytes[k * 4 + b] = ((v shr (8 * b)) and 0xFF).toByte()
        }
        return Pair(words[0] == "00000000", String(bytes, Charsets.UTF_16LE))
    }

    private fun runSu(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val o = p.inputStream.bufferedReader().readText(); p.waitFor(); o
    } catch (e: Exception) { "" }

    private fun urlsIn(t: String): List<String> =
        clipUrlRe.findAll(t).map { it.value.trimEnd('.', ',', ';', ')') }.filter { it.length > 10 }.distinct().toList()

    /** Baca clipboard sekali (dipanggil saat ada tanda tautan disalin). */
    fun readClipRootOnce() {
        Thread {
            val c = clipCmd ?: return@Thread
            val r = parseParcel(runSu(c)) ?: return@Thread
            lastClip = r.second
            urlsIn(r.second).forEach { Resolver.rescan(it) }
        }.start()
    }

    private fun clip() {
        while (running) {
            var c = clipCmd
            if (c == null) {
                for (v in clipVariants()) { val r = parseParcel(runSu(v)); if (r != null && r.first) { c = v; break } }
                if (c == null) { clipRoot = false; try { Thread.sleep(20000) } catch (e: Exception) { }; continue }
                clipCmd = c; clipRoot = true
            }
            val p = su("while true; do $c; echo ---; sleep 1; done") ?: return
            var first = true
            try {
                BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                    val sb = StringBuilder()
                    while (running) {
                        val l = r.readLine() ?: break
                        if (l.trim() == "---") {
                            val res = parseParcel(sb.toString()); sb.setLength(0)
                            if (res != null) {
                                val t = res.second
                                if (first) { first = false; lastClip = t }
                                else if (t != lastClip) { lastClip = t; urlsIn(t).forEach { Resolver.rescan(it) } }
                            }
                        } else sb.append(l).append('\n')
                    }
                }
            } catch (e: Exception) { }
            if (!running) return
            try { Thread.sleep(3000) } catch (e: Exception) { }
        }
    }
}
