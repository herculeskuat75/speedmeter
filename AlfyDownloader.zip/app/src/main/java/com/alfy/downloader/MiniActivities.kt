package com.alfy.downloader

import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.core.content.ContextCompat

class PreviewActivity : Activity() {
    private var player: androidx.media3.exoplayer.ExoPlayer? = null
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())
    private var tick: Runnable? = null
    private var spinner: ProgressBar? = null
    private var btnPlay: TextView? = null
    private var btnMute: TextView? = null
    private var seek: SeekBar? = null
    private var timeTv: TextView? = null
    private var surface: android.view.SurfaceView? = null
    private var root: FrameLayout? = null
    private var vw = 0
    private var vh = 0
    private var closing = false
    private var muted = false
    private var failed = false
    private val fallbacks = ArrayDeque<androidx.media3.exoplayer.source.MediaSource>()

    private fun fmt(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }

    private fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(28, 12, 28, 12); setOnClickListener { onClick() }
    }

    private fun refreshUi() {
        val p = player ?: return
        val st = p.playbackState
        val loading = !failed && (st == androidx.media3.common.Player.STATE_BUFFERING || st == androidx.media3.common.Player.STATE_IDLE)
        spinner?.visibility = if (loading) View.VISIBLE else View.GONE
        btnPlay?.text = if (p.playWhenReady && st != androidx.media3.common.Player.STATE_ENDED) "⏸" else "▶"
        btnMute?.text = if (muted) "🔇" else "🔊"
    }

    private fun fitVideo() {
        val sv = surface ?: return
        val r = root ?: return
        if (vw <= 0 || vh <= 0) return
        val W = if (r.width > 0) r.width else resources.displayMetrics.widthPixels
        val H = if (r.height > 0) r.height else resources.displayMetrics.heightPixels
        val scale = minOf(W.toFloat() / vw, H.toFloat() / vh)
        sv.layoutParams = FrameLayout.LayoutParams((vw * scale).toInt(), (vh * scale).toInt(), Gravity.CENTER)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val url = intent.getStringExtra("url") ?: run { finish(); return }
        val audioUrl = intent.getStringExtra("audio")
        val mode = intent.getStringExtra("mode") ?: "video"
        val sepAudio = intent.getBooleanExtra("muted", false) && audioUrl != null && audioUrl != url
        val ua = intent.getStringExtra("ua") ?: Resolver.UA
        val props = HashMap<String, String>()
        intent.getStringExtra("ref")?.let { props["Referer"] = it }

        val fl = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root = fl
        setContentView(fl)
        val sv = android.view.SurfaceView(this)
        surface = sv
        if (mode == "audio") {
            fl.addView(TextView(this).apply { text = "♪"; textSize = 96f; setTextColor(0x55FFFFFF); gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            fl.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        }

        // animasi berputar saat memuat
        val sp = ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        }
        spinner = sp
        fl.addView(sp, FrameLayout.LayoutParams(150, 150, Gravity.CENTER))

        // tombol kembali (kiri atas)
        fl.addView(btn("←") { closeNow() }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { topMargin = 40; leftMargin = 8 })

        // kontrol bawah: jeda, bisukan, geser waktu
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x99000000.toInt()); setPadding(8, 8, 8, 8)
        }
        val pb = btn("⏸") {
            val p = player ?: return@btn
            if (p.playWhenReady && p.playbackState != androidx.media3.common.Player.STATE_ENDED) p.playWhenReady = false
            else { if (p.playbackState == androidx.media3.common.Player.STATE_ENDED) p.seekTo(0); p.playWhenReady = true }
            refreshUi()
        }
        btnPlay = pb
        val mb = btn("🔊") {
            muted = !muted
            player?.volume = if (muted) 0f else 1f
            refreshUi()
        }
        btnMute = mb
        val sb = SeekBar(this)
        seek = sb
        val tt = TextView(this).apply { text = "0:00 / 0:00"; setTextColor(Color.WHITE); textSize = 12f; setPadding(8, 0, 8, 0) }
        timeTv = tt
        bar.addView(pb); bar.addView(mb)
        bar.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(tt)
        fl.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) { if (fromUser) player?.seekTo(v.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        try {
            val http = androidx.media3.datasource.DefaultHttpDataSource.Factory()
                .setUserAgent(ua).setDefaultRequestProperties(props)
                .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(12000).setReadTimeoutMs(15000)
            val msf = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(this)
                .setDataSourceFactory(androidx.media3.datasource.DataSource.Factory { ChunkedDataSource(http) })
            val p = androidx.media3.exoplayer.ExoPlayer.Builder(this).build()
            player = p
            val main = msf.createMediaSource(androidx.media3.common.MediaItem.fromUri(
                if (mode == "audio" && audioUrl != null) audioUrl else url))
            val src: androidx.media3.exoplayer.source.MediaSource =
                if (mode == "video" && sepAudio)
                    androidx.media3.exoplayer.source.MergingMediaSource(main, msf.createMediaSource(androidx.media3.common.MediaItem.fromUri(audioUrl!!)))
                else main
            if (mode == "video") {
                val fbUrl = intent.getStringExtra("fallback")
                if (fbUrl != null && fbUrl != url) fallbacks.addLast(msf.createMediaSource(androidx.media3.common.MediaItem.fromUri(fbUrl)))
                if (sepAudio) fallbacks.addLast(msf.createMediaSource(androidx.media3.common.MediaItem.fromUri(url)))
            }
            if (mode == "audio") {
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_VIDEO, true).build()
            } else p.setVideoSurfaceView(sv)
            p.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { refreshUi() }
                override fun onIsPlayingChanged(isPlaying: Boolean) { refreshUi() }
                override fun onVideoSizeChanged(v: androidx.media3.common.VideoSize) { vw = v.width; vh = v.height; fitVideo() }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    val fb = fallbacks.removeFirstOrNull()
                    if (fb != null) {   // gagal -> coba sumber cadangan
                        p.setMediaSource(fb); p.prepare(); p.playWhenReady = true
                        return
                    }
                    failed = true; refreshUi()
                    val hc = (error.cause as? androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException)?.responseCode
                    Toast.makeText(this@PreviewActivity, "Tidak bisa diputar (" + (if (hc != null) "HTTP $hc" else error.errorCodeName) + ")", Toast.LENGTH_SHORT).show()
                }
            })
            p.setMediaSource(src)
            p.prepare()
            p.playWhenReady = true
        } catch (e: Exception) {
            failed = true
            Toast.makeText(this, "Tidak bisa diputar", Toast.LENGTH_SHORT).show()
        }
        val r = object : Runnable {
            override fun run() {
                val p = player
                if (p != null && !closing) {
                    try {
                        val d = p.duration
                        if (d > 0) { seek?.max = d.toInt(); seek?.progress = p.currentPosition.toInt() }
                        timeTv?.text = fmt(p.currentPosition) + " / " + fmt(if (d > 0) d else 0)
                        refreshUi()
                    } catch (e: Exception) { }
                    ui.postDelayed(this, 500)
                }
            }
        }
        tick = r; ui.post(r)
        refreshUi()
    }

    /** Tutup seketika: suara berhenti, layar menutup, langsung kembali ke aplikasi sebelumnya. */
    private fun closeNow() {
        if (closing) return
        closing = true
        tick?.let { ui.removeCallbacks(it) }
        try { player?.playWhenReady = false } catch (e: Exception) { }
        finish()
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    override fun onBackPressed() { closeNow() }
    override fun dispatchKeyEvent(ev: android.view.KeyEvent): Boolean {
        if (ev.keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            if (ev.action == android.view.KeyEvent.ACTION_UP) closeNow()
            return true
        }
        return super.dispatchKeyEvent(ev)
    }
    override fun onPause() { super.onPause(); try { player?.playWhenReady = false } catch (e: Exception) { } }
    override fun onDestroy() {
        closing = true
        tick?.let { ui.removeCallbacks(it) }
        try { player?.release() } catch (e: Exception) { }
        player = null
        super.onDestroy()
    }
}

class ClipActivity : Activity() {
    private var done = false
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
                val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
                urls.forEach { Resolver.rescan(it) }
                if (urls.isNotEmpty()) Resolver.diag = "Clipboard: memindai ${urls.size} tautan…"
            } catch (e: Exception) { }
            finish()
            overridePendingTransition(0, 0)
        }
    }
}

class ShareActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val t = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        val urls = Regex("https?://[^\\s]+").findAll(t).map { it.value }.toList()
        urls.forEach { Resolver.rescan(it) }
        if (Settings.canDrawOverlays(this) && !FloatingService.running)
            ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        Toast.makeText(this, if (urls.isEmpty()) "Tidak ada tautan" else "Memindai tautan… cek menu mengambang", Toast.LENGTH_LONG).show()
        finish()
    }
}

class BrowserActivity : Activity() {
    private lateinit var wv: WebView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF212121.toInt()) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val et = EditText(this).apply {
            setText(intent.getStringExtra("url") ?: "https://www.google.com")
            setSingleLine(); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val go = Button(this).apply { text = "Buka" }
        bar.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(go)
        wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.settings.mixedContentMode = 0
        // Google memblokir login di WebView ber-UA bawaan; UA Firefox biasanya diterima
        wv.settings.userAgentString = "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0"
        try { android.webkit.CookieManager.getInstance().setAcceptCookie(true); android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true) } catch (e: Exception) { }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                if (Resolver.isMedia(u)) Resolver.submit(u, request.requestHeaders["Referer"] ?: view.url)
                return null
            }
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                et.setText(url); Resolver.submit(url)
            }
        }
        fun load() {
            var u = et.text.toString().trim()
            if (!u.startsWith("http")) u = if (u.contains(".") && !u.contains(" ")) "https://$u" else "https://www.google.com/search?q=" + Uri.encode(u)
            wv.loadUrl(u)
        }
        go.setOnClickListener { load() }
        root.addView(bar)
        root.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        load()
    }

    override fun onPause() { try { android.webkit.CookieManager.getInstance().flush() } catch (e: Exception) { }; super.onPause() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (wv.canGoBack()) wv.goBack() else super.onBackPressed() }
}
