# AlfyDownloader+
Upload folder ini ke GitHub (branch main) -> tab Actions -> "Build AlfyDownloader+ APK" -> unduh APK dari tab Releases.
Setelah install: beri izin Overlay, Aksesibilitas, Penyimpanan (menu ⚙ di aplikasi).

## Deteksi jaringan
Lihat tombol 📖 di aplikasi untuk panduan root, tcpdump, dan izin.

## Catatan versi ini
- YouTube: hanya link asli googlevideo.com/videoplayback (jalur cepat API pemutar, yt-dlp sebagai cadangan).
- Pratinjau: ExoPlayer (animasi loading, jeda, bisu, geser waktu, tombol kembali satu kali).
- Menu mengambang: seret ke lingkaran X di bawah untuk menyembunyikan; daftar link bisa digeser lewat judulnya.
- Scan otomatis (layar, URL bar, clipboard terbaru, logcat media) dan tombol 🔍 membaca clipboard terbaru.

## Versi rantai alat (v2)
- 6 alat pengambil link YouTube jalan bersamaan: ytFast, NewPipe, yt-dlp, HLS/Piped, yt-dlp+cookies, WebView. Log tiap alat tampil di panel menu mengambang; tiap link berlabel [alat].
- Tambahan: Akses Notifikasi (deteksi tanpa root), Lepas VPN, cookies login. Penjelasan lengkap ada di aplikasi (tombol 📖).
- Baca KONTEKS.md untuk status proyek. APK jadi lebih besar karena NewPipeExtractor.
