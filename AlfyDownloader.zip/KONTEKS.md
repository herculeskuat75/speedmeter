# KONTEKS PROYEK — AlfyDownloader+ (baca ini dulu di sesi baru)

## Tujuan
Aplikasi Android (Kotlin, Compose) pengunduh video/musik. Tombol mengambang yang bisa digeser, mendeteksi link video/musik otomatis di semua aplikasi di latar belakang, lalu mengunduh. APK ringan, build lewat GitHub Actions (`.github/workflows/build.yaml`), hasil masuk tab Releases.

## Pengguna
HP Android root, memakai ReVanced YouTube (app.revanced.android.youtube), sering memakai VPN (DarkTunnel, HTTP Custom). Prioritas utama: scan otomatis di belakang layar harus berhasil jadi link yang bisa diunduh. Tool berat boleh. Log per tool harus tampil di panel menu mengambang. Instruksi untuk pengguna ditulis di dalam aplikasi (tombol 📖), bukan di chat.

## Fakta penting dari uji lapangan (build v2)
- Pengguna HANYA bisa online lewat VPN (tidak ada kuota di luar VPN): fitur 'Lepas VPN' tidak berguna baginya. Semua alat harus bisa jalan di IP VPN + root.
- Hasil uji v2: semua alat gagal 'bot check' / LOGIN_REQUIRED (IP VPN ditandai YouTube). Deteksi video lewat Akses Notifikasi BERHASIL (judul + channel terbaca).
- v3: jalur yang tidak bergantung IP VPN / memakai login: yt-dlp+cookies (WebView login UA Firefox + cookies root dari Firefox/Chromium), Piped/Invidious dinamis (link diproksikan server), WebView memakai login yang sama.

## Arsitektur dua tahap
1. Deteksi video: Accessibility (AlfyAccessibilityService), media_session + logcat + clipboard (NetSniffer, root), Notifikasi MediaSession tanpa root (AlfyNotifService), menu Share.
2. Ubah video jadi link unduhan: `Chain.run()` di `Tools.kt` menjalankan 7 alat bersamaan secara bertahap:
   - ytFast (API pemutar iOS/Android VR) — `Resolver.ytFast`
   - NewPipe (NewPipeExtractor v0.26.5 via JitPack, refleksi) — `NP.fetch`
   - yt-dlp (6 klien, --force-ipv4) — `Resolver.ytdlpTool`
   - yt-dlp+cookies — `Cookies.file()` (WebView login + cookies root Firefox/Chromium), langsung jalan
   - Piped/Invidious dinamis — `Inst.fetch` (daftar server diambil otomatis, paralel)
   - HLS iOS/VR — `Resolver.youtubeFallback` (tunda 3 dtk, lewati bila sudah ada hasil)
   - WebView tersembunyi — `WebTool.grab` menangkap googlevideo/videoplayback, tunda 5 dtk
   Jeda coba ulang 60 detik per video, lalu satu kali coba ulang otomatis. Status tiap alat di `ToolLog` (tampil di panel + dialog 📖). Setiap link diberi label sumber `[alat]` (`Candidate.source`, diisi via `ToolLog.tl` ThreadLocal di `Repo.addCandidates`).
3. Lepas VPN: `VpnTool` (bind ke jaringan non-VPN tanpa root; bila root, `ip rule add uidrange`). Pengaturan di 📖.

## Yang sengaja tidak dipasang
tcpdump (HTTPS tidak terbaca), sniffer VPN lokal (bentrok dengan VPN pengguna), MITM (certificate pinning), PO token/bgutil (butuh Node), LSPosed (proyek terpisah).

## Status
- Kode baru (Tools.kt, AlfyNotifService.kt, perubahan Resolver/Models/Util/FloatingService/MainActivity/NetSniffer/AlfyApp, build.gradle.kts, proguard, manifest) BELUM dibangun/diuji: lingkungan penulis tidak punya Android SDK/Maven. Kemungkinan ada 1-2 error kompilasi di build pertama; perbaiki dari log GitHub Actions.
- Dugaan penyebab kegagalan sebelumnya: YouTube menolak "Sign in to confirm you're not a bot" karena IP VPN/seluler; versi klien iOS/VR di `Resolver` ditulis tetap dan bisa usang.
- Shorts: pencarian sekarang mengenali `shortsLockupViewModel`.

## Ide berikutnya (putaran kedua)
Perbarui versi klien iOS/Android VR, modul LSPosed untuk ReVanced, PO token via Termux, cookies Chrome (terenkripsi, sulit).
