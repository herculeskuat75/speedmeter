package com.example.netspeed

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Menyalakan kembali overlay setelah HP restart, jika "Mulai otomatis" diaktifkan. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = Prefs(context)
        if (!prefs.autoStart || !prefs.enabled) return
        if (!Compat.canDrawOverlays(context)) return
        try {
            Compat.startOverlayService(context)
        } catch (_: Exception) {
        }
    }
}
