package com.example.netspeed

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.text.InputFilter
import android.text.InputType
import android.os.SystemClock
import android.view.Gravity
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var usage: UsageStore
    private lateinit var statusText: TextView
    private lateinit var toggleBtn: Button
    private lateinit var tvToday: TextView
    private lateinit var tvWeek: TextView
    private lateinit var tvMonth: TextView
    private lateinit var bgImage: ImageView
    private lateinit var tvUsageAccess: TextView
    private lateinit var contentRoot: FrameLayout
    private var titleView: TextView? = null
    private var tvLocPerm: TextView? = null

    private val allTexts = ArrayList<TextView>()
    private var sweeper: RainbowSweeper? = null

    // kunci PIN
    private var lockView: View? = null
    private val pinBuf = StringBuilder()

    private val ui = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable {
        override fun run() {
            refreshStatus()
            refreshUsage()
            ui.postDelayed(this, 2000L)
        }
    }

    private val bgFile get() = File(filesDir, "app_bg.jpg")

    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        usage = UsageStore(this)
        contentRoot = buildUi()
        setContentView(contentRoot)
        applyBackground()
        collectTexts()
        applyTextStyle()
        sweeper = RainbowSweeper(
            enabled = { prefs.rainbowApp },
            views = { allTexts },
            restore = { tv -> if (!Rainbow.isPlainButton(tv)) tv.setTextColor(prefs.appTextColor) }
        )

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (prefs.pinEnabled && !unlocked) showLock()
    }

    override fun onStart() {
        super.onStart()
        if (skipNextLock) {
            skipNextLock = false
        } else if (prefs.pinEnabled && unlocked && leftAt > 0L &&
            SystemClock.elapsedRealtime() - leftAt > prefs.lockDelaySec * 1000L
        ) {
            unlocked = false
        }
        if (prefs.pinEnabled && !unlocked) showLock()
    }

    override fun onStop() {
        if (!isChangingConfigurations) leftAt = SystemClock.elapsedRealtime()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        ui.removeCallbacks(refresher)
        ui.post(refresher)
        sweeper?.start()
        refreshLocPerm()
    }

    override fun onPause() {
        ui.removeCallbacks(refresher)
        sweeper?.stop()
        super.onPause()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_BG && resultCode == RESULT_OK) {
            data?.data?.let { saveBackground(it) }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOC) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            Toast.makeText(
                this,
                if (ok) "Izin lokasi diberikan: band dibaca tanpa root" else "Izin lokasi ditolak: band hanya tampil \"LTE\"",
                Toast.LENGTH_LONG
            ).show()
            refreshLocPerm()
        }
    }

    /** Muat ulang layar (mis. setelah mengganti PIN) tanpa meminta PIN lagi. */
    private fun restartUi() {
        skipNextLock = true
        recreate()
    }

    private fun refreshLocPerm() {
        tvLocPerm?.text = if (SignalReader.hasLocationPermission(this)) {
            "Izin lokasi (untuk band tanpa root): sudah diberikan."
        } else {
            "Izin lokasi (untuk band tanpa root): belum diberikan."
        }
    }

    // ------------------------------------------------------------------ diagnostik

    /** Bandingkan semua sumber counter (TrafficStats, sysfs, /proc, root, NetworkStats) selama 6 detik. */
    private fun runCounterDiagnostic(btn: Button, mode: Int = 0) {
        btn.isEnabled = false
        val msg = when (mode) {
            1 -> "Uji unduh otomatis berjalan 6 detik\u2026"
            2 -> "Uji unggah otomatis berjalan 6 detik\u2026"
            else -> "Sekarang lakukan UNGGAH (mis. kirim file besar) selama 6 detik\u2026"
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        val truth = java.util.concurrent.atomic.AtomicLong(0L)
        if (mode != 0) Thread {
            // Angka pembanding: byte yang BENAR-BENAR dikirim / diterima aplikasi ini sendiri.
            val end = SystemClock.elapsedRealtime() + 6000L
            try {
                if (mode == 1) {
                    val c = java.net.URL("https://speed.cloudflare.com/__down?bytes=100000000").openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 5000; c.readTimeout = 5000
                    val buf = ByteArray(32768)
                    c.inputStream.use { i ->
                        while (SystemClock.elapsedRealtime() < end) {
                            val n = i.read(buf); if (n < 0) break
                            truth.addAndGet(n.toLong())
                        }
                    }
                    c.disconnect()
                } else {
                    val c = java.net.URL("https://speed.cloudflare.com/__up").openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 5000; c.readTimeout = 8000
                    c.doOutput = true; c.requestMethod = "POST"
                    c.setChunkedStreamingMode(32768)
                    val buf = ByteArray(32768)
                    java.util.Random().nextBytes(buf)
                    c.outputStream.use { o ->
                        while (SystemClock.elapsedRealtime() < end) {
                            o.write(buf); truth.addAndGet(buf.size.toLong())
                        }
                    }
                    try { c.responseCode } catch (_: Exception) {}
                    c.disconnect()
                }
            } catch (_: Exception) {
            }
        }.start()
        Thread {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val names = try {
                @Suppress("DEPRECATION")
                cm.allNetworks.mapNotNull { cm.getLinkProperties(it)?.interfaceName }.distinct()
            } catch (_: Exception) {
                emptyList()
            }

            class Snap(
                val ts: Map<String, LongArray>?, val sys: Map<String, LongArray>?,
                val proc: Map<String, LongArray>?, val root: Map<String, LongArray>?,
                val nsm: Map<String, LongArray>?
            )

            fun take(): Snap {
                val rootTxt = RootShell.runAny("cat /proc/net/dev")
                return Snap(
                    NetCounters.trafficStats(names), NetCounters.sysfs(names), NetCounters.procNetDev(),
                    if (rootTxt != null) parseNetDev(rootTxt) else null, NetCounters.networkStats(this)
                )
            }

            val s0 = take()
            try {
                Thread.sleep(6000L)
            } catch (_: Exception) {
            }
            val s1 = take()

            fun line(label: String, a: LongArray?, b: LongArray?): String =
                if (a != null && b != null) "  $label  rx +${b[0] - a[0]}  tx +${b[1] - a[1]}\n"
                else "  $label  tidak tersedia\n"

            val sb = StringBuilder()
            sb.append("Selisih byte selama 6 detik\n(rx = unduh, tx = unggah)\n\n")
            for (n in names) {
                sb.append(n).append('\n')
                sb.append(line("TrafficStats      ", s0.ts?.get(n), s1.ts?.get(n)))
                sb.append(line("/sys/class/net    ", s0.sys?.get(n), s1.sys?.get(n)))
                sb.append(line("/proc/net/dev     ", s0.proc?.get(n), s1.proc?.get(n)))
                sb.append(line("Kernel (root)     ", s0.root?.get(n), s1.root?.get(n)))
                sb.append('\n')
            }
            if (names.isEmpty()) sb.append("Tidak ada interface jaringan terdeteksi.\n\n")
            sb.append("Statistik sistem (NetworkStats)\n")
            for (k in listOf("__wifi__" to "Wi-Fi", "__mobile__" to "Seluler")) {
                sb.append(line(k.second.padEnd(10), s0.nsm?.get(k.first), s1.nsm?.get(k.first)))
            }
            if (s0.nsm == null) sb.append("  (butuh izin Akses penggunaan, Android 6+)\n")
            if (mode != 0) {
                val tb = truth.get()
                sb.append("\nPembanding (dihitung aplikasi sendiri, ").append(if (mode == 1) "unduh" else "unggah")
                    .append("): ").append(tb).append(" byte")
                if (tb == 0L) sb.append(" (uji gagal: tidak ada internet / server menolak)")
                sb.append("\n")
            }
            sb.append("\nMode VPN-per-aplikasi: ").append(if (prefs.vpnAppLevel) "ya" else "tidak")
            sb.append("\nSumber yang dipakai meter: ").append(OverlayService.current?.activeSources() ?: "(meter mati)")
            runOnUiThread {
                btn.isEnabled = true
                AlertDialog.Builder(this)
                    .setTitle("Hasil diagnostik")
                    .setMessage(sb.toString())
                    .setPositiveButton("Tutup", null)
                    .show()
            }
        }.start()
    }

    // ------------------------------------------------------------------ teks: warna, font, pelangi

    private fun collectTexts() {
        allTexts.clear()
        Rainbow.collect(contentRoot, allTexts)
    }

    /** Terapkan warna teks, font, dan (lewat sweeper) pelangi ke semua tulisan di layar pengaturan. */
    private fun applyTextStyle() {
        val tf = Fonts.typeface(prefs.fontOf(Area.APP), 0)
        val titleTf = Fonts.typeface(prefs.fontOf(Area.TITLE), 1)
        val c = prefs.appTextColor
        for (tv in allTexts) {
            tv.typeface = if (tv === titleView) titleTf else tf
            // Tombol biasa dibiarkan (latarnya abu-abu), Switch / RadioButton ikut diwarnai.
            if (!Rainbow.isPlainButton(tv)) tv.setTextColor(c)
        }
    }

    private fun applyTextColor() = applyTextStyle()

    // ------------------------------------------------------------------ kunci PIN

    private fun showLock() {
        if (lockView != null) return
        pinBuf.setLength(0)
        val v = buildLockView()
        contentRoot.addView(v, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        lockView = v
    }

    private fun hideLock() {
        lockView?.let { contentRoot.removeView(it) }
        lockView = null
        unlocked = true
        pinBuf.setLength(0)
    }

    private fun buildLockView(): View {
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#F2F4F8"))
            isClickable = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }
        val ink = Color.parseColor("#1B1F27")
        col.addView(TextView(this).apply {
            text = "Speed Meter terkunci"
            textSize = 22f
            setTextColor(ink)
            gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "Masukkan PIN"
            textSize = 14f
            setTextColor(Color.parseColor("#5A6270"))
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(14))
        })
        val dots = TextView(this).apply {
            textSize = 30f
            setTextColor(ink)
            gravity = Gravity.CENTER
            minHeight = dp(44)
        }
        col.addView(dots)
        val msg = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#C62828"))
            gravity = Gravity.CENTER
            minHeight = dp(24)
        }
        col.addView(msg)

        fun refreshDots() {
            val n = pinBuf.length
            dots.text = if (n == 0) "" else "\u25CF ".repeat(n).trim()
        }

        fun submit() {
            val now = System.currentTimeMillis()
            if (prefs.pinBlockedUntil > now) {
                msg.text = "Terlalu banyak salah. Coba lagi dalam ${(prefs.pinBlockedUntil - now) / 1000 + 1} detik."
                pinBuf.setLength(0)
                refreshDots()
                return
            }
            if (Pin.verify(prefs, pinBuf.toString())) {
                prefs.pinFails = 0
                hideLock()
            } else {
                val f = prefs.pinFails + 1
                prefs.pinFails = f
                if (f % 5 == 0) prefs.pinBlockedUntil = now + 30_000L * (f / 5)
                msg.text = if (f % 5 == 0) "PIN salah $f kali. Tunggu ${30 * (f / 5)} detik." else "PIN salah."
                pinBuf.setLength(0)
                refreshDots()
            }
        }

        fun press(k: String) {
            msg.text = ""
            when (k) {
                "\u232B" -> if (pinBuf.isNotEmpty()) pinBuf.setLength(pinBuf.length - 1)
                "OK" -> {
                    submit()
                    return
                }
                else -> if (pinBuf.length < 8) pinBuf.append(k)
            }
            refreshDots()
            if (k != "\u232B" && pinBuf.length == prefs.pinLen) submit()
        }

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rows = listOf(
            listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"),
            listOf("\u232B", "0", "OK")
        )
        for (r in rows) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in r) {
                val b = Button(this).apply {
                    text = k
                    textSize = 22f
                    setTextColor(ink)
                    setOnClickListener { press(k) }
                }
                row.addView(b, LinearLayout.LayoutParams(0, dp(66), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            grid.addView(row)
        }
        col.addView(grid, LinearLayout.LayoutParams(dp(300), LinearLayout.LayoutParams.WRAP_CONTENT))
        col.addView(TextView(this).apply {
            text = "Lupa PIN? Hapus data aplikasi lewat Pengaturan HP > Aplikasi."
            textSize = 11f
            setTextColor(Color.parseColor("#5A6270"))
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })
        frame.addView(col, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))
        return frame
    }

    /** Dialog dengan beberapa kolom angka (PIN). onOk mengembalikan false untuk membiarkan dialog tetap terbuka. */
    private fun pinDialog(title: String, labels: List<String>, onOk: (List<String>) -> Boolean) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(10), dp(22), 0)
        }
        val fields = labels.map { l ->
            EditText(this).apply {
                hint = l
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                filters = arrayOf(InputFilter.LengthFilter(8))
            }.also { box.addView(it) }
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK", null)
            .setNegativeButton("Batal", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (onOk(fields.map { it.text.toString() })) dlg.dismiss()
        }
    }

    private fun pinSection(col: LinearLayout) {
        col.addView(sectionTitle("Kunci aplikasi (PIN)"))
        col.addView(TextView(this).apply {
            text = "PIN dipakai untuk membuka layar pengaturan ini. Meter yang mengambang dan tombol Stop di " +
                "notifikasi tetap berjalan seperti biasa. PIN tidak disimpan, hanya hash-nya."
            textSize = 12f
            setPadding(0, dp(2), 0, dp(6))
        })
        if (!prefs.pinEnabled) {
            col.addView(Button(this).apply {
                text = "Atur PIN"
                setOnClickListener {
                    pinDialog("Atur PIN (4-8 angka)", listOf("PIN baru", "Ulangi PIN")) { v ->
                        when {
                            v[0].length < 4 -> { toast("PIN minimal 4 angka"); false }
                            v[0] != v[1] -> { toast("Kedua PIN tidak sama"); false }
                            else -> {
                                Pin.set(prefs, v[0])
                                prefs.pinLen = v[0].length
                                unlocked = true
                                toast("PIN aktif")
                                restartUi()
                                true
                            }
                        }
                    }
                }
            })
        } else {
            col.addView(Button(this).apply {
                text = "Ganti PIN"
                setOnClickListener {
                    pinDialog("Ganti PIN", listOf("PIN lama", "PIN baru (4-8 angka)", "Ulangi PIN baru")) { v ->
                        when {
                            !Pin.verify(prefs, v[0]) -> { toast("PIN lama salah"); false }
                            v[1].length < 4 -> { toast("PIN minimal 4 angka"); false }
                            v[1] != v[2] -> { toast("Kedua PIN tidak sama"); false }
                            else -> {
                                Pin.set(prefs, v[1])
                                prefs.pinLen = v[1].length
                                toast("PIN diganti")
                                true
                            }
                        }
                    }
                }
            })
            col.addView(Button(this).apply {
                text = "Matikan PIN"
                setOnClickListener {
                    pinDialog("Matikan PIN", listOf("PIN saat ini")) { v ->
                        if (!Pin.verify(prefs, v[0])) {
                            toast("PIN salah")
                            false
                        } else {
                            Pin.clear(prefs)
                            toast("PIN dimatikan")
                            restartUi()
                            true
                        }
                    }
                }
            })
            val opts = listOf("Langsung saat aplikasi ditinggalkan", "Setelah 30 detik", "Setelah 2 menit")
            val vals = intArrayOf(0, 30, 120)
            col.addView(radioRow("Kunci lagi", opts, vals.indexOf(prefs.lockDelaySec).coerceAtLeast(0)) {
                prefs.lockDelaySec = vals[it]
            })
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ aksi

    private fun refreshStatus() {
        val hasPerm = Compat.canDrawOverlays(this)
        val on = OverlayService.running
        statusText.text = when {
            !hasPerm -> "Izin \"Tampil di atas aplikasi lain\" belum diberikan."
            on -> "Meter sedang aktif dan mengambang di layar."
            else -> "Meter mati."
        }
        toggleBtn.text = if (on) "MATIKAN METER" else "NYALAKAN METER"
        tvUsageAccess.text = if (hasUsageAccess(this)) {
            "Akses penggunaan: sudah diizinkan."
        } else {
            "Akses penggunaan: belum diizinkan."
        }
    }

    private fun toggle() {
        if (OverlayService.running) {
            prefs.enabled = false
            stopService(Intent(this, OverlayService::class.java))
            toggleBtn.postDelayed({ refreshStatus() }, 300)
            return
        }
        if (!Compat.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin lalu kembali ke aplikasi ini", Toast.LENGTH_LONG).show()
            if (Build.VERSION.SDK_INT >= 23) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
            return
        }
        prefs.enabled = true
        Compat.startOverlayService(this)
        toggleBtn.postDelayed({ refreshStatus() }, 300)
    }

    private fun usageText(title: String, u: UsageStore.Usage): String =
        "$title\nWi-Fi: ${SpeedSampler.formatSize(u.wifi)}  \u2022  " +
            "Data: ${SpeedSampler.formatSize(u.mobile)}  \u2022  " +
            "Total: ${SpeedSampler.formatSize(u.total)}"

    private fun refreshUsage() {
        tvToday.text = usageText("Hari ini", usage.today())
        tvWeek.text = usageText("Minggu ini (mulai Senin)", usage.week())
        tvMonth.text = usageText("Bulan ini", usage.month())
    }

    // ------------------------------------------------------------------ latar belakang

    private fun pickBackground() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        try {
            startActivityForResult(i, REQ_BG)
        } catch (_: Exception) {
            try {
                val alt = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                startActivityForResult(Intent.createChooser(alt, "Pilih gambar"), REQ_BG)
            } catch (_: Exception) {
                Toast.makeText(this, "Tidak ada aplikasi galeri/pemilih file", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Ambil gambar, kecilkan (maks 1600 px), putar sesuai EXIF, simpan di penyimpanan aplikasi. */
    private fun saveBackground(uri: Uri) {
        Toast.makeText(this, "Memproses gambar\u2026", Toast.LENGTH_SHORT).show()
        Thread {
            var error: String? = null
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException("gambar tidak terbaca")
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2

                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, opts)
                } ?: throw IllegalStateException("gambar tidak terbaca")

                val orientation = try {
                    if (Build.VERSION.SDK_INT >= 24) {
                        contentResolver.openInputStream(uri)?.use {
                            ExifInterface(it).getAttributeInt(
                                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                            )
                        } ?: ExifInterface.ORIENTATION_NORMAL
                    } else {
                        // Android 5-6: ExifInterface belum bisa membaca stream, salin ke file sementara.
                        val tmp = File(cacheDir, "exif.tmp")
                        contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                        val o = ExifInterface(tmp.absolutePath).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                        )
                        tmp.delete()
                        o
                    }
                } catch (_: Exception) {
                    ExifInterface.ORIENTATION_NORMAL
                }
                val degrees = when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
                if (degrees != 0f) {
                    val m = Matrix().apply { postRotate(degrees) }
                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                }

                bgFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            } catch (e: Throwable) {
                error = e.message ?: e.javaClass.simpleName
            }
            runOnUiThread {
                if (error != null) {
                    Toast.makeText(this, "Gagal memakai gambar: $error", Toast.LENGTH_LONG).show()
                } else {
                    applyBackground()
                }
            }
        }.start()
    }

    private fun removeBackground() {
        bgFile.delete()
        applyBackground()
    }

    private fun applyBackground() {
        if (bgFile.exists()) {
            val bmp = BitmapFactory.decodeFile(bgFile.absolutePath)
            if (bmp != null) {
                bgImage.setImageBitmap(bmp)
                bgImage.visibility = View.VISIBLE // gambar tampil apa adanya, tanpa lapisan putih
                return
            }
        }
        bgImage.setImageDrawable(null)
        bgImage.visibility = View.GONE // tanpa gambar: latar putih (warna dasar frame)
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi(): FrameLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(32))
        }

        titleView = TextView(this).apply {
            text = "Speed Meter"
            textSize = 26f
            setTextColor(Color.BLACK)
        }
        col.addView(titleView)

        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(6), 0, dp(12))
        }
        col.addView(statusText)

        toggleBtn = Button(this).apply { setOnClickListener { toggle() } }
        col.addView(toggleBtn)

        col.addView(sectionTitle("Total pemakaian data"))
        tvToday = TextView(this).apply { setPadding(0, dp(4), 0, dp(8)) }
        tvWeek = TextView(this).apply { setPadding(0, dp(4), 0, dp(8)) }
        tvMonth = TextView(this).apply { setPadding(0, dp(4), 0, dp(8)) }
        col.addView(tvToday)
        col.addView(tvWeek)
        col.addView(tvMonth)
        col.addView(TextView(this).apply {
            text = "Dihitung hanya saat meter aktif (perkiraan, bukan kuota resmi operator)."
            textSize = 12f
        })

        col.addView(sectionTitle("Latar belakang aplikasi"))
        val bgRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bgRow.addView(Button(this).apply {
            text = "Pilih gambar"
            setOnClickListener { pickBackground() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bgRow.addView(Button(this).apply {
            text = "Hapus gambar"
            setOnClickListener { removeBackground() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(bgRow)

        col.addView(sectionTitle("Jaringan yang diukur"))
        col.addView(radioRow("Tampilkan kecepatan dari", listOf("Semua (Wi-Fi + data)", "Hanya Wi-Fi", "Hanya data seluler"), prefs.netFilter) {
            prefs.netFilter = it
        })

        col.addView(sectionTitle("Pelangi & warna"))
        col.addView(toggleRow("Pelangi di SEMUA teks & angka (meter, notifikasi, grafik, aplikasi ini)", prefs.rainbowAll) {
            prefs.rainbowAll = it
            restartUi()
        })
        col.addView(toggleRow("Pelangi di teks aplikasi ini", prefs.rainbowApp) { prefs.rainbowApp = it })
        col.addView(toggleRow("Pelangi di teks panel trafik & grafik", prefs.rainbowGraph) { prefs.rainbowGraph = it })
        col.addView(colorSection("Teks di aplikasi ini", { prefs.appTextColor }, {
            prefs.appTextColor = it
            applyTextColor()
        }))
        col.addView(toggleRow("Pelangi di meter mengambang (saat internet tersambung)", prefs.rainbow) {
            prefs.rainbow = it
        })
        col.addView(colorSection("Download (↓)", { prefs.downColor }, { prefs.downColor = it }))
        col.addView(colorSection("Upload (↑)", { prefs.upColor }, { prefs.upColor = it }))
        col.addView(colorSection("Latar belakang", { prefs.bgColor }, { prefs.bgColor = it }))

        col.addView(sectionTitle("Tampilan"))
        col.addView(radioRow("Ketebalan huruf", listOf("Normal", "Tebal", "Tebal banget"), prefs.textWeight) {
            prefs.textWeight = it
        })
        col.addView(radioRow("Panah saat ada trafik", listOf("Mati", "Menyala", "Berkedip"), prefs.arrowMode) {
            prefs.arrowMode = it
        })
        col.addView(labeledSeek("Transparansi latar", 255, prefs.bgAlpha, { "${it * 100 / 255}%" }) {
            prefs.bgAlpha = it
        })
        col.addView(labeledSeek("Ukuran teks meter mengambang", 52, (prefs.textSize - 8).coerceIn(0, 52), { "${it + 8} sp" }) {
            prefs.textSize = it + 8
        })
        col.addView(labeledSeek("Skala meter mengambang", 35, ((prefs.overlayScale * 10).toInt() - 5).coerceIn(0, 35), { "${(it + 5) * 10}%" }) {
            prefs.overlayScale = (it + 5) / 10f
        })
        col.addView(
            labeledSeek("Interval pengukuran", 7, (prefs.intervalMs / 250 - 1).toInt(),
                { "${(it + 1) * 250} ms" }) {
                prefs.intervalMs = (it + 1) * 250L
            }
        )

        col.addView(sectionTitle("Panel trafik (ketuk meter)"))
        col.addView(TextView(this).apply {
            text = "Ketuk meter yang mengambang untuk melihat grafik naik-turun, aplikasi yang " +
                "sedang memakai internet, dan alamat yang diakses. Trafik per aplikasi butuh izin " +
                "\"Akses penggunaan\"."
            textSize = 13f
            setPadding(0, dp(4), 0, dp(6))
        })
        tvUsageAccess = TextView(this).apply { setPadding(0, 0, 0, dp(4)) }
        col.addView(tvUsageAccess)
        col.addView(Button(this).apply {
            text = "Buka pengaturan Akses penggunaan"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Pengaturan tidak ditemukan", Toast.LENGTH_LONG).show()
                }
            }
        })

        col.addView(toggleRow("Alamat via root (minta akses su, untuk melihat alamat yang diakses)", prefs.rootAddr) { on ->
            prefs.rootAddr = on
            if (on) {
                // Memancing dialog izin root (Magisk/KernelSU) sekarang juga.
                Thread {
                    val ok = RootShell.run("id") != null
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            if (ok) "Akses root diberikan" else "Akses root ditolak / tidak ada root",
                            Toast.LENGTH_LONG
                        ).show()
                        if (!ok) prefs.rootAddr = false
                    }
                }.start()
            }
        })

        col.addView(toggleRow("Tampilkan nama host (subdomain) bukan IP, lewat reverse DNS", prefs.resolveHost) { prefs.resolveHost = it })

        col.addView(sectionTitle("Notifikasi: IP, sinyal, band"))
        col.addView(TextView(this).apply {
            text = "Notifikasi menampilkan IP lokal. dBm dan band dibaca lewat root (dumpsys), sama seperti script Termux."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        })
        col.addView(toggleRow("Tampilkan dBm & band di notifikasi (butuh root)", prefs.rootSignal) { on ->
            prefs.rootSignal = on
            if (on) {
                Thread {
                    val ok = RootShell.run("id") != null
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            if (ok) "Akses root diberikan" else "Akses root ditolak / tidak ada root",
                            Toast.LENGTH_LONG
                        ).show()
                        if (!ok) prefs.rootSignal = false
                    }
                }.start()
            }
        })

        col.addView(sectionTitle("Tampilan notifikasi"))
        col.addView(TextView(this).apply {
            text = "Atur warna, ukuran, ketebalan, dan pelangi untuk teks IP lokal, dBm, band, unduh, dan unggah " +
                "di panel notifikasi. Semua ini jalan tanpa root. Saat notifikasi diciutkan Android hanya memberi " +
                "tinggi sekitar 64dp, jadi ukuran besar terlihat penuh setelah notifikasi dibentangkan " +
                "(atau pilih mode ciut di bawah)."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        })
        col.addView(toggleRow("Pelangi di teks notifikasi", prefs.rainbowNotif) { prefs.rainbowNotif = it })
        col.addView(toggleRow("Warna sendiri untuk unduh / unggah (mati = otomatis terang)", prefs.notifSpeedCustom) { prefs.notifSpeedCustom = it })
        col.addView(colorSection("Warna unduh / unggah", { prefs.notifSpeedColor }, { prefs.notifSpeedColor = it; prefs.notifSpeedCustom = true }))
        col.addView(toggleRow("Warna sendiri untuk IP, dBm, band (mati = otomatis terang)", prefs.notifInfoCustom) { prefs.notifInfoCustom = it })
        col.addView(colorSection("Warna IP / dBm / band", { prefs.notifInfoColor }, { prefs.notifInfoColor = it; prefs.notifInfoCustom = true }))
        col.addView(labeledSeek("Ukuran unduh / unggah", 24, (prefs.notifSpeedSize - 10).coerceIn(0, 24), { "${it + 10} sp" }) { prefs.notifSpeedSize = it + 10 })
        col.addView(labeledSeek("Ukuran IP / dBm / band", 18, (prefs.notifInfoSize - 8).coerceIn(0, 18), { "${it + 8} sp" }) { prefs.notifInfoSize = it + 8 })
        col.addView(radioRow("Ketebalan unduh / unggah", listOf("Normal", "Tebal", "Tebal banget"), prefs.notifSpeedWeight) { prefs.notifSpeedWeight = it })
        col.addView(radioRow("Ketebalan IP / dBm / band", listOf("Normal", "Tebal", "Tebal banget"), prefs.notifInfoWeight) { prefs.notifInfoWeight = it })
        col.addView(radioRow("Saat notifikasi diciutkan", listOf("Otomatis (kecilkan agar muat)", "Sembunyikan baris IP/dBm/band (unduh/unggah besar)", "Ukuran penuh (boleh terpotong)"), prefs.notifCollapsed) { prefs.notifCollapsed = it })
        col.addView(toggleRow("Teks ringkas dengan panah (\u2191 \u2193)", prefs.notifCompact) { prefs.notifCompact = it })

        col.addView(sectionTitle("Font"))
        col.addView(TextView(this).apply {
            text = "Pilih \"Ikuti font HP\" untuk memakai font sistem, atau \"Bawaan aplikasi\". Tiap bagian bisa diatur sendiri atau mengikuti font global."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        })
        col.addView(fontPicker("Font global", null))
        col.addView(fontPicker("Nama aplikasi (judul)", Area.TITLE))
        col.addView(fontPicker("Teks di aplikasi ini", Area.APP))
        col.addView(fontPicker("Meter mengambang", Area.FLOAT))
        col.addView(fontPicker("Notifikasi: unduh / unggah", Area.NSPEED))
        col.addView(fontPicker("Notifikasi: IP lokal", Area.IP))
        col.addView(fontPicker("Notifikasi: dBm", Area.DBM))
        col.addView(fontPicker("Notifikasi: band", Area.BAND))
        col.addView(fontPicker("Panel trafik & grafik", Area.GRAPH))

        col.addView(sectionTitle("dBm & band tanpa root"))
        col.addView(TextView(this).apply {
            text = "dBm dibaca lewat API Android biasa (tanpa izin). Band dan sinyal sel yang lebih tepat butuh izin lokasi " +
                "(aplikasi tidak menyimpan atau mengirim lokasi). Jika HP di-root, cara root dicoba lebih dulu."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        })
        col.addView(toggleRow("Baca dBm & band tanpa root", prefs.noRootSignal) { on ->
            prefs.noRootSignal = on
            if (on && Build.VERSION.SDK_INT >= 23 && !SignalReader.hasLocationPermission(this)) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_LOC)
            }
        })
        tvLocPerm = TextView(this).apply { setPadding(0, 0, 0, dp(4)) }
        col.addView(tvLocPerm)
        col.addView(Button(this).apply {
            text = "Minta izin lokasi"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_LOC)
            }
        })

        col.addView(sectionTitle("Akurasi unggah / unduh"))
        col.addView(toggleRow("Tambahan: baca counter kernel via root (abaikan jika tidak root)", prefs.rootCounters) { prefs.rootCounters = it })
        col.addView(TextView(this).apply {
            text = "Tanpa root, aplikasi memakai 4 cara sekaligus (TrafficStats, /sys/class/net, /proc/net/dev, dan statistik sistem NetworkStats bila Akses penggunaan diizinkan) lalu mengambil angka unggah/unduh terbesar. Root hanya tambahan. Pakai tombol diagnostik untuk melihat cara mana yang jalan di HP kamu."
            textSize = 12f
            setPadding(0, dp(2), 0, dp(4))
        })
        col.addView(Button(this).apply {
            text = "Diagnostik (unggah manual)"
            setOnClickListener { runCounterDiagnostic(this, 0) }
        })
        col.addView(Button(this).apply {
            text = "Uji UNDUH otomatis (6 detik)"
            setOnClickListener { runCounterDiagnostic(this, 1) }
        })
        col.addView(Button(this).apply {
            text = "Uji UNGGAH otomatis (6 detik)"
            setOnClickListener { runCounterDiagnostic(this, 2) }
        })

        col.addView(sectionTitle("Opsi"))
        col.addView(toggleRow("Tampilkan dalam bit (Mbps)", prefs.useBits) { prefs.useBits = it })
        col.addView(toggleRow("Saat VPN aktif, ukur level aplikasi (sama seperti 1DM+)", prefs.vpnAppLevel) { prefs.vpnAppLevel = it })
        col.addView(toggleRow("Tampilkan upload", prefs.showUpload) { prefs.showUpload = it })
        col.addView(toggleRow("Kunci posisi (tidak bisa digeser)", prefs.locked) { prefs.locked = it })
        col.addView(toggleRow("Jangan menutupi tombol navigasi (Home / Back / Recent)", prefs.safeNav) { prefs.safeNav = it })

        col.addView(sectionTitle("Tetap tampil di panel notifikasi & Pengaturan"))
        col.addView(TextView(this).apply {
            text = "Android menyembunyikan meter mengambang biasa saat panel notifikasi ditarik dan di beberapa " +
                "layar Pengaturan. Agar tetap tampil, nyalakan layanan aksesibilitas \"Speed Meter\" " +
                "(hanya untuk menggambar meter, tidak membaca isi layar), lalu nyalakan opsi di bawah."
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        })
        col.addView(toggleRow("Tampil di atas panel notifikasi & Pengaturan", prefs.a11yOverlay) { prefs.a11yOverlay = it })
        col.addView(Button(this).apply {
            text = "Buka pengaturan aksesibilitas"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Tidak bisa membuka pengaturan aksesibilitas", Toast.LENGTH_LONG).show()
                }
            }
        })
        col.addView(Button(this).apply {
            text = "Aktifkan layanan lewat root"
            setOnClickListener {
                Thread {
                    val comp = "$packageName/${OverlayAccessibilityService::class.java.name}"
                    val cur = (RootShell.runAny("settings get secure enabled_accessibility_services") ?: "").trim()
                    val has = cur.split(":").any { it == comp }
                    val list = if (has) cur else if (cur.isEmpty() || cur == "null") comp else "$cur:$comp"
                    val ok = RootShell.runAny(
                        "settings put secure enabled_accessibility_services $list; " +
                            "settings put secure accessibility_enabled 1; echo ok"
                    ) != null
                    runOnUiThread {
                        Toast.makeText(
                            this@MainActivity,
                            if (ok) "Layanan diaktifkan. Nyalakan opsi di atas." else "Gagal (root ditolak?)",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }.start()
            }
        })
        col.addView(toggleRow("Kunci ukuran (cubit dua jari tidak mengubah ukuran)", prefs.lockResize) { prefs.lockResize = it })
        col.addView(TextView(this).apply {
            text = "Ukuran meter: cubit dua jari pada meter untuk mengecilkan, rentangkan untuk membesarkan."
            textSize = 12f
        })
        col.addView(Button(this).apply {
            text = "Reset ukuran meter"
            setOnClickListener { prefs.overlayScale = 1f }
        })
        col.addView(toggleRow("Mulai otomatis setelah HP restart", prefs.autoStart) { prefs.autoStart = it })

        pinSection(col)

        col.addView(TextView(this).apply {
            text = "Tip: seret meter di layar untuk memindahkan posisinya."
            textSize = 12f
            setPadding(0, dp(16), 0, 0)
        })

        col.addView(TextView(this).apply {
            text = "created by alfy47"
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        }, LinearLayout.LayoutParams(-1, -2))
        col.addView(TextView(this).apply {
            text = "alfysilverfunks@gmail.com"
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, dp(8))
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:alfysilverfunks@gmail.com")))
                } catch (_: Exception) {
                    toast("Tidak ada aplikasi email")
                }
            }
        }, LinearLayout.LayoutParams(-1, -2))

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        bgImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
        }
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        frame.addView(bgImage, FrameLayout.LayoutParams(match, match))
        frame.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(match, match))
        return frame
    }

    private fun fontPicker(title: String, area: Int?): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        box.addView(TextView(this).apply { text = title })
        val items = if (area == null) Fonts.names else listOf("Ikuti font global") + Fonts.names
        fun idxOf(pos: Int): Int = if (area == null) pos else if (pos == 0) prefs.fontGlobal else pos - 1
        val cur = if (area == null) prefs.fontGlobal else prefs.fontRaw(area) + 1
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                (v as? TextView)?.typeface = Fonts.typeface(idxOf(position), 0)
                return v
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getDropDownView(position, convertView, parent)
                (v as? TextView)?.typeface = Fonts.typeface(idxOf(position), 0)
                return v
            }
        }
        val sp = Spinner(this)
        sp.adapter = adapter
        sp.setSelection(cur.coerceIn(0, items.size - 1), false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val now = if (area == null) prefs.fontGlobal else prefs.fontRaw(area) + 1
                if (pos == now) return
                if (area == null) prefs.fontGlobal = pos else prefs.setFontRaw(area, pos - 1)
                applyTextStyle()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        box.addView(sp)
        return box
    }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 18f
        setTextColor(Color.BLACK)
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun seek(max: Int, progress: Int, onChange: (Int) -> Unit): SeekBar =
        SeekBar(this).apply {
            this.max = max
            this.progress = progress
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) onChange(p)
                }

                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }

    private fun labeledSeek(
        title: String,
        max: Int,
        progress: Int,
        label: (Int) -> String,
        onChange: (Int) -> Unit
    ): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tv = TextView(this).apply { text = "$title: ${label(progress)}" }
        box.addView(tv)
        box.addView(seek(max, progress) {
            tv.text = "$title: ${label(it)}"
            onChange(it)
        })
        return box
    }

    private fun radioRow(
        title: String,
        options: List<String>,
        selected: Int,
        onSelect: (Int) -> Unit
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        box.addView(TextView(this).apply { text = title })
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        val ids = ArrayList<Int>()
        options.forEach { label ->
            val rb = RadioButton(this)
            rb.text = label
            rb.id = View.generateViewId()
            ids.add(rb.id)
            group.addView(rb)
        }
        group.check(ids[selected.coerceIn(0, ids.size - 1)])
        group.setOnCheckedChangeListener { _, checkedId ->
            val idx = ids.indexOf(checkedId)
            if (idx >= 0) onSelect(idx)
        }
        box.addView(group)
        return box
    }

    private fun toggleRow(title: String, initial: Boolean, onChange: (Boolean) -> Unit): View =
        Switch(this).apply {
            text = title
            isChecked = initial
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }

    /** Pemilih warna: kotak pratinjau + slider R/G/B + warna cepat. */
    private fun colorSection(title: String, get: () -> Int, set: (Int) -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val preview = View(this).apply { setBackgroundColor(get()) }
        header.addView(TextView(this).apply { text = title }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(preview, LinearLayout.LayoutParams(dp(56), dp(28)))
        box.addView(header)

        val c0 = get()
        val sbs = arrayOfNulls<SeekBar>(3)
        fun apply() {
            val c = Color.rgb(sbs[0]!!.progress, sbs[1]!!.progress, sbs[2]!!.progress)
            preview.setBackgroundColor(c)
            set(c)
        }
        sbs[0] = seek(255, Color.red(c0)) { apply() }
        sbs[1] = seek(255, Color.green(c0)) { apply() }
        sbs[2] = seek(255, Color.blue(c0)) { apply() }
        sbs.forEach { box.addView(it) }

        val presets = intArrayOf(
            Color.WHITE, Color.parseColor("#4CAF50"), Color.CYAN, Color.YELLOW,
            Color.parseColor("#FF9800"), Color.RED, Color.MAGENTA, Color.BLACK
        )
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (p in presets) {
            val sw = View(this).apply {
                setBackgroundColor(p)
                setOnClickListener {
                    sbs[0]!!.progress = Color.red(p)
                    sbs[1]!!.progress = Color.green(p)
                    sbs[2]!!.progress = Color.blue(p)
                    preview.setBackgroundColor(p)
                    set(p)
                }
            }
            val lp = LinearLayout.LayoutParams(0, dp(30), 1f)
            lp.setMargins(dp(2), dp(6), dp(2), 0)
            row.addView(sw, lp)
        }
        box.addView(row)
        return box
    }

    companion object {
        private const val REQ_BG = 42
        private const val REQ_LOC = 43

        /** sudah memasukkan PIN pada sesi proses ini */
        @Volatile var unlocked = false
        @Volatile var leftAt = 0L
        @Volatile var skipNextLock = false
    }
}
